package com.example.editfast

import android.graphics.*
import android.text.*
import android.text.style.ForegroundColorSpan
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings
import kotlin.math.*

/** المناطق التي تغطيها واجهة المنصة (نسب تقريبية من الإطار العمودي 9:16) */
data class SafeZone(val top: Float, val bottom: Float, val right: Float, val left: Float = 0.04f)
val PLATFORMS: List<Pair<String, SafeZone?>> = listOf(
    "بدون" to null,
    "TikTok" to SafeZone(0.12f, 0.26f, 0.17f),
    "Instagram Reels" to SafeZone(0.10f, 0.22f, 0.15f),
    "YouTube Shorts" to SafeZone(0.10f, 0.22f, 0.17f)
)
fun presetY(z: SafeZone?, which: Int): Float = when (which) {
    0 -> if (z != null) 1f - 2f * z.top - 0.15f else 0.65f
    1 -> 0.05f
    else -> if (z != null) -1f + 2f * z.bottom + 0.15f else -0.65f
}

val ANIMS = listOf("بدون", "تلاشي", "ظهور مكبّر", "انزلاق من الأسفل", "انزلاق من الأعلى", "آلة كاتبة")
val TEMPLATES: List<Pair<String, CapStyle>> = listOf(
    "أصفر بارز" to CapStyle(),
    "أبيض كلاسيك" to CapStyle(color = 0xFFFFFFFF.toInt(), anim = 1),
    "صندوق دائري" to CapStyle(color = 0xFFFFFFFF.toInt(), outline = false, shadow = false, boxMode = 2, boxColor = 0xCC000000.toInt(), anim = 1),
    "نيون" to CapStyle(color = 0xFF00E5FF.toInt(), anim = 3),
    "آلة كاتبة" to CapStyle(font = "monospace", color = 0xFFFFFFFF.toInt(), outline = false, boxMode = 1, boxColor = 0xFF000000.toInt(), anim = 5),
    "وردي بوب" to CapStyle(color = 0xFFFF4081.toInt(), outlineColor = 0xFFFFFFFF.toInt(), anim = 2),
    "شريط أخضر" to CapStyle(color = 0xFF000000.toInt(), outline = false, shadow = false, boxMode = 2, boxColor = 0xFF69F0AE.toInt(), anim = 4)
)

data class AnimState(val alpha: Float, val scale: Float, val dy: Float, val chars: Int)

object CapAnim {
    private fun easeOut(p: Float) = 1f - (1f - p).pow(3)
    private fun back(p: Float): Float { val c1 = 1.70158f; val c3 = c1 + 1f; return 1f + c3 * (p - 1f).pow(3) + c1 * (p - 1f).pow(2) }

    /** حالة الحركة عند الزمن t (تُستخدم في المعاينة والتصدير بنفس الطريقة) */
    fun state(c: Caption, t: Long): AnimState {
        val st = c.st; val d = max(1L, st.animMs).toFloat()
        val pin = ((t - c.startMs) / d).coerceIn(0f, 1f); val pout = ((c.endMs - t) / d).coerceIn(0f, 1f)
        var alpha = 1f; var scale = 1f; var dy = 0f; var chars = -1
        when (st.anim) {
            1 -> alpha = pin
            2 -> { scale = 0.5f + 0.5f * back(pin); alpha = min(1f, pin * 3f) }
            3 -> { dy = -(1f - easeOut(pin)) * 0.2f; alpha = pin }
            4 -> { dy = (1f - easeOut(pin)) * 0.2f; alpha = pin }
            5 -> chars = ceil(c.text.length * ((t - c.startMs) / (d * 3f)).coerceIn(0f, 1f)).toInt()
        }
        if (st.animOut == 1) alpha *= pout
        return AnimState(alpha.coerceIn(0f, 1f), scale.coerceAtLeast(0.01f), dy, chars)
    }

    /** مركز النص بإحداثيات NDC مع حصره داخل المنطقة الآمنة */
    fun place(c: Caption, bw: Int, bh: Int, fw: Int, fh: Int, safe: SafeZone?, a: AnimState): Pair<Float, Float> {
        var x = c.st.x; var y = c.st.y
        if (safe != null) {
            val hw = bw.toFloat() / fw; val hh = bh.toFloat() / fh
            val xmin = -1f + 2f * safe.left + hw; val xmax = 1f - 2f * safe.right - hw
            val ymin = -1f + 2f * safe.bottom + hh; val ymax = 1f - 2f * safe.top - hh
            if (xmin <= xmax) x = x.coerceIn(xmin, xmax)
            if (ymin <= ymax) y = y.coerceIn(ymin, ymax)
        }
        return x to (y + a.dy)
    }
}

object CapRender {
    private val imgCache = HashMap<String, Bitmap>()
    private fun sticker(path: String): Bitmap? = imgCache.getOrPut(path) {
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 2 }) ?: return null
    }

    /** يرسم النص (أو الملصق) في صورة بنفس الأبعاد النسبية للإطار: خط، حدود، ظل، صندوق */
    fun render(c: Caption, fw: Int, fh: Int, chars: Int = -1): Bitmap {
        val st = c.st
        if (c.img != null) sticker(c.img)?.let { b ->
            val th = (fh * 0.22f * st.size).toInt().coerceAtLeast(8)
            return Bitmap.createScaledBitmap(b, max(8, b.width * th / b.height), th, true)
        }
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = st.typeface(); textSize = fh * 0.04f * st.size; color = st.color }
        val full = c.text.ifBlank { " " }
        val w = min(max(40, (fw * st.maxW).toInt()), max(1, ceil(Layout.getDesiredWidth(full, tp)).toInt()))
        val sp = SpannableString(full)
        if (chars in 0 until full.length) sp.setSpan(ForegroundColorSpan(0x00000000), chars, full.length, 0)
        val al = when (st.align) { 0 -> Layout.Alignment.ALIGN_NORMAL; 2 -> Layout.Alignment.ALIGN_OPPOSITE; else -> Layout.Alignment.ALIGN_CENTER }
        fun lay(p: TextPaint) = StaticLayout.Builder.obtain(sp, 0, sp.length, p, w).setAlignment(al).build()
        val sw = if (st.outline) tp.textSize * 0.14f else 0f
        val pad = if (st.boxMode != 0) tp.textSize * 0.5f * st.boxPad else 0f
        val h = lay(tp).height
        val bw = max(2, (w + 2 * pad + 2 * sw).toInt()); val bh = max(2, (h + 2 * pad + 2 * sw).toInt())
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
        if (st.boxMode != 0) {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = st.boxColor }
            val r = RectF(0f, 0f, bw.toFloat(), bh.toFloat())
            if (st.boxMode == 2) cv.drawRoundRect(r, pad * 0.9f, pad * 0.9f, bp) else cv.drawRect(r, bp)
        }
        cv.save(); cv.translate(pad + sw, pad + sw)
        if (st.outline) {
            val op = TextPaint(tp).apply { style = Paint.Style.STROKE; strokeWidth = sw * 2; color = st.outlineColor; strokeJoin = Paint.Join.ROUND }
            lay(op).draw(cv)
        }
        if (st.shadow) tp.setShadowLayer(tp.textSize * 0.12f, 2f, 2f, 0xAA000000.toInt())
        lay(tp).draw(cv)
        cv.restore(); return bmp
    }
}

/** طبقة تراكب واحدة في التصدير (تعرض نصاً واحداً في كل لحظة) */
@UnstableApi
class LaneOverlay(private val caps: List<Caption>, private val fw: Int, private val fh: Int, private val safe: SafeZone?, private val offsetMs: Long = 0L) : BitmapOverlay() {
    private val blank = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    private val cache = HashMap<Pair<Int, Int>, Bitmap>()
    private fun cur(ms: Long) = caps.indexOfFirst { ms >= it.startMs && ms <= it.endMs }
    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000 + offsetMs; val i = cur(ms); if (i < 0) return blank
        val a = CapAnim.state(caps[i], ms)
        return cache.getOrPut(i to a.chars) { CapRender.render(caps[i], fw, fh, a.chars) }
    }
    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val ms = presentationTimeUs / 1000 + offsetMs; val i = cur(ms)
        if (i < 0) return OverlaySettings.Builder().setAlphaScale(0f).build()
        val a = CapAnim.state(caps[i], ms); val b = getBitmap(presentationTimeUs)
        val (x, y) = CapAnim.place(caps[i], b.width, b.height, fw, fh, safe, a)
        return OverlaySettings.Builder().setOverlayFrameAnchor(0f, 0f).setBackgroundFrameAnchor(x, y)
            .setScale(a.scale, a.scale).setAlphaScale(a.alpha).build()
    }
}

/** توزيع النصوص المتزامنة على طبقات بحيث لا يتداخل نصان في الطبقة نفسها */
fun captionLanes(caps: List<Caption>): List<List<Caption>> {
    val out = mutableListOf<MutableList<Caption>>()
    for (c in caps.sortedBy { it.startMs }) {
        val l = out.firstOrNull { it.last().endMs <= c.startMs } ?: mutableListOf<Caption>().also { out.add(it) }
        l.add(c)
    }
    return out
}
