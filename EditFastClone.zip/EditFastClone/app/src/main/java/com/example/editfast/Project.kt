package com.example.editfast

import android.graphics.Bitmap
import com.google.gson.Gson
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class SrcD(val path: String, val dur: Long, val ratio: Float)
data class SettingsD(
    val optSilence: Boolean, val optCaptions: Boolean, val optSfx: Boolean, val optZoom: Boolean, val filterIdx: Int, val formatIdx: Int,
    val fill: Boolean, val rotate: Int, val flip: Boolean, val resIdx: Int, val quality: Int, val capsVisible: Boolean,
    val muteOriginal: Boolean, val origVol: Float, val musicPath: String?, val musicName: String, val musicVol: Float,
    val defStyle: CapStyle, val platform: Int, val showSafe: Boolean, val clampSafe: Boolean,
    val adjB: Float, val adjC: Float, val adjS: Float, val adjW: Float, val tScale: Float, val tX: Float, val tY: Float,
    val transition: Int, val transMs: Long, val fadeEnds: Boolean, val voiceStart: Long, val hasVoice: Boolean,
    val fxShake: Boolean, val fxPulse: Boolean, val fxVignette: Boolean, val fxBars: Boolean
)
data class ProjectD(val id: Long, val name: String, val modified: Long, val sources: List<SrcD>, val clips: List<Clip>, val captions: List<Caption>, val s: SettingsD)
data class ProjectItem(val id: Long, val name: String, val modified: Long, val durationMs: Long, val thumb: String?)

/** حفظ المشروعات في ملفات داخل التطبيق (project.json + صورة مصغّرة + تعليق صوتي) */
object Projects {
    val gson = Gson()
    private fun root(ctx: android.content.Context) = File(ctx.filesDir, "projects").apply { mkdirs() }
    private fun dir(ctx: android.content.Context, id: Long) = File(root(ctx), id.toString()).apply { mkdirs() }

    fun save(ctx: android.content.Context, p: ProjectD, thumb: Bitmap?, voice: ShortArray?) {
        val d = dir(ctx, p.id)
        File(d, "project.json").writeText(gson.toJson(p))
        val tf = File(d, "thumb.jpg")
        if (thumb != null && !tf.exists()) tf.outputStream().use { thumb.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        if (voice != null) {
            val vf = File(d, "voice.pcm")
            if (vf.length() != voice.size * 2L) {
                val bb = ByteBuffer.allocate(voice.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                bb.asShortBuffer().put(voice); vf.writeBytes(bb.array())
            }
        }
    }

    fun load(ctx: android.content.Context, id: Long): ProjectD? =
        runCatching { gson.fromJson(File(dir(ctx, id), "project.json").readText(), ProjectD::class.java) }.getOrNull()

    fun loadVoice(ctx: android.content.Context, id: Long): ShortArray? {
        val f = File(dir(ctx, id), "voice.pcm"); if (!f.exists()) return null
        val sb = ByteBuffer.wrap(f.readBytes()).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        return ShortArray(sb.remaining()).also { sb.get(it) }
    }

    fun list(ctx: android.content.Context): List<ProjectItem> =
        root(ctx).listFiles()?.mapNotNull { d ->
            val f = File(d, "project.json"); if (!f.exists()) return@mapNotNull null
            runCatching {
                val p = gson.fromJson(f.readText(), ProjectD::class.java)
                ProjectItem(p.id, p.name, p.modified, p.clips.sumOf { it.outMs }, File(d, "thumb.jpg").takeIf { it.exists() }?.path)
            }.getOrNull()
        }?.sortedByDescending { it.modified }.orEmpty()

    fun delete(ctx: android.content.Context, id: Long) { dir(ctx, id).deleteRecursively() }
}
