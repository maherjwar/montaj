package com.example.editfast

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** تحليل الصوت داخل الجهاز (بدون إنترنت): شكل الموجة وكشف السكتات */
object AudioAnalyzer {
    const val WIN_MS = 50L

    /** سعة الصوت (RMS) لكل 50 مللي ثانية */
    fun amps(path: String): FloatArray {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(path)
            val ti = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true } ?: return FloatArray(0)
            ex.selectTrack(ti); val fmt = ex.getTrackFormat(ti)
            val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0); codec.start()
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var win = (sr * WIN_MS / 1000).toInt()
            val out = ArrayList<Float>(); var sumSq = 0.0; var cnt = 0
            val info = MediaCodec.BufferInfo(); var inDone = false; var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) { codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)!!
                    val chunk = ByteArray(info.size); ob.position(info.offset); ob.get(chunk)
                    val sb = ByteBuffer.wrap(chunk).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val total = sb.remaining() / ch
                    for (f in 0 until total) {
                        var m = 0; for (c in 0 until ch) m += sb.get(f * ch + c).toInt()
                        val v = m.toDouble() / ch; sumSq += v * v; cnt++
                        if (cnt >= win) { out.add((sqrt(sumSq / cnt) / 32768.0).toFloat()); sumSq = 0.0; cnt = 0 }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat; sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT); win = (sr * WIN_MS / 1000).toInt()
                }
            }
            codec.stop(); codec.release()
            return out.toFloatArray()
        } catch (e: Exception) { return FloatArray(0) } finally { ex.release() }
    }

    /** الأجزاء التي فيها كلام (تُحذف السكتات الأطول من minSilMs) */
    fun keep(amps: FloatArray, totalMs: Long, minSilMs: Long = 450, padMs: Long = 120): List<Seg> {
        if (amps.size < 10) return listOf(Seg(0, totalMs))
        val sorted = amps.sorted()
        val floor = sorted[(sorted.size * 0.15).toInt()]; val peak = sorted[min(sorted.size - 1, (sorted.size * 0.92).toInt())]
        val th = floor + (peak - floor) * 0.15f
        val segs = ArrayList<Seg>(); var s = -1L; var lastSpeech = -1L
        for (i in amps.indices) {
            val t = i * WIN_MS
            if (amps[i] > th) { if (s < 0) s = t; lastSpeech = t + WIN_MS }
            else if (s >= 0 && t - lastSpeech >= minSilMs) { segs += Seg(s, lastSpeech); s = -1 }
        }
        if (s >= 0) segs += Seg(s, lastSpeech)
        val padded = segs.map { Seg(max(0L, it.s - padMs), min(totalMs, it.e + padMs)) }
        val merged = ArrayList<Seg>()
        for (g in padded) { val l = merged.lastOrNull(); if (l != null && g.s <= l.e) merged[merged.lastIndex] = Seg(l.s, max(l.e, g.e)) else merged += g }
        return if (merged.isEmpty()) listOf(Seg(0, totalMs)) else merged
    }
}
