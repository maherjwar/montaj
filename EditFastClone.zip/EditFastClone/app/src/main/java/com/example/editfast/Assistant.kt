package com.example.editfast

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class ChatMsg(val fromUser: Boolean, val text: String)

/** مساعد المونتاج: يحوّل طلب المستخدم النصي إلى إجراءات ينفذها التطبيق (عبر نموذج لغوي على Groq) */
object Assistant {
    private fun system(): String {
        val styles = TEMPLATES.joinToString("، ") { it.first }
        return "أنت «مساعد لمسة»: مساعد مونتاج داخل تطبيق تحرير فيديو. المستخدم يكتب بالعربية (قد تكون بلهجة). حوّل طلبه إلى إجراءات ينفذها التطبيق.\n" +
            "أجب بـ JSON فقط بهذا الشكل: {\"reply\":\"رد قصير ودود بنفس لهجة المستخدم\",\"actions\":[ ... ]}\n" +
            "الإجراءات المتاحة (الحقل type):\n" +
            "- auto_edit {silence:bool, captions:bool}: مونتاج تلقائي (قص السكتات وكابشن تلقائي)\n" +
            "- add_text {text, at, dur}: إضافة نص. at بالثواني أو \"playhead\" أو \"start\" أو \"end\". dur بالثواني\n" +
            "- split {at}: تقسيم المقطع. delete_clip {at}: حذف المقطع. speed {value, at}: سرعة المقطع من 0.25 إلى 4\n" +
            "- filter {name}: بدون | حيوي | دافئ | بارد | أبيض وأسود | سينمائي\n" +
            "- format {name}: original | tiktok | youtube | square | instagram | cinema\n" +
            "- transition {name, ms}: none | fade | flash. fade_ends {value:bool}\n" +
            "- music_volume {value 0..1}، original_volume {value 0..1.5}، mute_original {value:bool}\n" +
            "- template {id, text, text2, at, dur}: قوالب موشن. id واحد من: lower (ثلث سفلي) | subscribe (زر اشتراك) | social (لايك وكومنت وشير) | counter (عدّاد، text رقم مثل 1500K) | title (عنوان) | frame (إطار تمييز)\n" +
            "- sfx {query, at}: مؤثر صوتي. query كلمة من اسم المؤثر أو تصنيفه مثل: woosh, hit, pop, ding, clk, rise, fun, tr, cash, cam\n" +
            "- caption_style {name}: تطبيق قالب على كل الكابشن، الأسماء: " + styles + "\n" +
            "- safe_zone {platform}: tiktok | reels | shorts | none (إبعاد النص عن أزرار المنصة)\n" +
            "- adjust {brightness, contrast, saturation, warmth}: قيم من -1 إلى 1\n" +
            "- undo {}: تراجع\n" +
            "قواعد: لا تخترع إجراءات خارج القائمة. إن لم تفهم اسأل سؤالاً قصيراً في reply مع actions فارغة. لا تكتب أي نص خارج JSON."
    }

    fun ask(key: String, baseUrl: String, history: List<ChatMsg>, state: String): Pair<String, JSONArray> {
        val base = baseUrl.ifBlank { "https://api.groq.com/openai/v1" }.trimEnd('/')
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system() + "\nحالة المشروع الحالية: " + state))
        for (m in history) msgs.put(JSONObject().put("role", if (m.fromUser) "user" else "assistant").put("content", m.text))
        val body = JSONObject().put("model", "llama-3.3-70b-versatile").put("messages", msgs).put("temperature", 0.2)
            .put("response_format", JSONObject().put("type", "json_object"))
        val text: String
        try {
            val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 30000; c.readTimeout = 60000
            c.setRequestProperty("Authorization", "Bearer $key"); c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code !in 200..299) throw Exception("خطأ $code: ${resp.take(120)}")
            text = JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        } catch (e: IOException) { throw Exception("تعذر الاتصال بالخدمة (قد تحتاج VPN)") }
        return try {
            val j = JSONObject(text)
            j.optString("reply", "") to (j.optJSONArray("actions") ?: JSONArray())
        } catch (e: Exception) { text.take(300) to JSONArray() }
    }
}
