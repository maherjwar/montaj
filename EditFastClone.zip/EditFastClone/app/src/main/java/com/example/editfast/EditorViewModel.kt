package com.example.editfast

import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel

data class Caption(val startMs: Long, val endMs: Long, val text: String)
data class Msg(val fromUser: Boolean, val text: String)

class EditorViewModel : ViewModel() {
    var uri by mutableStateOf<Uri?>(null)
    var durationMs by mutableLongStateOf(0L)
    var trimStart by mutableLongStateOf(0L)
    var trimEnd by mutableLongStateOf(0L)
    val captions = mutableStateListOf<Caption>()
    val messages = mutableStateListOf(Msg(false, "أهلاً! قولّي عايز المونتاج إزاي.\nأمثلة:\n• كابشن: نص الكلام هنا\n• قص من 2 إلى 8\n• امسح الكابشن"))

    fun onVideo(u: Uri, d: Long) { uri = u; durationMs = d; trimStart = 0; trimEnd = d; captions.clear() }

    private fun nums(s: String): List<Double> {
        val en = s.map { if (it in '٠'..'٩') ('0' + (it - '٠')) else it }.joinToString("")
        return Regex("\\d+(\\.\\d+)?").findAll(en).map { it.value.toDouble() }.toList()
    }

    /** مساعد بسيط يفهم أوامر نصية. استبدل هذه الدالة باستدعاء نموذج ذكاء اصطناعي (LLM) لاحقاً. */
    fun send(text: String) {
        messages += Msg(true, text)
        if (uri == null) { messages += Msg(false, "اختار فيديو الأول 🎬"); return }
        val reply = when {
            "امسح" in text || "احذف" in text -> { captions.clear(); "تم مسح الكابشن." }
            "كابشن" in text || "caption" in text.lowercase() -> {
                val body = text.substringAfter(":", text.substringAfter("كابشن")).trim()
                val words = body.split(Regex("\\s+")).filter { it.isNotBlank() }
                if (words.isEmpty()) "اكتب النص بعد النقطتين." else {
                    captions.clear()
                    val chunks = words.chunked(3)
                    val span = (trimEnd - trimStart) / chunks.size
                    chunks.forEachIndexed { i, c ->
                        captions += Caption(trimStart + i * span, trimStart + (i + 1) * span, c.joinToString(" "))
                    }
                    "تمت إضافة ${chunks.size} كابشن موزعة على الفيديو."
                }
            }
            "قص" in text || "trim" in text.lowercase() -> {
                val n = nums(text)
                if (n.size >= 2) {
                    val s = (n[0] * 1000).toLong().coerceIn(0, durationMs)
                    val e = (n[1] * 1000).toLong().coerceIn(s + 500, durationMs)
                    trimStart = s; trimEnd = e; "تم القص من ${n[0]} إلى ${n[1]} ثانية."
                } else "اكتب وقتين، مثال: قص من 2 إلى 8"
            }
            else -> "لسه بفهم أوامر الكابشن والقص والمسح بس."
        }
        messages += Msg(false, reply)
    }
}
