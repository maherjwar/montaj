package com.example.editfast

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Caption(val startMs: Long, val endMs: Long, val text: String)
data class Msg(val fromUser: Boolean, val text: String)

class EditorViewModel : ViewModel() {
    var uri by mutableStateOf<Uri?>(null)
    var durationMs by mutableLongStateOf(0L)
    var busy by mutableStateOf<String?>(null)
    var optSilence by mutableStateOf(true)
    var optCaptions by mutableStateOf(true)
    var optSfx by mutableStateOf(true)
    var optFx by mutableStateOf(true)
    val segments = mutableStateListOf<Seg>()
    val captions = mutableStateListOf<Caption>()
    val messages = mutableStateListOf(Msg(false, "اضغط «مونتاج تلقائي» أو اكتب أمراً:\n• كابشن: نص الكلام\n• قص من 2 إلى 8\n• امسح الكابشن"))

    fun onVideo(u: Uri, d: Long) {
        uri = u; durationMs = d; captions.clear(); segments.clear(); segments += Seg(0, d)
    }

    private fun nums(s: String): List<Double> {
        val en = s.map { if (it in '٠'..'٩') ('0' + (it - '٠')) else it }.joinToString("")
        return Regex("\\d+(\\.\\d+)?").findAll(en).map { it.value.toDouble() }.toList()
    }

    /** مونتاج بضغطة واحدة: تفريغ الصوت ← قص السكتات + كابشن تلقائي */
    fun autoEdit(ctx: Context) {
        val u = uri ?: return
        val p = ctx.getSharedPreferences("p", 0)
        val key = p.getString("key", "") ?: ""
        if (key.isBlank()) { messages += Msg(false, "أضف مفتاح Groq المجاني من أيقونة الإعدادات ⚙️ أولاً (console.groq.com)."); return }
        viewModelScope.launch {
            try {
                busy = "جاري تحليل الكلام..."
                val words = withContext(Dispatchers.IO) { Auto.transcribe(ctx, u, key, p.getString("lang", "ar") ?: "") }
                if (words.isEmpty()) { messages += Msg(false, "لم أجد كلاماً في الفيديو."); return@launch }
                captions.clear(); if (optCaptions) captions += Auto.captions(words)
                segments.clear()
                if (optSilence) segments += Auto.segments(words, durationMs) else segments += Seg(0, durationMs)
                val kept = segments.sumOf { it.e - it.s }
                messages += Msg(false, "تم ✅ حذفت ${"%.1f".format((durationMs - kept) / 1000.0)} ثانية من السكتات، وأضفت ${captions.size} كابشن. اضغط «تصدير» لإضافة المؤثرات والانتقالات.")
            } catch (e: Exception) {
                messages += Msg(false, "فشل: ${e.message}")
            } finally { busy = null }
        }
    }

    fun send(text: String) {
        messages += Msg(true, text)
        if (uri == null) { messages += Msg(false, "اختار فيديو الأول 🎬"); return }
        messages += Msg(false, when {
            "امسح" in text || "احذف" in text -> { captions.clear(); "تم مسح الكابشن." }
            "كابشن" in text -> {
                val words = text.substringAfter(":", text.substringAfter("كابشن")).trim().split(Regex("\\s+")).filter { it.isNotBlank() }
                if (words.isEmpty()) "اكتب النص بعد النقطتين." else {
                    captions.clear(); val chunks = words.chunked(3)
                    val a = segments.first().s; val span = (segments.last().e - a) / chunks.size
                    chunks.forEachIndexed { i, c -> captions += Caption(a + i * span, a + (i + 1) * span, c.joinToString(" ")) }
                    "تمت إضافة ${chunks.size} كابشن."
                }
            }
            "قص" in text -> {
                val n = nums(text)
                if (n.size >= 2) {
                    val s = (n[0] * 1000).toLong().coerceIn(0, durationMs); val e = (n[1] * 1000).toLong().coerceIn(s + 500, durationMs)
                    segments.clear(); segments += Seg(s, e); "تم القص من ${n[0]} إلى ${n[1]} ثانية."
                } else "اكتب وقتين، مثال: قص من 2 إلى 8"
            }
            else -> "جرّب زر «مونتاج تلقائي»، أو أوامر: كابشن، قص، امسح."
        })
    }
}
