package com.example.editfast

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Typeface
import androidx.compose.ui.graphics.asAndroidBitmap
import java.io.File
import java.util.Locale
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

/** الكابشن/النصوص على الخط الزمني للناتج (بالميلي ثانية) */
/** طبقة على الخط الزمني: نص، أو ملصق صورة (img)، أو تراكب صورة/فيديو PIP (img/vid) */
data class Caption(
    val startMs: Long, val endMs: Long, val text: String, val st: CapStyle = CapStyle(), val img: String? = null,
    val vid: String? = null, val vAspect: Float = 1f, val srcStart: Long = 0L,
    val mask: Int = 0, val bw: Float = 0f, val bc: Int = 0xFFFFFFFF.toInt(), val chroma: Boolean = false, val chromaTol: Float = 0.5f
)
data class Source(val uri: Uri, val durationMs: Long, val ratio: Float)
/** مقطع من فيديو مصدر: من s إلى e بسرعة speed */
data class Clip(val src: Int, val s: Long, val e: Long, val speed: Float = 1f, val vol: Float = 1f) { val outMs: Long get() = ((e - s) / speed).toLong() }
data class Snap(val clips: List<Clip>, val caps: List<Caption>)

data class CapStyle(
    val font: String = "sans-serif", val fontPath: String? = null, val size: Float = 1.25f,
    val color: Int = 0xFFFFEB3B.toInt(), val bold: Boolean = true, val italic: Boolean = false, val underline: Boolean = false,
    val outline: Boolean = true, val outlineColor: Int = 0xFF000000.toInt(), val outW: Float = 1f,
    val shadow: Boolean = true, val shadowAmt: Float = 1f, val shadowColor: Int = 0xAA000000.toInt(), val glow: Boolean = false, val glowColor: Int = 0,
    val grad: Boolean = false, val color2: Int = 0xFFFF4081.toInt(),
    val boxMode: Int = 0, val boxColor: Int = 0xB3000000.toInt(), val boxPad: Float = 1f, val boxR: Float = 0.9f,
    val spacing: Float = 0f, val lineSp: Float = 1f, val opacity: Float = 1f, val rot: Float = 0f,
    val anim: Int = 2, val animOut: Int = 1, val loop: Int = 0, val animMs: Long = 300, val hl: Int = 0xFF00E5FF.toInt(),
    val align: Int = 1, val maxW: Float = 0.78f, val x: Float = 0f, val y: Float = -0.5f
)

object App { lateinit var ctx: Context }

private val tfCache = HashMap<String, Typeface>()
fun CapStyle.typeface(): Typeface = tfCache.getOrPut("$font|$fontPath|$bold|$italic") {
    val fp = fontPath
    val base = try {
        when {
            fp == null -> Typeface.create(font, Typeface.NORMAL)
            fp.startsWith("asset:") -> Typeface.createFromAsset(App.ctx.assets, fp.removePrefix("asset:"))
            else -> Typeface.createFromFile(fp)
        }
    } catch (e: Exception) { Typeface.DEFAULT }
    val style = when { bold && italic -> Typeface.BOLD_ITALIC; bold -> Typeface.BOLD; italic -> Typeface.ITALIC; else -> Typeface.NORMAL }
    Typeface.create(base, style)
}

val FORMATS = listOf("الأصلي" to 0f, "TikTok / Reels / Shorts  9:16" to 9f / 16, "YouTube  16:9" to 16f / 9,
    "مربع  1:1" to 1f, "Instagram  4:5" to 0.8f, "سينمائي  21:9" to 21f / 9)
val FILTER_NAMES = listOf("بدون", "حيوي", "دافئ", "بارد", "أبيض وأسود", "سينمائي")

class EditorViewModel : ViewModel() {
    val sources = mutableStateListOf<Source>()
    val clips = mutableStateListOf<Clip>()
    val captions = mutableStateListOf<Caption>()
    val thumbs = mutableStateMapOf<Int, List<ImageBitmap>>()
    var version by mutableIntStateOf(0)           // يتغير عند تعديل المقاطع لإعادة بناء المشغّل
    var busy by mutableStateOf<String?>(null)
    var status by mutableStateOf("اضغط + لإضافة فيديو")
    var optSilence by mutableStateOf(true)
    var optCaptions by mutableStateOf(true)
    var optSfx by mutableStateOf(true)
    var optZoom by mutableStateOf(true)
    var filterIdx by mutableIntStateOf(0)
    var formatIdx by mutableIntStateOf(0)
    var fill by mutableStateOf(false)
    var rotate by mutableIntStateOf(0)
    var flip by mutableStateOf(false)
    var resIdx by mutableIntStateOf(1)
    var quality by mutableIntStateOf(2)
    var capsVisible by mutableStateOf(true)
    var muteOriginal by mutableStateOf(false)
    var origVol by mutableFloatStateOf(1f)
    var music by mutableStateOf<Uri?>(null)
    var musicName by mutableStateOf("")
    var musicVol by mutableFloatStateOf(0.3f)
    var defStyle by mutableStateOf(CapStyle())
    var platform by mutableIntStateOf(0)
    var showSafe by mutableStateOf(false)
    var clampSafe by mutableStateOf(true)
    fun safeFor(ratio: Float): SafeZone? = if (clampSafe && ratio < 0.8f) PLATFORMS[platform].second else null
    var selCap by mutableIntStateOf(-1)
    var selClip by mutableStateOf(false)
    var projectId by mutableLongStateOf(0L)
    var projectName by mutableStateOf("")
    private var lastSaved = ""
    fun clearSel() { selCap = -1; selClip = false }
    var adjB by mutableFloatStateOf(0f); var adjC by mutableFloatStateOf(0f)
    var adjS by mutableFloatStateOf(0f); var adjW by mutableFloatStateOf(0f)
    var tScale by mutableFloatStateOf(1f); var tX by mutableFloatStateOf(0f); var tY by mutableFloatStateOf(0f)
    var transition by mutableIntStateOf(0); var transMs by mutableLongStateOf(300L); var fadeEnds by mutableStateOf(false)
    var voice by mutableStateOf<ShortArray?>(null); var voiceStart by mutableLongStateOf(0L); var recording by mutableStateOf(false)
    var fxShake by mutableStateOf(false); var fxPulse by mutableStateOf(false)
    var fxVignette by mutableStateOf(false); var fxBars by mutableStateOf(false)
    fun look() = Look(filterIdx, rotate, flip, adjB, adjC, adjS, adjW, tScale, tX, tY, fxShake, fxPulse)
    fun setVolAt(t: Long, v: Float) { val i = clipAt(t); if (i < 0) return; push(4000 + i); clips[i] = clips[i].copy(vol = v) }
    fun resetAdjust() { adjB = 0f; adjC = 0f; adjS = 0f; adjW = 0f; filterIdx = 0 }
    fun resetCrop() { tScale = 1f; tX = 0f; tY = 0f }
    fun autoFitCaptions() {
        if (platform == 0) platform = 1
        clampSafe = true; showSafe = true
        setAllY(presetY(PLATFORMS[platform].second, 2))
        status = "تم ضبط مكان الكابشن داخل المنطقة الآمنة (${PLATFORMS[platform].first})"
    }

    val totalMs: Long get() = clips.sumOf { it.outMs }
    fun baseRatio(): Float { val r = sources.firstOrNull()?.ratio ?: (9f / 16); return if (rotate % 180 != 0) 1f / r else r }
    fun starts(): List<Long> { var a = 0L; return clips.map { val s = a; a += it.outMs; s } }
    fun clipAt(t: Long): Int { val st = starts(); for (i in clips.indices) if (t < st[i] + clips[i].outMs) return i; return clips.lastIndex }
    private fun bump() { version++ }

    // ---- تراجع / إعادة ----
    private val uStack = ArrayDeque<Snap>(); private val rStack = ArrayDeque<Snap>()
    var canUndo by mutableStateOf(false); var canRedo by mutableStateOf(false)
    private var lastEdit = -1
    private fun snap() = Snap(clips.toList(), captions.toList())
    private fun upd() { canUndo = uStack.isNotEmpty(); canRedo = rStack.isNotEmpty() }
    fun push(key: Int = -1) {
        if (key >= 0 && key == lastEdit) return
        lastEdit = key; uStack.addLast(snap()); if (uStack.size > 50) uStack.removeFirst(); rStack.clear(); upd()
    }
    private fun restore(s: Snap) { clips.clear(); clips += s.clips; captions.clear(); captions += s.caps; selCap = -1; lastEdit = -1; bump() }
    fun undo() { if (uStack.isEmpty()) return; rStack.addLast(snap()); restore(uStack.removeLast()); upd() }
    fun redo() { if (rStack.isEmpty()) return; uStack.addLast(snap()); restore(rStack.removeLast()); upd() }

    // ---- المصادر ----
    fun addSource(ctx: Context, u: Uri, d: Long, ratio: Float) {
        val idx = sources.size; push()
        sources += Source(u, d, ratio); clips += Clip(idx, 0, d); bump()
        status = "اضغط «لمسة الذكية» أو عدّل يدوياً"
        loadThumbs(ctx, idx, u, d)
    }

    fun loadThumbs(ctx: Context, idx: Int, u: Uri, d: Long) {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                try {
                    val r = MediaMetadataRetriever().apply { setDataSource(ctx, u) }
                    val out = (0 until 12).mapNotNull { i ->
                        r.getFrameAtTime(d * 1000L * i / 12, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let {
                            Bitmap.createScaledBitmap(it, max(1, it.width * 100 / it.height), 100, true).asImageBitmap()
                        }
                    }
                    r.release(); out
                } catch (e: Exception) { emptyList() }
            }
            thumbs[idx] = list
        }
    }

    /** تراكب صورة/فيديو فوق الفيديو (PIP) */
    fun addPip(at: Long, path: String, isVideo: Boolean, dur: Long, aspect: Float) {
        val end = if (isVideo) at + min(dur, max(1500L, totalMs - at)) else at + 3000
        addCap(Caption(at, end, "", defStyle.copy(size = 1f, boxMode = 0, anim = 2, animOut = 1, x = 0.45f, y = 0.35f),
            img = if (!isVideo) path else null, vid = if (isVideo) path else null, vAspect = aspect))
    }

    // ---- المشروعات ----
    private fun resetState() {
        sources.clear(); clips.clear(); captions.clear(); thumbs.clear(); uStack.clear(); rStack.clear(); upd()
        optSilence = true; optCaptions = true; optSfx = true; optZoom = true; filterIdx = 0; formatIdx = 0; fill = false
        rotate = 0; flip = false; resIdx = 1; quality = 2; capsVisible = true; muteOriginal = false; origVol = 1f
        music = null; musicName = ""; musicVol = 0.3f; defStyle = CapStyle(); platform = 0; showSafe = false; clampSafe = true
        adjB = 0f; adjC = 0f; adjS = 0f; adjW = 0f; tScale = 1f; tX = 0f; tY = 0f
        transition = 0; transMs = 300L; fadeEnds = false; voice = null; voiceStart = 0L
        fxShake = false; fxPulse = false; fxVignette = false; fxBars = false
        selCap = -1; selClip = false; busy = null; lastSaved = ""
    }

    fun newProject() {
        resetState(); projectId = System.currentTimeMillis()
        projectName = "مشروع " + java.text.SimpleDateFormat("MM/dd HH:mm", Locale.US).format(java.util.Date())
        status = "اضغط + لإضافة فيديو"; bump()
    }

    fun toProject(modified: Long) = ProjectD(projectId, projectName, modified,
        sources.map { SrcD(it.uri.path ?: "", it.durationMs, it.ratio) }, clips.toList(), captions.toList(),
        SettingsD(optSilence, optCaptions, optSfx, optZoom, filterIdx, formatIdx, fill, rotate, flip, resIdx, quality, capsVisible,
            muteOriginal, origVol, music?.path, musicName, musicVol, defStyle, platform, showSafe, clampSafe, adjB, adjC, adjS, adjW,
            tScale, tX, tY, transition, transMs, fadeEnds, voiceStart, voice != null, fxShake, fxPulse, fxVignette, fxBars))

    fun autosave(ctx: Context) {
        if (projectId == 0L || (clips.isEmpty() && captions.isEmpty())) return
        val core = toProject(0L)
        val key = Projects.gson.toJson(core) + (voice?.size ?: 0)
        if (key == lastSaved) return
        lastSaved = key
        try { Projects.save(ctx, core.copy(modified = System.currentTimeMillis()), thumbs[0]?.firstOrNull()?.asAndroidBitmap(), voice) } catch (e: Exception) { }
    }

    fun openProject(ctx: Context, id: Long) {
        val p = Projects.load(ctx, id) ?: run { status = "تعذر فتح المشروع"; return }
        resetState()
        p.sources.forEach { sources += Source(Uri.fromFile(File(it.path)), it.dur, it.ratio) }
        clips += p.clips; captions += p.captions
        val s = p.s
        optSilence = s.optSilence; optCaptions = s.optCaptions; optSfx = s.optSfx; optZoom = s.optZoom; filterIdx = s.filterIdx
        formatIdx = s.formatIdx; fill = s.fill; rotate = s.rotate; flip = s.flip; resIdx = s.resIdx; quality = s.quality
        capsVisible = s.capsVisible; muteOriginal = s.muteOriginal; origVol = s.origVol
        music = s.musicPath?.let { Uri.fromFile(File(it)) }; musicName = s.musicName; musicVol = s.musicVol
        defStyle = s.defStyle; platform = s.platform; showSafe = s.showSafe; clampSafe = s.clampSafe
        adjB = s.adjB; adjC = s.adjC; adjS = s.adjS; adjW = s.adjW; tScale = s.tScale; tX = s.tX; tY = s.tY
        transition = s.transition; transMs = s.transMs; fadeEnds = s.fadeEnds; voiceStart = s.voiceStart
        voice = if (s.hasVoice) Projects.loadVoice(ctx, id) else null
        fxShake = s.fxShake; fxPulse = s.fxPulse; fxVignette = s.fxVignette; fxBars = s.fxBars
        projectId = p.id; projectName = p.name
        status = "تم فتح المشروع"; bump()
        sources.forEachIndexed { i, src -> loadThumbs(ctx, i, src.uri, src.durationMs) }
    }

    // ---- ترجمات SRT ----
    private fun parseT(x: String): Long? {
        val m = Regex("(\\d+):(\\d+):(\\d+)[,.](\\d+)").find(x.trim()) ?: return null
        val (h, mi, s, ms) = m.destructured
        return ((h.toLong() * 60 + mi.toLong()) * 60 + s.toLong()) * 1000 + ms.padEnd(3, '0').take(3).toLong()
    }
    fun importSrt(text: String): Int {
        val out = mutableListOf<Caption>()
        for (b in text.replace("\r", "").trim().split(Regex("\n\\s*\n"))) {
            val lines = b.lines().filter { it.isNotBlank() }
            val ti = lines.indexOfFirst { "-->" in it }; if (ti < 0) continue
            val parts = lines[ti].split("-->"); if (parts.size < 2) continue
            val s = parseT(parts[0]); val e = parseT(parts[1]); if (s == null || e == null) continue
            out += Caption(s, e, lines.drop(ti + 1).joinToString("\n"), defStyle)
        }
        if (out.isNotEmpty()) { push(); captions += out; captions.sortBy { it.startMs } }
        return out.size
    }
    private fun ts(ms: Long) = String.format(Locale.US, "%02d:%02d:%02d,%03d", ms / 3600000, (ms / 60000) % 60, (ms / 1000) % 60, ms % 1000)
    fun toSrt(): String = captions.filter { it.img == null && it.vid == null }
        .mapIndexed { i, c -> "${i + 1}\n${ts(c.startMs)} --> ${ts(c.endMs)}\n${c.text}\n" }.joinToString("\n")

    // ---- عمليات المقاطع (على المقطع الواقع تحت المؤشر) ----
    fun split(t: Long) {
        if (clips.isEmpty()) return
        val i = clipAt(t); val c = clips[i]; val srcT = c.s + ((t - starts()[i]) * c.speed).toLong()
        if (srcT - c.s < 200 || c.e - srcT < 200) { status = "ضع المؤشر داخل المقطع للتقسيم"; return }
        push(); clips[i] = c.copy(e = srcT); clips.add(i + 1, c.copy(s = srcT)); bump()
    }
    fun deleteAt(t: Long) {
        if (clips.size <= 1) { status = "لا يمكن حذف المقطع الوحيد"; return }
        val i = clipAt(t); val a = starts()[i]; val out = clips[i].outMs; val b = a + out
        push(); clips.removeAt(i)
        val nc = captions.mapNotNull { c -> when {
            c.endMs <= a -> c
            c.startMs >= b -> c.copy(startMs = c.startMs - out, endMs = c.endMs - out)
            c.startMs >= a && c.endMs <= b -> null
            c.startMs < a -> c.copy(endMs = a)
            else -> c.copy(startMs = a, endMs = max(a + 200, c.endMs - out))
        } }
        captions.clear(); captions += nc; selCap = -1; bump()
    }
    fun duplicateAt(t: Long) { val i = clipAt(t); if (i < 0) return; push(); clips.add(i + 1, clips[i]); bump() }
    fun moveAt(t: Long, dir: Int) {
        val i = clipAt(t); val j = i + dir
        if (i < 0 || j !in clips.indices) return
        push(); val c = clips[i]; clips[i] = clips[j]; clips[j] = c; bump()
    }
    private fun shiftAfter(oldEnd: Long, delta: Long) {
        if (delta == 0L) return
        for (k in captions.indices) { val c = captions[k]; if (c.startMs >= oldEnd) captions[k] = c.copy(startMs = c.startMs + delta, endMs = c.endMs + delta) }
    }
    fun setSpeedAt(t: Long, sp: Float) {
        val i = clipAt(t); if (i < 0) return; push(); val old = clips[i].outMs; val st = starts()[i]
        clips[i] = clips[i].copy(speed = sp); shiftAfter(st + old, clips[i].outMs - old); bump()
    }
    fun setTrimAt(t: Long, s: Long, e: Long) {
        val i = clipAt(t); if (i < 0) return; val c = clips[i]; val dur = sources[c.src].durationMs
        val ns = s.coerceIn(0, dur); val ne = e.coerceIn(ns + 200, dur)
        push(3000 + i); val old = c.outMs; val st = starts()[i]
        clips[i] = c.copy(s = ns, e = ne); shiftAfter(st + old, clips[i].outMs - old); bump()
    }

    // ---- الكابشن والنصوص والملصقات ----
    fun modCap(i: Int, key: Int = -1, f: (Caption) -> Caption) { if (i in captions.indices) { push(key); captions[i] = f(captions[i]) } }
    fun editCaption(i: Int, t: String) = modCap(i, i) { it.copy(text = t) }
    fun setCaptionTime(i: Int, s: Long, e: Long) = modCap(i, 1000 + i) { it.copy(startMs = s, endMs = max(e, s + 200)) }
    fun updStyle(i: Int, f: (CapStyle) -> CapStyle) = modCap(i, 5000 + i) { it.copy(st = f(it.st)) }
    fun moveCap(i: Int, dx: Float, dy: Float, z: Float) = updStyle(i) {
        it.copy(x = (it.x + dx).coerceIn(-1f, 1f), y = (it.y + dy).coerceIn(-1f, 1f), size = (it.size * z).coerceIn(0.3f, 4f))
    }
    fun splitCaption(i: Int, t: Long) {
        val c = captions.getOrNull(i) ?: return
        if (t <= c.startMs + 150 || t >= c.endMs - 150) { status = "ضع المؤشر داخل النص لتقسيمه"; return }
        push(); captions[i] = c.copy(endMs = t); captions.add(i + 1, c.copy(startMs = t)); selCap = i
    }
    fun removeCaption(i: Int) { if (i in captions.indices) { push(); captions.removeAt(i); selCap = -1 } }
    fun duplicateCap(i: Int) {
        if (i !in captions.indices) return
        push(); val c = captions[i]; captions.add(i + 1, c.copy(startMs = c.endMs, endMs = c.endMs + (c.endMs - c.startMs))); selCap = i + 1
    }
    private fun addCap(c: Caption) { push(); captions += c; captions.sortBy { it.startMs }; selCap = captions.indexOf(c) }
    fun addCaption(at: Long, text: String = "نص جديد") = addCap(Caption(at, min(at + 2000, max(totalMs, at + 500)), text, defStyle))
    fun addEmoji(at: Long, e: String) = addCap(Caption(at, at + 2000, e, defStyle.copy(size = 3f, boxMode = 0, outline = false, shadow = false, anim = 2, y = 0.1f)))
    fun addSticker(at: Long, path: String) = addCap(Caption(at, at + 2500, "", defStyle.copy(size = 1.4f, boxMode = 0, anim = 2, y = 0.1f), path))
    fun applyStyleToAll(i: Int) {
        if (i !in captions.indices) return
        push(); val s = captions[i].st
        for (k in captions.indices) if (captions[k].img == null) captions[k] = captions[k].copy(st = s.copy(x = captions[k].st.x, y = captions[k].st.y))
        defStyle = s
    }
    fun setAllY(y: Float) {
        push(); for (k in captions.indices) if (captions[k].img == null) captions[k] = captions[k].copy(st = captions[k].st.copy(y = y, x = 0f))
        defStyle = defStyle.copy(y = y, x = 0f)
    }

    private fun srcToOut(list: List<Clip>, src: Int, t: Long): Long? {
        var a = 0L
        for (c in list) { if (c.src == src && t >= c.s && t < c.e) return a + ((t - c.s) / c.speed).toLong(); a += c.outMs }
        return null
    }

    /** مونتاج بضغطة واحدة على أول فيديو: تفريغ الصوت ← قص السكتات + كابشن تلقائي */
    fun autoEdit(ctx: Context) {
        val src = sources.firstOrNull() ?: return
        val p = ctx.getSharedPreferences("p", 0)
        val key = (p.getString("key", "") ?: "").ifBlank { BuildConfig.GROQ_KEY }
        if (key.isBlank()) { status = "لا يوجد مفتاح: أضفه من ⚙️ الإعدادات"; return }
        viewModelScope.launch {
            try {
                busy = "جاري تحليل الكلام..."
                val words = withContext(Dispatchers.IO) { Auto.transcribe(ctx, src.uri, key, p.getString("lang", "ar") ?: "", p.getString("url", "") ?: "") }
                if (words.isEmpty()) { status = "لم أجد كلاماً في الفيديو"; return@launch }
                push()
                val segs = if (optSilence) Auto.segments(words, src.durationMs) else listOf(Seg(0, src.durationMs))
                val nc = segs.map { Clip(0, it.s, it.e) }
                captions.clear()
                if (optCaptions) Auto.captions(words).forEach { c ->
                    srcToOut(nc, 0, c.startMs)?.let { o -> captions += Caption(o, o + (c.endMs - c.startMs), c.text, defStyle) }
                }
                clips.clear(); clips += nc; bump()
                val kept = nc.sumOf { it.e - it.s }
                status = "تم ✅ حذف ${"%.1f".format((src.durationMs - kept) / 1000.0)}ث من السكتات • ${captions.size} كابشن"
            } catch (e: Exception) { status = "فشل: ${e.message}" } finally { busy = null }
        }
    }
}
