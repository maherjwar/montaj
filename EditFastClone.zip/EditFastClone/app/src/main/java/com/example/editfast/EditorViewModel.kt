package com.example.editfast

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.min

data class Caption(val startMs: Long, val endMs: Long, val text: String)

/** ستايل الكابشن: الخط، الحجم، اللون، الخلفية، الموضع (0 أعلى، 1 وسط، 2 أسفل) */
data class CapStyle(
    val font: String = "sans-serif", val fontPath: String? = null, val size: Float = 1f,
    val color: Int = 0xFFFFEB3B.toInt(), val bg: Int = 0, val bold: Boolean = true, val pos: Int = 2
)

fun CapStyle.typeface(): Typeface {
    val base = try { if (fontPath != null) Typeface.createFromFile(fontPath) else Typeface.create(font, Typeface.NORMAL) }
    catch (e: Exception) { Typeface.DEFAULT }
    return Typeface.create(base, if (bold) Typeface.BOLD else Typeface.NORMAL)
}

class EditorViewModel : ViewModel() {
    var uri by mutableStateOf<Uri?>(null)
    var durationMs by mutableLongStateOf(0L)
    var busy by mutableStateOf<String?>(null)
    var status by mutableStateOf("اختر فيديو للبدء")
    var optSilence by mutableStateOf(true)
    var optCaptions by mutableStateOf(true)
    var optSfx by mutableStateOf(true)
    var optZoom by mutableStateOf(true)
    var optGrade by mutableStateOf(true)
    var style by mutableStateOf(CapStyle())
    val segments = mutableStateListOf<Seg>()
    val captions = mutableStateListOf<Caption>()

    fun onVideo(u: Uri, d: Long) {
        uri = u; durationMs = d; captions.clear(); segments.clear(); segments += Seg(0, d)
        status = "اضغط «مونتاج تلقائي» أو عدّل يدوياً"
    }
    fun editCaption(i: Int, t: String) { if (i in captions.indices) captions[i] = captions[i].copy(text = t) }
    fun removeCaption(i: Int) { if (i in captions.indices) captions.removeAt(i) }
    fun addCaption(at: Long) { captions += Caption(at, min(at + 2000, durationMs), "نص جديد"); captions.sortBy { it.startMs } }
    fun setRange(s: Long, e: Long) { segments.clear(); segments += Seg(s, e) }

    /** مونتاج بضغطة واحدة: تفريغ الصوت ← قص السكتات + كابشن تلقائي */
    fun autoEdit(ctx: Context) {
        val u = uri ?: return
        val p = ctx.getSharedPreferences("p", 0)
        val key = p.getString("key", "") ?: ""
        if (key.isBlank()) { status = "أضف مفتاح Groq المجاني من ⚙️ الإعدادات أولاً"; return }
        viewModelScope.launch {
            try {
                busy = "جاري تحليل الكلام..."
                val words = withContext(Dispatchers.IO) { Auto.transcribe(ctx, u, key, p.getString("lang", "ar") ?: "") }
                if (words.isEmpty()) { status = "لم أجد كلاماً في الفيديو"; return@launch }
                captions.clear(); if (optCaptions) captions += Auto.captions(words)
                segments.clear()
                if (optSilence) segments += Auto.segments(words, durationMs) else segments += Seg(0, durationMs)
                val kept = segments.sumOf { it.e - it.s }
                status = "تم ✅ حذف ${"%.1f".format((durationMs - kept) / 1000.0)}ث من السكتات • ${captions.size} كابشن"
            } catch (e: Exception) { status = "فشل: ${e.message}" } finally { busy = null }
        }
    }
}
