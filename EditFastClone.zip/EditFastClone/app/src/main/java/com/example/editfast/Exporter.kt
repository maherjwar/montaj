package com.example.editfast

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.TypefaceSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.*
import androidx.media3.transformer.*
import com.google.common.collect.ImmutableList
import java.io.File

@UnstableApi
private class CaptionOverlay(val caps: List<Caption>, val offsetMs: Long, val st: CapStyle) : TextOverlay() {
    private val tf = st.typeface()
    override fun getText(presentationTimeUs: Long): SpannableString {
        val ms = presentationTimeUs / 1000 + offsetMs
        val t = caps.firstOrNull { ms in it.startMs..it.endMs }?.text ?: " "
        return SpannableString(t).apply {
            setSpan(ForegroundColorSpan(st.color), 0, length, 0)
            setSpan(TypefaceSpan(tf), 0, length, 0)
            if (st.bg != 0 && t != " ") setSpan(BackgroundColorSpan(st.bg), 0, length, 0)
            setSpan(RelativeSizeSpan(3.2f * st.size), 0, length, 0)
        }
    }
    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().setBackgroundFrameAnchor(0f, listOf(0.6f, 0f, -0.55f)[st.pos]).build()
}

data class ExportSpec(
    val uris: List<Uri>, val clips: List<Clip>, val caps: List<Caption>, val st: CapStyle,
    val zoom: Boolean, val filter: Int, val sfx: Boolean, val muteOrig: Boolean, val origVol: Float,
    val music: Uri?, val musicVol: Float, val fmtRatio: Float, val baseRatio: Float,
    val rotate: Int, val flip: Boolean, val fill: Boolean, val shortSide: Int, val bitrate: Int
)

@UnstableApi
fun filterEffects(i: Int): List<Effect> = when (i) {
    1 -> listOf(Contrast(0.12f), HslAdjustment.Builder().adjustSaturation(18f).build())
    2 -> listOf(RgbAdjustment.Builder().setRedScale(1.1f).setBlueScale(0.88f).build(), HslAdjustment.Builder().adjustSaturation(8f).build())
    3 -> listOf(RgbAdjustment.Builder().setRedScale(0.92f).setBlueScale(1.12f).build())
    4 -> listOf(HslAdjustment.Builder().adjustSaturation(-100f).build(), Contrast(0.15f))
    5 -> listOf(Contrast(0.25f), HslAdjustment.Builder().adjustSaturation(-12f).build(), RgbAdjustment.Builder().setRedScale(1.03f).setBlueScale(1.05f).build())
    else -> emptyList()
}

@UnstableApi
fun geoEffects(rot: Int, flip: Boolean): List<Effect> =
    if (rot == 0 && !flip) emptyList()
    else listOf(ScaleAndRotateTransformation.Builder().setRotationDegrees(rot.toFloat()).setScale(if (flip) -1f else 1f, 1f).build())

@UnstableApi
fun previewEffects(filter: Int, rot: Int, flip: Boolean): List<Effect> = geoEffects(rot, flip) + filterEffects(filter)

@UnstableApi
private fun volumeProc(v: Float) = ChannelMixingAudioProcessor().apply {
    putChannelMixingMatrix(ChannelMixingMatrix.create(1, 2).scaleBy(v))
    putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v))
}

/** قص + سرعة + زووم + دوران/قلب + فلتر + حجم/دقة + كابشن + مؤثرات + موسيقى */
@UnstableApi
fun exportVideo(ctx: Context, sp: ExportSpec, done: (Result<Uri>) -> Unit): Transformer {
    val total = sp.clips.sumOf { it.outMs }
    val eff = if (sp.fmtRatio > 0) sp.fmtRatio else sp.baseRatio
    val hpx = (if (eff < 1f) sp.shortSide / eff else sp.shortSide.toFloat()).toInt().let { it - it % 2 }
    val items = sp.clips.mapIndexed { i, c ->
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()
        val item = MediaItem.Builder().setUri(sp.uris[c.src]).setClippingConfiguration(clip).build()
        val v = mutableListOf<Effect>(); val a = mutableListOf<AudioProcessor>()
        if (c.speed != 1f) { v += SpeedChangeEffect(c.speed); a += SonicAudioProcessor().apply { setSpeed(c.speed); setPitch(1f) } }
        if (sp.origVol != 1f) a += volumeProc(sp.origVol)
        if (sp.zoom) {
            val base = if (i % 2 == 0) 1.0f else 1.12f
            val punch = if (i == 0) 0f else 0.22f
            v += MatrixTransformation { t ->
                val p = (1f - (t / 1000f) / 350f).coerceAtLeast(0f)
                val sc = base + punch * p
                Matrix().apply { postScale(sc, sc) }
            }
        }
        v += geoEffects(sp.rotate, sp.flip)
        v += filterEffects(sp.filter)
        if (sp.fmtRatio > 0) v += Presentation.createForAspectRatio(sp.fmtRatio,
            if (sp.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT)
        v += Presentation.createForHeight(hpx)
        EditedMediaItem.Builder(item).setRemoveAudio(sp.muteOrig).setEffects(Effects(a, v)).build()
    }
    val seqs = mutableListOf(EditedMediaItemSequence(items))
    if (sp.sfx) {
        val ev = mutableListOf<Triple<Long, ShortArray, Float>>()
        val wh = Sfx.whoosh(); val pp = Sfx.pop(); var out = 0L
        sp.clips.forEachIndexed { i, c -> if (i > 0) ev += Triple(out - 120, wh, 0.8f); out += c.outMs }
        sp.caps.forEach { ev += Triple(it.startMs, pp, 0.25f) }
        val wav = Sfx.render(ctx, total - 50, ev)
        seqs += EditedMediaItemSequence(listOf(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).build()))
    }
    if (sp.music != null) {
        val mi = MediaItem.Builder().setUri(sp.music)
            .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setEndPositionMs(total).build()).build()
        seqs += EditedMediaItemSequence(listOf(EditedMediaItem.Builder(mi).setRemoveVideo(true)
            .setEffects(Effects(listOf(volumeProc(sp.musicVol)), emptyList())).build()))
    }
    val cb = Composition.Builder(seqs)
    if (sp.caps.isNotEmpty()) cb.setEffects(Effects(emptyList(), listOf(OverlayEffect(ImmutableList.of(CaptionOverlay(sp.caps, 0L, sp.st))))))
    val out = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")
    val enc = DefaultEncoderFactory.Builder(ctx)
        .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(sp.bitrate).build()).build()
    val tr = Transformer.Builder(ctx).setEncoderFactory(enc).addListener(object : Transformer.Listener {
        override fun onCompleted(c: Composition, r: ExportResult) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, out.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/EditFast")
            }
            val dst = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            if (dst == null) { done(Result.failure(Exception("تعذر الحفظ"))); return }
            ctx.contentResolver.openOutputStream(dst)!!.use { o -> out.inputStream().use { it.copyTo(o) } }
            out.delete(); done(Result.success(dst))
        }
        override fun onError(c: Composition, r: ExportResult, ex: ExportException) = done(Result.failure(ex))
    }).build()
    tr.start(cb.build(), out.absolutePath)
    return tr
}
