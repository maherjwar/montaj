package com.example.editfast

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.*
import com.google.common.collect.ImmutableList
import java.io.File

@UnstableApi
private class CaptionOverlay(val caps: List<Caption>, val offsetMs: Long) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val ms = presentationTimeUs / 1000 + offsetMs
        val t = caps.firstOrNull { ms in it.startMs..it.endMs }?.text ?: " "
        return SpannableString(t).apply {
            setSpan(ForegroundColorSpan(Color.WHITE), 0, length, 0)
            setSpan(RelativeSizeSpan(3f), 0, length, 0)
        }
    }
    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.6f).build()
}

@UnstableApi
fun exportVideo(ctx: Context, uri: Uri, s: Long, e: Long, caps: List<Caption>, done: (Result<Uri>) -> Unit) {
    val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(s).setEndPositionMs(e).build()
    val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build()
    val effects = if (caps.isEmpty()) Effects.EMPTY
    else Effects(listOf(), listOf(OverlayEffect(ImmutableList.of(CaptionOverlay(caps, s)))))
    val edited = EditedMediaItem.Builder(item).setEffects(effects).build()
    val out = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")
    Transformer.Builder(ctx).addListener(object : Transformer.Listener {
        override fun onCompleted(c: Composition, r: ExportResult) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, out.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/EditFast")
            }
            val dst = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            if (dst == null) { done(Result.failure(Exception("تعذر الحفظ"))); return }
            ctx.contentResolver.openOutputStream(dst)!!.use { o -> out.inputStream().use { it.copyTo(o) } }
            out.delete(); done(Result.success(dst))
        }
        override fun onError(c: Composition, r: ExportResult, ex: ExportException) = done(Result.failure(ex))
    }).build().start(edited, out.absolutePath)
}
