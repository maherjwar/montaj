package com.example.editfast

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.*
import androidx.media3.transformer.*
import com.google.common.collect.ImmutableList
import java.io.File

@UnstableApi
private class CaptionOverlay(val caps: List<Caption>, val offsetMs: Long) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val ms = presentationTimeUs / 1000 + offsetMs
        val t = caps.firstOrNull { ms in it.startMs..it.endMs }?.text ?: " "
        return SpannableString(t).apply {
            setSpan(ForegroundColorSpan(Color.YELLOW), 0, length, 0)
            setSpan(StyleSpan(android.graphics.Typeface.BOLD), 0, length, 0)
            setSpan(RelativeSizeSpan(3.2f), 0, length, 0)
        }
    }
    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.55f).build()
}

/** fx = زووم عند كل قطع (انتقال) + تدرج ألوان، sfx = مؤثرات صوتية عند القطع والكابشن */
@UnstableApi
fun exportVideo(ctx: Context, uri: Uri, segs: List<Seg>, caps: List<Caption>, fx: Boolean, sfx: Boolean, done: (Result<Uri>) -> Unit) {
    val items = segs.mapIndexed { i, sg ->
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(sg.s).setEndPositionMs(sg.e).build()
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build()
        val v = mutableListOf<Effect>()
        if (fx) {
            val base = if (i % 2 == 0) 1.0f else 1.12f
            val punch = if (i == 0) 0f else 0.22f
            v += MatrixTransformation { t ->
                val p = (1f - (t / 1000f) / 350f).coerceAtLeast(0f)
                val sc = base + punch * p
                Matrix().apply { postScale(sc, sc) }
            }
            v += Contrast(0.12f)
            v += HslAdjustment.Builder().adjustSaturation(18f).build()
        }
        val c = caps.filter { it.endMs > sg.s && it.startMs < sg.e }
        if (c.isNotEmpty()) v += OverlayEffect(ImmutableList.of(CaptionOverlay(c, sg.s)))
        EditedMediaItem.Builder(item).setEffects(Effects(emptyList(), v)).build()
    }
    val seqs = mutableListOf(EditedMediaItemSequence(items))
    if (sfx) {
        val ev = mutableListOf<Triple<Long, ShortArray, Float>>()
        val wh = Sfx.whoosh(); val pp = Sfx.pop(); var out = 0L
        segs.forEachIndexed { i, sg ->
            if (i > 0) ev += Triple(out - 120, wh, 0.8f)
            caps.filter { it.startMs >= sg.s && it.startMs < sg.e }.forEach { ev += Triple(out + it.startMs - sg.s, pp, 0.25f) }
            out += sg.e - sg.s
        }
        val wav = Sfx.render(ctx, out - 50, ev)
        seqs += EditedMediaItemSequence(listOf(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).build()))
    }
    val out = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")
    Transformer.Builder(ctx).addListener(object : Transformer.Listener {
        override fun onCompleted(c: Composition, r: ExportResult) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, out.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/EditFast")
            }
            val dst = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            if (dst == null) { done(Result.failure(Exception("تعذر الحفظ"))); return }
            ctx.contentResolver.openOutputStream(dst)!!.use { o -> out.inputStream().use { it.copyTo(o) } }
            out.delete(); done(Result.success(dst))
        }
        override fun onError(c: Composition, r: ExportResult, ex: ExportException) = done(Result.failure(ex))
    }).build().start(Composition.Builder(seqs).build(), out.absolutePath)
}
