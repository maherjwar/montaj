package com.example.editfast

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.TypefaceSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.*
import androidx.media3.transformer.*
import com.google.common.collect.ImmutableList
import java.io.File
import kotlin.math.*
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader

data class ExportSpec(
    val uris: List<Uri>, val clips: List<Clip>, val caps: List<Caption>,
    val zoom: Boolean, val filter: Int, val sfx: Boolean, val muteOrig: Boolean, val origVol: Float,
    val music: Uri?, val musicVol: Float, val fmtRatio: Float, val baseRatio: Float,
    val rotate: Int, val flip: Boolean, val fill: Boolean, val shortSide: Int, val bitrate: Int, val safe: SafeZone?,
    val look: Look, val transition: Int, val transMs: Long, val fadeEnds: Boolean, val voice: ShortArray?, val voiceStart: Long,
    val vignette: Boolean, val bars: Boolean, val sfxEvents: List<SfxEvt> = emptyList()
)

@UnstableApi
fun filterEffects(i: Int): List<Effect> = when (i) {
    1 -> listOf(Contrast(0.12f), HslAdjustment.Builder().adjustSaturation(18f).build())
    2 -> listOf(RgbAdjustment.Builder().setRedScale(1.1f).setBlueScale(0.88f).build(), HslAdjustment.Builder().adjustSaturation(8f).build())
    3 -> listOf(RgbAdjustment.Builder().setRedScale(0.92f).setBlueScale(1.12f).build())
    4 -> listOf(HslAdjustment.Builder().adjustSaturation(-100f).build(), Contrast(0.15f))
    5 -> listOf(Contrast(0.25f), HslAdjustment.Builder().adjustSaturation(-12f).build(), RgbAdjustment.Builder().setRedScale(1.03f).setBlueScale(1.05f).build())
    else -> emptyList()
}

@UnstableApi
fun geoEffects(rot: Int, flip: Boolean): List<Effect> =
    if (rot == 0 && !flip) emptyList()
    else listOf(ScaleAndRotateTransformation.Builder().setRotationDegrees(rot.toFloat()).setScale(if (flip) -1f else 1f, 1f).build())

data class Look(
    val filter: Int = 0, val rot: Int = 0, val flip: Boolean = false,
    val b: Float = 0f, val c: Float = 0f, val s: Float = 0f, val w: Float = 0f,
    val sc: Float = 1f, val tx: Float = 0f, val ty: Float = 0f, val shake: Boolean = false, val pulse: Boolean = false
)

/** كل مؤثرات المظهر: تدوير/قلب، تكبير وتحريك، فلتر، سطوع/تباين/تشبع/دفء */
@UnstableApi
fun lookEffects(l: Look): List<Effect> {
    val out = mutableListOf<Effect>()
    if (l.rot != 0 || l.flip) out += ScaleAndRotateTransformation.Builder().setRotationDegrees(l.rot.toFloat()).setScale(if (l.flip) -1f else 1f, 1f).build()
    if (l.sc != 1f || l.tx != 0f || l.ty != 0f) out += MatrixTransformation { Matrix().apply { postScale(l.sc, l.sc); postTranslate(l.tx, l.ty) } }
    if (l.shake || l.pulse) out += MatrixTransformation { t ->
        val s = t / 1_000_000f; var sc = 1f; var dx = 0f; var dy = 0f
        if (l.pulse) sc *= 1f + 0.05f * abs(sin(s * 5f))
        if (l.shake) { sc *= 1.05f; dx = 0.014f * sin(s * 47f); dy = 0.014f * cos(s * 53f) }
        Matrix().apply { postScale(sc, sc); postTranslate(dx, dy) }
    }
    out += filterEffects(l.filter)
    if (l.b != 0f) out += Brightness(l.b)
    if (l.c != 0f) out += Contrast(l.c)
    if (l.s != 0f) out += HslAdjustment.Builder().adjustSaturation(l.s * 100f).build()
    if (l.w != 0f) out += RgbAdjustment.Builder().setRedScale(1f + 0.25f * l.w).setBlueScale(1f - 0.25f * l.w).build()
    return out
}

@UnstableApi
fun previewEffects(filter: Int, rot: Int, flip: Boolean): List<Effect> = geoEffects(rot, flip) + filterEffects(filter)

@UnstableApi
private fun volumeProc(v: Float) = ChannelMixingAudioProcessor().apply {
    putChannelMixingMatrix(ChannelMixingMatrix.create(1, 2).scaleBy(v))
    putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v))
}

/** قص + سرعة + زووم + دوران/قلب + فلتر + حجم/دقة + كابشن + مؤثرات + موسيقى */
@UnstableApi
fun exportVideo(ctx: Context, sp: ExportSpec, done: (Result<Uri>) -> Unit): Transformer {
    val total = sp.clips.sumOf { it.outMs }
    val eff = if (sp.fmtRatio > 0) sp.fmtRatio else sp.baseRatio
    val hpx = (if (eff < 1f) sp.shortSide / eff else sp.shortSide.toFloat()).toInt().let { it - it % 2 }
    val fxBmp: Bitmap? = if (sp.vignette || sp.bars) Bitmap.createBitmap(outW0(sp, eff, hpx), hpx, Bitmap.Config.ARGB_8888).also { b ->
        val cv = Canvas(b); val w = b.width.toFloat(); val h = b.height.toFloat()
        if (sp.vignette) cv.drawRect(0f, 0f, w, h, Paint().apply {
            shader = RadialGradient(w / 2, h / 2, hypot(w, h) / 2, intArrayOf(0x00000000, 0x00000000, 0xB0000000.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        })
        if (sp.bars) { val p = Paint().apply { color = 0xFF000000.toInt() }; cv.drawRect(0f, 0f, w, h * 0.11f, p); cv.drawRect(0f, h * 0.89f, w, h, p) }
    } else null
    val outStarts = run { var a = 0L; sp.clips.map { val st = a; a += it.outMs; st } }
    val outW = (hpx * eff).toInt().let { it - it % 2 }
    val safeZ = if (eff < 0.8f) sp.safe else null
    val items = sp.clips.mapIndexed { i, c ->
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()
        val item = MediaItem.Builder().setUri(sp.uris[c.src]).setClippingConfiguration(clip).build()
        val v = mutableListOf<Effect>(); val a = mutableListOf<AudioProcessor>()
        if (c.speed != 1f) { v += SpeedChangeEffect(c.speed); a += SonicAudioProcessor().apply { setSpeed(c.speed); setPitch(1f) } }
        val vv = sp.origVol * c.vol
        if (vv != 1f) a += volumeProc(vv)
        if (sp.zoom) {
            val base = if (i % 2 == 0) 1.0f else 1.12f
            val punch = if (i == 0) 0f else 0.22f
            v += MatrixTransformation { t ->
                val p = (1f - (t / 1000f) / 350f).coerceAtLeast(0f)
                val sc = base + punch * p
                Matrix().apply { postScale(sc, sc) }
            }
        }
        v += lookEffects(sp.look)
        // انتقال تلاشي/وميض عند حدود المقاطع، وتلاشي البداية والنهاية
        val last = i == sp.clips.lastIndex
        val inOn = (i > 0 && sp.transition != 0) || (i == 0 && sp.fadeEnds)
        val outOn = (!last && sp.transition != 0) || (last && sp.fadeEnds)
        if (inOn || outOn) {
            val dur = c.outMs.toFloat(); val d = max(1L, sp.transMs).toFloat(); val white = sp.transition == 2
            v += object : RgbMatrix {
                override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
                    val ms = presentationTimeUs / 1000f; var f = 0f
                    if (inOn) f = max(f, 1f - ms / d)
                    if (outOn) f = max(f, 1f - (dur - ms) / d)
                    f = f.coerceIn(0f, 1f)
                    val m = FloatArray(16); m[0] = 1f - f; m[5] = 1f - f; m[10] = 1f - f; m[15] = 1f
                    if (white) { m[12] = f; m[13] = f; m[14] = f }
                    return m
                }
            }
        }
        if (sp.fmtRatio > 0) v += Presentation.createForAspectRatio(sp.fmtRatio,
            if (sp.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT)
        v += Presentation.createForHeight(hpx)
        if (fxBmp != null) v += OverlayEffect(ImmutableList.of<TextureOverlay>(StaticOverlay(fxBmp)))
        val c0 = outStarts[i]; val c1 = c0 + c.outMs
        val here = sp.caps.filter { it.endMs > c0 && it.startMs < c1 }
        if (here.isNotEmpty()) {
            val ob = ImmutableList.builder<TextureOverlay>()
            captionLanes(here).forEach { ob.add(LaneOverlay(it, outW, hpx, safeZ, c0)) }
            v += OverlayEffect(ob.build())
        }
        EditedMediaItem.Builder(item).setRemoveAudio(sp.muteOrig).setEffects(Effects(a, v)).build()
    }
    val seqs = mutableListOf(EditedMediaItemSequence(items))
    if (sp.sfx || sp.voice != null || sp.sfxEvents.isNotEmpty()) {
        val ev = mutableListOf<Triple<Long, ShortArray, Float>>()
        if (sp.sfx) {
            val wh = Sfx.whoosh(); val pp = Sfx.pop(); var out = 0L
            sp.clips.forEachIndexed { i, c -> if (i > 0) ev += Triple(out - 120, wh, 0.8f); out += c.outMs }
            sp.caps.forEach { ev += Triple(it.startMs, pp, 0.25f) }
        }
        sp.voice?.let { ev += Triple(sp.voiceStart, it, 1f) }
        sp.sfxEvents.forEach { e -> val pcm = SfxLib.pcm(ctx, e.id); if (pcm.isNotEmpty()) ev += Triple(e.t, pcm, e.vol) }
        val wav = Sfx.render(ctx, total - 50, ev)
        seqs += EditedMediaItemSequence(listOf(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).build()))
    }
    if (sp.music != null) {
        val mi = MediaItem.Builder().setUri(sp.music)
            .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setEndPositionMs(total).build()).build()
        seqs += EditedMediaItemSequence(listOf(EditedMediaItem.Builder(mi).setRemoveVideo(true)
            .setEffects(Effects(listOf(volumeProc(sp.musicVol)), emptyList())).build()))
    }
    val cb = Composition.Builder(seqs)
    val out = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")
    val enc = DefaultEncoderFactory.Builder(ctx)
        .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(sp.bitrate).build()).build()
    val tr = Transformer.Builder(ctx).setEncoderFactory(enc).addListener(object : Transformer.Listener {
        override fun onCompleted(c: Composition, r: ExportResult) {
            PipFrames.release()
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, out.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/EditFast")
            }
            val dst = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            if (dst == null) { done(Result.failure(Exception("تعذر الحفظ"))); return }
            ctx.contentResolver.openOutputStream(dst)!!.use { o -> out.inputStream().use { it.copyTo(o) } }
            out.delete(); done(Result.success(dst))
        }
        override fun onError(c: Composition, r: ExportResult, ex: ExportException) { PipFrames.release(); done(Result.failure(ex)) }
    }).build()
    tr.start(cb.build(), out.absolutePath)
    return tr
}

private fun outW0(sp: ExportSpec, eff: Float, hpx: Int) = (hpx * eff).toInt().let { it - it % 2 }.coerceAtLeast(2)

/** صورة ثابتة بحجم الإطار (فينيت / أشرطة سينمائية) */
@UnstableApi
private class StaticOverlay(private val bmp: Bitmap) : BitmapOverlay() {
    override fun getBitmap(presentationTimeUs: Long): Bitmap = bmp
}
