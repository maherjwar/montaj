package com.example.editfast

import android.graphics.BitmapFactory
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

val GOLD_BRUSH = Brush.horizontalGradient(listOf(Color(0xFFF7D98A), Color(0xFFE8B84B)))
val AI_BRUSH = Brush.horizontalGradient(listOf(TEAL, PINK))

@Composable
private fun Badge(text: String, color: Color) {
    Text(text, color = color, fontSize = 10.sp, modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.16f)).padding(horizontal = 7.dp, vertical = 3.dp))
}

@Composable
private fun ToolTile(icon: ImageVector, label: String, tint: Color, badge: String?, badgeColor: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp)) {
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(22.dp)).background(tint.copy(alpha = 0.14f)).border(1.dp, tint.copy(alpha = 0.35f), RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(30.dp)) }
            if (badge != null) Box(Modifier.align(Alignment.TopStart).offset(y = (-6).dp)) { Badge(badge, badgeColor) }
        }
        Text(label, color = Color(0xFFD8D4E3), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun HomeScreen(recent: List<ProjectItem>, onStart: (String?, String?) -> Unit, onOpen: (Long) -> Unit, onAllProjects: () -> Unit, onSettings: () -> Unit) {
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greet = if (hour < 12) "صباح الخير" else if (hour < 18) "طاب يومك" else "مساء الخير"
    var prompt by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize()) {
        GlowBackground()
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(horizontal = 20.dp).padding(bottom = 130.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    LogoMark(44.dp); Spacer(Modifier.width(10.dp)); Text("لمسة", color = Color.White, fontSize = 24.sp)
                }
                IconButton(onSettings) { Icon(Icons.Default.Settings, null, tint = Color(0xFFD8D4E3)) }
            }
            Spacer(Modifier.height(26.dp))
            Text("$greet 👋", color = Color(0xFFA9A3B8), fontSize = 15.sp)
            Text("هيا نصنع فيديو يخطف الأنظار", color = Color(0xFFFFF5E6), fontSize = 30.sp, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                // بطاقة الذكاء الاصطناعي
                Column(Modifier.weight(1f).height(250.dp).clip(RoundedCornerShape(28.dp)).background(Brush.verticalGradient(listOf(Color(0xFF241733), Color(0xFF14101D))))
                    .border(1.5.dp, Color(0xFF6A3F85), RoundedCornerShape(28.dp)).clickable { onStart(null, "ai") }.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                        AiRing(64.dp); Spacer(Modifier.weight(1f))
                        Text("AI", color = Color.White, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(AI_BRUSH).padding(horizontal = 9.dp, vertical = 4.dp))
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("لمسة الذكية\nتمنتج لك", color = Color.White, fontSize = 20.sp, lineHeight = 26.sp)
                    Text("قل ما تريد وهي تنفّذ المونتاج كله", color = Color(0xFF9A93AB), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    Spacer(Modifier.weight(1f))
                    Row(Modifier.clip(RoundedCornerShape(50)).background(AI_BRUSH).padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("اطلب", color = Color(0xFF10201C), fontSize = 14.sp); Spacer(Modifier.width(6.dp)); Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFF10201C), modifier = Modifier.size(16.dp))
                    }
                }
                // بطاقة المونتاج اليدوي
                Column(Modifier.weight(1f).height(250.dp).clip(RoundedCornerShape(28.dp)).background(Brush.verticalGradient(listOf(Color(0xFF2A2214), Color(0xFF17130C))))
                    .border(1.5.dp, Color(0xFF8A6D2E), RoundedCornerShape(28.dp)).clickable { onStart(null, null) }.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                        Box(Modifier.size(60.dp).clip(RoundedCornerShape(18.dp)).background(GOLD_BRUSH), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.ContentCut, null, tint = Color(0xFF2A2010), modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.weight(1f)); Badge("مجاني", Color(0xFF7CE0A0))
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("مونتاج بنفسك", color = Color.White, fontSize = 20.sp)
                    Text("كل أدوات المونتاج بدون حدود", color = Color(0xFF9A93AB), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    Spacer(Modifier.weight(1f))
                    Row(Modifier.clip(RoundedCornerShape(50)).background(GOLD_BRUSH).padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("ابدأ", color = Color(0xFF2A2010), fontSize = 14.sp); Spacer(Modifier.width(6.dp)); Icon(Icons.Default.PlayArrow, null, tint = Color(0xFF2A2010), modifier = Modifier.size(18.dp))
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            // مونتاج بالكلام
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color(0xFF15111E)).border(1.dp, Color(0xFF2A2338), RoundedCornerShape(26.dp)).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("مونتاج كامل بالكلام", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.AutoAwesome, null, tint = PINK, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF0E0B15)).border(1.dp, Color(0xFF2A2338), RoundedCornerShape(20.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = TEAL, modifier = Modifier.padding(horizontal = 6.dp).size(20.dp))
                    BasicTextField(prompt, { prompt = it }, Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                        cursorBrush = Brush.verticalGradient(listOf(TEAL, TEAL)),
                        decorationBox = { inner -> if (prompt.isEmpty()) Text("قل لي ماذا تريد أن أفعل...", color = Color(0xFF7D768F), fontSize = 15.sp); inner() })
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(AI_BRUSH).clickable(enabled = prompt.isNotBlank()) { onStart(prompt.trim(), null) }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Send, null, tint = Color(0xFF10201C), modifier = Modifier.size(20.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Icons.Default.ContentCut to "قص", Icons.Default.ClosedCaption to "كابشن", Icons.Default.Movie to "موشن", Icons.Default.ZoomIn to "زووم", Icons.Default.Palette to "ألوان", Icons.Default.VolumeUp to "صوت").forEach { (ic, n) ->
                        Row(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF14211F)).clickable { onStart("افعل ما يناسب: $n", null) }.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(ic, null, tint = TEAL, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(n, color = Color(0xFFBFEFE4), fontSize = 13.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            // بانر القص التلقائي
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF2A1F2E), Color(0xFF1B1620)))).border(1.dp, Color(0xFF6A3F85), RoundedCornerShape(22.dp))
                .clickable { onStart(null, "silence") }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(PINK.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = PINK) }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text("احذف السكتات في ثوانٍ", color = Color.White, fontSize = 15.sp)
                    Text("يعمل على جهازك بدون إنترنت", color = Color(0xFF9A93AB), fontSize = 12.sp)
                }
                Text("جرّبه", color = Color(0xFF10201C), fontSize = 13.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(PINK, Color(0xFFF59ECB)))).padding(horizontal = 16.dp, vertical = 9.dp))
            }
            Spacer(Modifier.height(26.dp))
            // أمثلة
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("شاهد ماذا تفعل لمسة", color = Color.White, fontSize = 19.sp, modifier = Modifier.weight(1f)); Icon(Icons.Default.AutoAwesome, null, tint = TEAL, modifier = Modifier.size(18.dp))
            }
            Text("اضغط على أي مثال وجرّبه على فيديوك", color = Color(0xFF8E87A0), fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ExampleCard("كابشن كلمة بكلمة", "اضف كابشن بقالب كاريوكي") { KaraokeDemo() }
                ExampleCard("قص السكتات والتكرار", null) { WaveDemo() }
            }
            Spacer(Modifier.height(26.dp))
            // أدوات سريعة
            Text("أدوات سريعة", color = Color.White, fontSize = 19.sp)
            Spacer(Modifier.height(14.dp))
            val tools = listOf(
                Triple(Icons.Default.AutoAwesome to "مونتاج تلقائي", TEAL, "AI" to "ai"), Triple(Icons.Default.ClosedCaption to "كابشن تلقائي", Color(0xFF6BE0C5), "AI" to "prompt:أضف كابشن تلقائي للفيديو"),
                Triple(Icons.Default.GraphicEq to "حذف السكتات", Color(0xFF5CC8FF), "مجاني" to "silence"), Triple(Icons.Default.PictureInPicture to "تراكب", Color(0xFFB794FF), "جديد" to "pip"),
                Triple(Icons.Default.GraphicEq to "مؤثرات صوتية", Color(0xFFFFB04D), "جديد" to "sfx"), Triple(Icons.Default.Movie to "قوالب موشن", PINK, "جديد" to "tpls"),
                Triple(Icons.Default.EmojiEmotions to "ملصقات", Color(0xFFFF7BCB), "" to "stickers"), Triple(Icons.Default.Tune to "فلاتر", Color(0xFF9BE564), "" to "filter"),
                Triple(Icons.Default.Palette to "ألوان", Color(0xFFFF8A65), "" to "adjust"), Triple(Icons.Default.Layers to "انتقالات", Color(0xFF64B5F6), "" to "trans"),
                Triple(Icons.Default.MusicNote to "موسيقى وصوت", Color(0xFFFF6B8B), "مجاني" to "audio"), Triple(Icons.Default.TextFields to "قوالب نص", GOLD, "" to "templates")
            )
            tools.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (iconLabel, tint, bp) ->
                        val key = bp.second
                        ToolTile(iconLabel.first, iconLabel.second, tint, bp.first.ifBlank { null }, if (bp.first == "AI") TEAL else if (bp.first == "جديد") GOLD else Color(0xFF7CE0A0), Modifier.weight(1f)) {
                            if (key.startsWith("prompt:")) onStart(key.removePrefix("prompt:"), null) else onStart(null, key)
                        }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            if (recent.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("أكمل من حيث توقفت", color = Color.White, fontSize = 19.sp, modifier = Modifier.weight(1f))
                    Text("الكل ‹", color = Color(0xFF9A93AB), fontSize = 13.sp, modifier = Modifier.clickable(onClick = onAllProjects))
                }
                Spacer(Modifier.height(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(recent.take(8)) { p ->
                        Column(Modifier.width(120.dp).clickable { onOpen(p.id) }) {
                            val bmp = remember(p.thumb) { p.thumb?.let { BitmapFactory.decodeFile(it)?.asImageBitmap() } }
                            Box(Modifier.size(120.dp, 160.dp).clip(RoundedCornerShape(18.dp)).background(CARD).border(1.dp, Color(0xFF2A2338), RoundedCornerShape(18.dp))) {
                                if (bmp != null) androidx.compose.foundation.Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            }
                            Text(p.name, color = Color(0xFFD8D4E3), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExampleCard(title: String, prompt: String?, content: @Composable () -> Unit) {
    Column(Modifier.width(250.dp).clip(RoundedCornerShape(24.dp)).background(Color(0xFF14111C)).border(1.dp, Color(0xFF241E30), RoundedCornerShape(24.dp)).padding(12.dp)) {
        Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF0C0A12)), contentAlignment = Alignment.Center) { content() }
        Text(title, color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp, bottom = 8.dp))
    }
}

@Composable
private fun KaraokeDemo() {
    val words = listOf("هذا", "سيغيّر", "كل", "شيء")
    var i by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(500); i = (i + 1) % words.size } }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        words.forEachIndexed { k, w ->
            Text(w, color = if (k == i) Color(0xFF1B1400) else Color.White, fontSize = 20.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (k == i) Color(0xFFFFD83D) else Color.Transparent).padding(horizontal = 6.dp, vertical = 2.dp))
        }
    }
}

@Composable
private fun WaveDemo() {
    val bars = remember { val r = Random(7); List(46) { i -> if (i in 12..15 || i in 28..30 || i in 38..39) 0.06f else 0.25f + r.nextFloat() * 0.75f } }
    Canvas(Modifier.fillMaxSize().padding(14.dp)) {
        val step = size.width / bars.size
        bars.forEachIndexed { i, a ->
            val cut = a < 0.1f; val h = size.height * a * 0.8f; val x = i * step + step / 2
            drawLine(if (cut) Color(0xFFFF5A5A) else Color(0xFF3FD0F0), Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2), step * 0.5f)
        }
    }
}

/** الشريط السفلي: الرئيسية / مشاريعي / [لمسة AI] / المكتبة / الإعدادات */
@Composable
fun BottomNav(tab: Int, onTab: (Int) -> Unit, onAi: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().navigationBarsPadding().height(96.dp)) {
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(70.dp).background(Brush.verticalGradient(listOf(Color(0xE60B0A12), Color(0xFF0B0A12)))))
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(70.dp), verticalAlignment = Alignment.CenterVertically) {
            @Composable fun Item(i: Int, icon: ImageVector, label: String) {
                Column(Modifier.weight(1f).clickable { onTab(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, null, tint = if (tab == i) GOLD else Color(0xFF7D768F), modifier = Modifier.size(26.dp))
                    Text(label, color = if (tab == i) GOLD else Color(0xFF7D768F), fontSize = 11.sp)
                    if (tab == i) Box(Modifier.padding(top = 3.dp).width(22.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(GOLD))
                }
            }
            Item(0, Icons.Default.Home, "الرئيسية"); Item(1, Icons.Default.FolderOpen, "مشاريعي")
            Spacer(Modifier.weight(1f))
            Item(2, Icons.Default.LibraryMusic, "المكتبة"); Item(3, Icons.Default.Settings, "الإعدادات")
        }
        Column(Modifier.align(Alignment.TopCenter), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.clickable(onClick = onAi)) { AiRing(66.dp) }
            Text("لمسة AI", color = PINK, fontSize = 12.sp)
        }
    }
}

/** مكتبة: مؤثرات صوتية / قوالب موشن / خطوط */
@Composable
fun LibraryScreen() {
    val ctx = LocalContext.current
    var sec by remember { mutableIntStateOf(0) }
    val sfx = remember { SfxLib.items(ctx) }
    val cats = remember(sfx) { sfx.map { it.cat }.distinct() }
    var ci by remember { mutableIntStateOf(0) }
    val fonts = remember { ctx.assets.list("fonts")?.filter { it.endsWith(".ttf") || it.endsWith(".otf") }?.sorted().orEmpty() }
    Box(Modifier.fillMaxSize()) {
        GlowBackground()
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
            Text("المكتبة", color = Color.White, fontSize = 26.sp, modifier = Modifier.padding(top = 18.dp, bottom = 12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("مؤثرات صوتية", "قوالب موشن", "الخطوط").forEachIndexed { i, n -> FilterChip(sec == i, { sec = i }, { Text(n) }) }
            }
            Spacer(Modifier.height(12.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 120.dp)) {
                when (sec) {
                    0 -> {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            cats.forEachIndexed { i, c -> FilterChip(ci == i, { ci = i }, { Text(SfxLib.CATS[c] ?: c) }) }
                        }
                        sfx.filter { it.cat == cats.getOrNull(ci) }.forEach { s ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(14.dp)).background(CARD).clickable { SfxLib.preview(ctx, s.id) }.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayCircle, null, tint = TEAL); Spacer(Modifier.width(10.dp)); Text(s.name, color = Color.White, modifier = Modifier.weight(1f))
                            }
                        }
                        Text("برخصة CC0 — التفاصيل في assets/sfx/CREDITS.md", color = Color(0xFF7D768F), fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                    }
                    1 -> TplRender.LIST.chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            row.forEach { (id, name) ->
                                val thumb = remember(id) {
                                    val (tx, t2, acc) = TplRender.defaults(id)
                                    TplRender.draw(Caption(0, 3000, tx, CapStyle(color = 0xFFFFFFFF.toInt()), tpl = id, t2 = t2, bc = acc), 540, 960, 30).asImageBitmap()
                                }
                                Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(CARD).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) { androidx.compose.foundation.Image(thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                                    Text(name, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                    else -> fonts.forEach { f ->
                        val fam = remember(f) { FontFamily(CapStyle(font = f, fontPath = "asset:fonts/$f", bold = false).typeface()) }
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(14.dp)).background(CARD).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("أبجد هوز Abc", fontFamily = fam, color = Color.White, fontSize = 22.sp, modifier = Modifier.weight(1f))
                            Text(f.substringBeforeLast('.').substringBefore('[').substringBefore('-'), color = Color(0xFF7D768F), fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var lang by remember { mutableStateOf(prefs.getString("lang", "ar") ?: "ar") }
    var url by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
    var saved by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        GlowBackground()
        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 130.dp)) {
            Text("الإعدادات", color = Color.White, fontSize = 26.sp, modifier = Modifier.padding(top = 18.dp, bottom = 14.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CARD).padding(16.dp)) {
                Text("المساعد والكابشن التلقائي", color = Color.White, fontSize = 16.sp)
                Text("مفتاح Groq المجاني من console.groq.com لتحويل الكلام إلى نص وتشغيل المساعد.", color = Color(0xFF8E87A0), fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                OutlinedTextField(key, { key = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("API Key") }, singleLine = true)
                OutlinedTextField(lang, { lang = it; saved = false }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("لغة الكلام (ar / en / فارغ=تلقائي)") }, singleLine = true)
                OutlinedTextField(url, { url = it; saved = false }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("عنوان الخدمة (اختياري)") }, singleLine = true)
                if (BuildConfig.GROQ_KEY.isNotBlank()) Text("✓ مفتاح مدمج في التطبيق، لا حاجة لإدخاله", color = TEAL, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(14.dp)).background(GOLD_BRUSH).clickable {
                    prefs.edit().putString("key", key.trim()).putString("lang", lang.trim()).putString("url", url.trim()).apply(); saved = true
                }, contentAlignment = Alignment.Center) { Text(if (saved) "تم الحفظ ✓" else "حفظ", color = Color(0xFF2A2010), fontSize = 15.sp) }
            }
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CARD).padding(16.dp)) {
                Text("حول التطبيق", color = Color.White, fontSize = 16.sp)
                Text("لمسة — نسخة 0.3\nالمؤثرات الصوتية برخصة CC0، والخطوط مفتوحة المصدر (OFL).", color = Color(0xFF8E87A0), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}
