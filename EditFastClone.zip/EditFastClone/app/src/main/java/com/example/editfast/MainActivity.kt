package com.example.editfast

import android.Manifest
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.abs

private val BG = Color(0xFF1E1E22)
private val PANEL = Color(0xFF17171C)
private val ACCENT = Color(0xFF8B5CF6)
private val RED = Color(0xFFFF3B5C)
private val GREEN = Color(0xFF7CB342)
private val SPEEDS = listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
private val PALETTE = listOf(0xFFFFFFFF, 0xFFCCCCCC, 0xFF999999, 0xFF666666, 0xFF000000, 0xFFFFE0B2, 0xFFFFCC80, 0xFFFFEB3B, 0xFFFFD54F,
    0xFFFF9100, 0xFFFF5252, 0xFFFF1744, 0xFFB71C1C, 0xFFFF4081, 0xFFE040FB, 0xFF7C4DFF, 0xFF6D4AFF, 0xFF448AFF, 0xFF00B0FF,
    0xFF00E5FF, 0xFF1DE9B6, 0xFF69F0AE, 0xFF76FF03, 0xFFFFCDD2).map { it.toInt() }

private data class CardP(val mode: Int, val color: Int, val text: Int, val r: Float)
private val CARDS = listOf(
    CardP(1, 0xFFFFEB3B.toInt(), 0xFF000000.toInt(), 0f), CardP(1, 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0f),
    CardP(2, 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 2f), CardP(2, 0xFFFFC107.toInt(), 0xFF000000.toInt(), 2f),
    CardP(2, 0xCC000000.toInt(), 0xFFFFFFFF.toInt(), 2f), CardP(2, 0xFFFF1744.toInt(), 0xFFFFFFFF.toInt(), 0.6f),
    CardP(2, 0xFF6D4AFF.toInt(), 0xFFFFFFFF.toInt(), 0.9f), CardP(2, 0xFF69F0AE.toInt(), 0xFF000000.toInt(), 0.9f)
)
private data class FontOpt(val label: String, val font: String, val path: String?)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.ctx = applicationContext
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = ACCENT)) { EditorScreen() } }
    }
}

private fun fmt(ms: Long) = "%d:%02d.%d".format(ms / 60000, (ms / 1000) % 60, (ms / 100) % 10)

@Composable
private fun Tool(icon: ImageVector, label: String, hi: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.width(72.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (hi) Color(0xFFB794FF) else Color.White, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(5.dp)); Text(label, fontSize = 10.sp, color = Color.LightGray, maxLines = 1)
    }
}

@Composable
private fun Opt(label: String, on: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f)); Switch(on, set)
    }
}

@Composable
private fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Color.White else Color.Gray, CircleShape)
                .clickable { onPick(c) })
        }
    }
}

@Composable
private fun LayerBtn(h: Int, icon: ImageVector, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.height(h.dp).width(34.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (on) Color.White else Color(0xFF666670), modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun Chips(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, n -> FilterChip(sel == i, { onSel(i) }, { Text(n) }) }
    }
}

/** لوحة ألوان أفقية على طريقة InShot (+ بدون + لون مخصص) */
@Composable
private fun Palette(selected: Int?, withNone: Boolean, onPick: (Int?) -> Unit, onCustom: () -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        if (withNone) Box(Modifier.size(40.dp).background(Color.White).clickable { onPick(null) }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Block, null, tint = RED)
        }
        PALETTE.forEach { c ->
            Box(Modifier.size(40.dp).background(Color(c)).then(if (c == selected) Modifier.border(3.dp, ACCENT) else Modifier).clickable { onPick(c) })
        }
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(6.dp)).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
            .clickable { onCustom() })
    }
}

@Composable
private fun BoxScope.Handle(al: Alignment, dx: Int, dy: Int, bg: Color, icon: ImageVector?, mod: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    Box(Modifier.align(al).absoluteOffset(dx.dp, dy.dp).size(28.dp).clip(CircleShape).background(bg).then(mod)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier), contentAlignment = Alignment.Center) {
        if (icon != null) Icon(icon, null, tint = if (bg == Color.White) Color.Black else Color.White, modifier = Modifier.size(16.dp))
    }
}

/** نص/ملصق في المعاينة: إطار تحديد بمقابض (حذف، تعديل، تغيير الحجم، العرض) + سحب وقرص */
@Composable
private fun CaptionLayer(vm: EditorViewModel, idx: Int, c: Caption, pos: Long, fw: Int, fh: Int, safe: SafeZone?, selected: Boolean, onEdit: () -> Unit) {
    val a = CapAnim.state(c, pos)
    val bmp = remember(c, fw, fh, a.chars) { CapRender.render(c, fw, fh, a.chars).asImageBitmap() }
    val (x, y) = CapAnim.place(c, bmp.width, bmp.height, fw, fh, safe, a)
    val cx = (x + 1f) / 2f * fw; val cy = (1f - y) / 2f * fh
    val den = LocalDensity.current
    val wDp = with(den) { bmp.width.toDp() }; val hDp = with(den) { bmp.height.toDp() }
    Box(Modifier.offset { IntOffset((cx - bmp.width / 2f).toInt(), (cy - bmp.height / 2f).toInt()) }
        .size(wDp, hDp).graphicsLayer(scaleX = a.scale, scaleY = a.scale, rotationZ = -a.rot)) {
        Image(bmp, null, Modifier.fillMaxSize().graphicsLayer(alpha = a.alpha)
            .pointerInput(idx) { detectTapGestures { vm.selCap = idx } }
            .pointerInput(idx, selected) {
                if (selected) detectTransformGestures { _, pan, z, _ -> vm.moveCap(idx, pan.x / (fw / 2f), -pan.y / (fh / 2f), z) }
            })
        if (selected) {
            Box(Modifier.fillMaxSize().border(1.5.dp, Color.White))
            Handle(AbsoluteAlignment.TopLeft, -14, -14, RED, Icons.Default.Close, onClick = { vm.removeCaption(idx) })
            if (c.img == null) Handle(AbsoluteAlignment.TopRight, 14, -14, Color.White, Icons.Default.Edit, onClick = onEdit)
            Handle(AbsoluteAlignment.BottomRight, 14, 14, Color.White, Icons.Default.OpenInFull,
                Modifier.pointerInput(idx) { detectDragGestures { ch, d -> ch.consume(); vm.updStyle(idx) { it.copy(size = (it.size * (1f + (d.x + d.y) / bmp.width)).coerceIn(0.3f, 4f)) } } })
            if (c.img == null) {
                Handle(AbsoluteAlignment.CenterRight, 10, 0, Color.White, null,
                    Modifier.pointerInput(idx) { detectDragGestures { ch, d -> ch.consume(); vm.updStyle(idx) { it.copy(maxW = (it.maxW + d.x * 2f / fw).coerceIn(0.2f, 0.98f)) } } })
                Handle(AbsoluteAlignment.CenterLeft, -10, 0, Color.White, null,
                    Modifier.pointerInput(idx) { detectDragGestures { ch, d -> ch.consume(); vm.updStyle(idx) { it.copy(maxW = (it.maxW - d.x * 2f / fw).coerceIn(0.2f, 0.98f)) } } })
            }
        }
    }
}

/** محرر النص المثبّت أسفل الشاشة (على طريقة InShot): ألوان / حدود / ظل / توهج / بطاقة / خط / محاذاة / قوالب / كتابة */
@Composable
private fun TextEditor(vm: EditorViewModel, i: Int, c: Caption, fonts: List<FontOpt>, onAddFont: () -> Unit,
                       onCustomColor: ((Int) -> Unit) -> Unit, onDone: () -> Unit, onCancel: () -> Unit) {
    var tab by remember { mutableIntStateOf(3) }
    var sub by remember { mutableIntStateOf(0) }
    val st = c.st
    fun upd(f: (CapStyle) -> CapStyle) = vm.updStyle(i, f)
    Column(Modifier.fillMaxWidth().background(PANEL)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onDone) { Icon(Icons.Default.Check, null, tint = Color.White) }
            IconButton({ tab = 0 }) { Icon(Icons.Default.Opacity, null, tint = if (tab == 0) ACCENT else Color.White) }
            IconButton({ tab = 1 }) { Icon(Icons.Default.FormatAlignCenter, null, tint = if (tab == 1) ACCENT else Color.White) }
            TextButton({ tab = 2 }) { Text("Aa", fontSize = 20.sp, color = if (tab == 2) ACCENT else Color.White) }
            IconButton({ tab = 3 }, Modifier.clip(RoundedCornerShape(8.dp)).background(if (tab == 3) Color(0xFF2C2C36) else Color.Transparent)) {
                Box(Modifier.size(26.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red))))
            }
            IconButton({ tab = 4 }) { Icon(Icons.Default.FormatColorText, null, tint = if (tab == 4) ACCENT else Color(0xFFFF8A65)) }
            IconButton({ tab = 5 }) { Icon(Icons.Default.Keyboard, null, tint = if (tab == 5) ACCENT else Color.White) }
            IconButton(onCancel) { Icon(Icons.Default.Close, null, tint = Color.White) }
        }
        Column(Modifier.heightIn(max = 330.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp).padding(bottom = 10.dp)) {
            when (tab) {
                3 -> {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        listOf("نص", "الحدود", "ظل", "توهج", "بطاقة", "التعتيم").forEachIndexed { k, n ->
                            Column(Modifier.clickable { sub = k }.padding(vertical = 6.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(n, color = if (sub == k) Color.White else Color.Gray, fontSize = 15.sp)
                                if (sub == k) Box(Modifier.padding(top = 3.dp).size(5.dp).clip(CircleShape).background(Color.White))
                            }
                        }
                    }
                    when (sub) {
                        0 -> Palette(st.color, false, { col -> if (col != null) upd { it.copy(color = col, grad = false) } }) { onCustomColor { col -> upd { it.copy(color = col, grad = false) } } }
                        1 -> {
                            Palette(if (st.outline) st.outlineColor else null, true, { col -> if (col == null) upd { it.copy(outline = false) } else upd { it.copy(outline = true, outlineColor = col) } }) { onCustomColor { col -> upd { it.copy(outline = true, outlineColor = col) } } }
                            if (st.outline) Slider(st.outW, { v -> upd { it.copy(outW = v) } }, valueRange = 0.3f..3f)
                        }
                        2 -> {
                            Palette(if (st.shadow) st.shadowColor else null, true, { col -> if (col == null) upd { it.copy(shadow = false) } else upd { it.copy(shadow = true, shadowColor = col) } }) { onCustomColor { col -> upd { it.copy(shadow = true, shadowColor = col) } } }
                            if (st.shadow) Slider(st.shadowAmt, { v -> upd { it.copy(shadowAmt = v) } }, valueRange = 0.3f..3f)
                        }
                        3 -> Palette(if (st.glow) (if (st.glowColor != 0) st.glowColor else st.color) else null, true, { col -> if (col == null) upd { it.copy(glow = false) } else upd { it.copy(glow = true, glowColor = col) } }) { onCustomColor { col -> upd { it.copy(glow = true, glowColor = col) } } }
                        4 -> {
                            Palette(if (st.boxMode != 0) st.boxColor else null, true, { col -> if (col == null) upd { it.copy(boxMode = 0) } else upd { it.copy(boxMode = if (it.boxMode == 0) 2 else it.boxMode, boxColor = col) } }) { onCustomColor { col -> upd { it.copy(boxMode = if (it.boxMode == 0) 2 else it.boxMode, boxColor = col) } } }
                            if (st.boxMode != 0) {
                                Chips(listOf("مربع", "دائري"), st.boxMode - 1) { k -> upd { it.copy(boxMode = k + 1) } }
                                Slider(st.boxPad, { v -> upd { it.copy(boxPad = v) } }, valueRange = 0.3f..2.5f)
                            }
                        }
                        5 -> { Text("شفافية النص", color = Color.White); Slider(st.opacity, { v -> upd { it.copy(opacity = v) } }, valueRange = 0.1f..1f) }
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(84.dp, 46.dp).clip(RoundedCornerShape(6.dp)).background(Color.White).clickable { upd { it.copy(boxMode = 0) } }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Block, null, tint = RED) }
                        CARDS.forEach { p ->
                            Box(Modifier.size(84.dp, 46.dp).clip(RoundedCornerShape(if (p.mode == 2) (p.r * 11f).coerceAtMost(23f).dp else 2.dp)).background(Color(p.color))
                                .clickable { upd { it.copy(boxMode = p.mode, boxColor = p.color, boxR = p.r, color = p.text, grad = false) } }, contentAlignment = Alignment.Center) {
                                Text("نص", color = Color(p.text), fontSize = 16.sp)
                            }
                        }
                    }
                }
                2 -> {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        fonts.forEach { f ->
                            val fam = remember(f) { FontFamily(CapStyle(font = f.font, fontPath = f.path, bold = false).typeface()) }
                            val on = st.font == f.font && st.fontPath == f.path
                            Box(Modifier.size(100.dp, 54.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2C2C36)).then(if (on) Modifier.border(2.dp, ACCENT, RoundedCornerShape(10.dp)) else Modifier)
                                .clickable { upd { it.copy(font = f.font, fontPath = f.path) } }, contentAlignment = Alignment.Center) {
                                Text("أبجد Abc", fontFamily = fam, color = Color.White, fontSize = 17.sp, maxLines = 1)
                            }
                        }
                        AssistChip(onAddFont, { Text("+ خط") })
                    }
                    Text("الحجم", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Slider(st.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.4f..3f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(st.bold, { upd { it.copy(bold = !it.bold) } }, { Text("عريض") })
                        FilterChip(st.italic, { upd { it.copy(italic = !it.italic) } }, { Text("مائل") })
                        FilterChip(st.underline, { upd { it.copy(underline = !it.underline) } }, { Text("تسطير") })
                    }
                }
                1 -> {
                    Text("المحاذاة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(listOf("بداية السطر", "وسط", "نهاية السطر"), st.align) { k -> upd { it.copy(align = k) } }
                    Text("تباعد الأحرف", color = Color.White); Slider(st.spacing, { v -> upd { it.copy(spacing = v) } }, valueRange = 0f..0.5f)
                    Text("تباعد الأسطر", color = Color.White); Slider(st.lineSp, { v -> upd { it.copy(lineSp = v) } }, valueRange = 0.7f..2f)
                    Text("أقصى عرض للنص", color = Color.White); Slider(st.maxW, { v -> upd { it.copy(maxW = v) } }, valueRange = 0.3f..0.95f)
                }
                0 -> {
                    Text("الشفافية", color = Color.White, modifier = Modifier.padding(top = 8.dp)); Slider(st.opacity, { v -> upd { it.copy(opacity = v) } }, valueRange = 0.1f..1f)
                    Text("تدوير النص", color = Color.White); Slider(st.rot, { v -> upd { it.copy(rot = v) } }, valueRange = -180f..180f)
                    Text("الحجم", color = Color.White); Slider(st.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.4f..3f)
                }
                4 -> {
                    Text("قوالب جاهزة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(TEMPLATES.map { it.first }, -1) { k -> val t = TEMPLATES[k].second; upd { s -> t.copy(x = s.x, y = s.y, size = s.size) } }
                    Opt("تعبئة متدرجة", st.grad) { v -> upd { it.copy(grad = v) } }
                    if (st.grad) Swatches(listOf(0xFFFF4081, 0xFFFF6F00, 0xFF6D4AFF, 0xFF00E5FF, 0xFF69F0AE, 0xFFFFFFFF).map { it.toInt() }, st.color2) { v -> upd { it.copy(color2 = v) } }
                    TextButton({ vm.applyStyleToAll(i) }) { Text("تطبيق هذا التنسيق على كل النصوص") }
                }
                5 -> {
                    val fr = remember { FocusRequester() }
                    LaunchedEffect(Unit) { fr.requestFocus() }
                    OutlinedTextField(c.text, { vm.editCaption(i, it) }, Modifier.fillMaxWidth().padding(top = 8.dp).focusRequester(fr))
                }
            }
        }
    }
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) {
        val l = object : Player.Listener { override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED) player.pause() } }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    var pos by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(60f) }
    var panel by remember { mutableStateOf<String?>(null) }
    var settings by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var prog by remember { mutableFloatStateOf(0f) }
    var tr by remember { mutableStateOf<Transformer?>(null) }
    var doneUri by remember { mutableStateOf<Uri?>(null) }
    var editMode by remember { mutableStateOf(false) }
    var editBackup by remember { mutableStateOf<Caption?>(null) }
    var hexCb by remember { mutableStateOf<((Int) -> Unit)?>(null) }
    val paint = remember { android.graphics.Paint().apply { color = android.graphics.Color.GRAY; isAntiAlias = true } }
    val bundled = remember { ctx.assets.list("fonts")?.filter { it.endsWith(".ttf") || it.endsWith(".otf") }?.sorted().orEmpty() }
    val customFonts = remember { mutableStateListOf<File>().apply { addAll(ctx.filesDir.listFiles { f -> f.name.startsWith("font_") }.orEmpty()) } }
    val fontOpts = bundled.map { FontOpt(it.substringBeforeLast('.').substringBefore('[').substringBefore('-'), it, "asset:fonts/$it") } +
        listOf("sans-serif" to "عادي", "serif" to "Serif", "monospace" to "Mono", "casual" to "Casual", "cursive" to "Cursive").map { FontOpt(it.second, it.first, null) } +
        customFonts.map { FontOpt(it.name.removePrefix("font_").removeSuffix(".ttf"), it.name.removePrefix("font_").removeSuffix(".ttf"), it.path) }

    fun seekOut(t: Long) {
        if (vm.clips.isEmpty() || player.mediaItemCount != vm.clips.size) return
        val tt = t.coerceIn(0, vm.totalMs); val i = vm.clipAt(tt)
        player.seekTo(i, ((tt - vm.starts()[i]) * vm.clips[i].speed).toLong()); pos = tt
    }
    fun curOut(): Long {
        val i = player.currentMediaItemIndex
        if (i !in vm.clips.indices) return 0
        return vm.starts()[i] + (player.currentPosition / vm.clips[i].speed).toLong()
    }
    fun toggle() {
        if (vm.clips.isEmpty()) return
        if (player.playWhenReady && player.playbackState != Player.STATE_ENDED) player.pause()
        else { if (player.playbackState == Player.STATE_ENDED) seekOut(0); player.play() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            val m = MediaMetadataRetriever().apply { setDataSource(ctx, u) }
            val d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            var w = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toFloat() ?: 9f
            var h = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toFloat() ?: 16f
            val rot = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
            m.release(); if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            vm.addSource(ctx, u, d, w / h)
        }
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val name = (u.lastPathSegment ?: "font").substringAfterLast('/').substringBeforeLast('.')
            val f = File(ctx.filesDir, "font_$name.ttf")
            ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            if (customFonts.none { it.name == f.name }) customFonts.add(f)
            vm.updStyle(vm.selCap) { it.copy(font = name, fontPath = f.path) }
        }
    }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { vm.music = u; vm.musicName = (u.lastPathSegment ?: "موسيقى").substringAfterLast('/') }
    }
    val stickerPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            val f = File(ctx.filesDir, "sticker_${System.currentTimeMillis()}.img")
            ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            vm.addSticker(pos, f.path)
        }
    }
    val voiceRec = remember { VoiceRec() }
    fun startVoice() { vm.voiceStart = pos; voiceRec.start(); vm.recording = true; player.play() }
    fun stopVoice() { vm.voice = voiceRec.stop(); vm.recording = false; player.pause() }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) startVoice() }

    LaunchedEffect(vm.version) {
        if (vm.clips.isEmpty()) { player.clearMediaItems(); return@LaunchedEffect }
        val t = pos
        player.setMediaItems(vm.clips.map { c ->
            MediaItem.Builder().setUri(vm.sources[c.src].uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()).build()
        }, false)
        player.prepare(); seekOut(t)
    }
    LaunchedEffect(Unit) {
        while (true) {
            if (vm.clips.isNotEmpty() && player.mediaItemCount == vm.clips.size) {
                val cl = vm.clips[player.currentMediaItemIndex.coerceIn(0, vm.clips.lastIndex)]
                if (player.playbackParameters.speed != cl.speed) player.setPlaybackSpeed(cl.speed)
                player.volume = cl.vol.coerceIn(0f, 1f)
                if (player.isPlaying) pos = curOut()
            }
            playing = player.playWhenReady && player.playbackState != Player.STATE_ENDED && player.playbackState != Player.STATE_IDLE
            delay(40)
        }
    }
    val look = vm.look()
    LaunchedEffect(look) { try { player.setVideoEffects(lookEffects(look)) } catch (_: Exception) {} }
    LaunchedEffect(exporting) {
        while (exporting) { val h = ProgressHolder(); if (tr?.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) prog = h.progress / 100f; delay(300) }
    }
    val sel = vm.captions.getOrNull(vm.selCap)
    LaunchedEffect(sel == null) { if (sel == null) editMode = false }

    val ratio = if (vm.formatIdx == 0) vm.baseRatio() else FORMATS[vm.formatIdx].second
    val hasVideo = vm.clips.isNotEmpty()
    val safeZ = vm.safeFor(ratio)
    fun startEdit(i: Int) { vm.selCap = i; editBackup = vm.captions.getOrNull(i); editMode = true; panel = null }

    @Composable
    fun PanelBody() {
        when (panel) {
            "clip" -> {
                val i = if (hasVideo) vm.clipAt(pos) else -1
                val c = vm.clips.getOrNull(i)
                if (c == null) Text("أضف فيديو أولاً", color = Color.Gray) else {
                    Text("المقطع ${i + 1} من ${vm.clips.size}  •  السرعة ${c.speed}x", color = Color.White, fontSize = 16.sp)
                    Chips(SPEEDS.map { "${it}x" }, SPEEDS.indexOf(c.speed)) { vm.setSpeedAt(pos, SPEEDS[it]) }
                    Text("قص المقطع", color = Color.White, modifier = Modifier.padding(top = 10.dp))
                    RangeSlider(c.s.toFloat()..c.e.toFloat(), { vm.setTrimAt(pos, it.start.toLong(), it.endInclusive.toLong()) },
                        valueRange = 0f..vm.sources[c.src].durationMs.toFloat())
                    Text("مستوى صوت المقطع ${(c.vol * 100).toInt()}%", color = Color.White)
                    Slider(c.vol, { vm.setVolAt(pos, it) }, valueRange = 0f..1f)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton({ vm.moveAt(pos, -1) }) { Text("⬅ تقديم") }
                        TextButton({ vm.moveAt(pos, 1) }) { Text("تأخير ➡") }
                        TextButton({ vm.duplicateAt(pos) }) { Text("نسخ") }
                        TextButton({ vm.deleteAt(pos) }) { Text("حذف") }
                    }
                    Text("ملاحظة: تغيير السرعة والقص يحرّك الكابشن اللاحق تلقائياً.", color = Color.Gray, fontSize = 11.sp)
                }
            }
            "format" -> {
                FORMATS.forEachIndexed { i, (n, _) ->
                    Row(Modifier.fillMaxWidth().clickable { vm.formatIdx = i }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(vm.formatIdx == i, { vm.formatIdx = i }); Text(n, color = Color.White)
                    }
                }
                Opt("ملء الإطار (قص الأطراف) بدل الأشرطة السوداء", vm.fill) { vm.fill = it }
                Text("التدوير", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                Chips(listOf("0°", "90°", "180°", "270°"), vm.rotate / 90) { vm.rotate = it * 90 }
                Opt("قلب أفقي (مرآة)", vm.flip) { vm.flip = it }
            }
            "audio" -> {
                Opt("المؤثرات الصوتية (عند القطع والكابشن)", vm.optSfx) { vm.optSfx = it }
                Opt("كتم صوت الفيديو الأصلي", vm.muteOriginal) { vm.muteOriginal = it }
                Text("مستوى صوت الفيديو", color = Color.White); Slider(vm.origVol, { vm.origVol = it }, valueRange = 0f..1.5f)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button({ musicPicker.launch(arrayOf("audio/*")) }) { Icon(Icons.Default.MusicNote, null); Text(" إضافة موسيقى") }
                    if (vm.music != null) {
                        Text(vm.musicName, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(1f).padding(start = 8.dp), maxLines = 1)
                        IconButton({ vm.music = null }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                    Button({
                        if (vm.recording) stopVoice()
                        else if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) startVoice()
                        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                    }, colors = ButtonDefaults.buttonColors(containerColor = if (vm.recording) RED else ACCENT)) {
                        Icon(Icons.Default.Mic, null); Text(if (vm.recording) " إيقاف التسجيل" else " تسجيل تعليق صوتي")
                    }
                    if (vm.voice != null && !vm.recording) IconButton({ vm.voice = null }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                }
                Text("يُسجَّل التعليق أثناء تشغيل الفيديو (يُفضّل استخدام سماعات).", color = Color.Gray, fontSize = 11.sp)
                if (vm.music != null) { Text("مستوى الموسيقى", color = Color.White); Slider(vm.musicVol, { vm.musicVol = it }, valueRange = 0.05f..1f) }
            }
            "stickers" -> {
                listOf("😂🔥❤️👍😍😎🤩🥳", "👏💯✨⭐🎉💥🚀✅", "👀🙏💪🎬📌⚡🤔😱").forEach { row ->
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        row.chunked(2).forEach { e -> TextButton({ vm.addEmoji(pos, e); panel = null }) { Text(e, fontSize = 30.sp) } }
                    }
                }
                Button({ stickerPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)); panel = null }) { Icon(Icons.Default.Image, null); Text(" ملصق من صورة") }
            }
            "caps" -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.weight(1f))
                    TextButton({ vm.addCaption(pos) }) { Icon(Icons.Default.Add, null); Text("إضافة هنا") }
                }
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    itemsIndexed(vm.captions) { i, c ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmt(c.startMs), color = if (i == vm.selCap) Color.White else Color(0xFFFFC107), fontSize = 12.sp,
                                modifier = Modifier.clickable { vm.selCap = i; seekOut(c.startMs + 1); panel = null }.padding(end = 8.dp))
                            OutlinedTextField(c.text, { vm.editCaption(i, it) }, Modifier.weight(1f), singleLine = true)
                            IconButton({ vm.removeCaption(i) }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                        }
                    }
                }
                if (vm.captions.isEmpty()) Text("لا يوجد كابشن — استخدم «لمسة الذكية» أو أضف يدوياً", color = Color.Gray, fontSize = 12.sp)
            }
            "cap_anim" -> {
                val i = vm.selCap; val c = vm.captions.getOrNull(i)
                if (c != null) {
                    Text("طريقة الظهور", color = Color.White)
                    Chips(ANIMS, c.st.anim) { v -> vm.updStyle(i) { it.copy(anim = v) } }
                    if (c.st.anim == 9) {
                        Text("لون الكلمة المميّزة", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                        Swatches(listOf(0xFFFFEB3B, 0xFF00E5FF, 0xFF69F0AE, 0xFFFF4081, 0xFFFF9100, 0xFFFFFFFF).map { it.toInt() }, c.st.hl) { v -> vm.updStyle(i) { it.copy(hl = v) } }
                    }
                    Text("الاختفاء", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(OUTS, c.st.animOut) { v -> vm.updStyle(i) { it.copy(animOut = v) } }
                    Text("حركة مستمرة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(LOOPS, c.st.loop) { v -> vm.updStyle(i) { it.copy(loop = v) } }
                    Text("مدة الحركة ${c.st.animMs} مللي ثانية", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Slider(c.st.animMs.toFloat(), { v -> vm.updStyle(i) { it.copy(animMs = v.toLong()) } }, valueRange = 100f..1200f)
                }
            }
            "cap_pos", "safe" -> {
                val i = vm.selCap; val c = vm.captions.getOrNull(i)
                if (panel == "cap_pos" && c != null) {
                    Text("التوقيت", color = Color.White)
                    RangeSlider(c.startMs.toFloat()..c.endMs.toFloat(), { vm.setCaptionTime(i, it.start.toLong(), it.endInclusive.toLong()) },
                        valueRange = 0f..maxOf(vm.totalMs, c.endMs).toFloat())
                }
                Text("المنصة", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                Chips(PLATFORMS.map { it.first }, vm.platform) { vm.platform = it }
                Opt("إظهار المناطق الآمنة في المعاينة (الأحمر = تغطيه أزرار المنصة)", vm.showSafe) { vm.showSafe = it }
                Opt("إبقاء النص داخل المنطقة الآمنة تلقائياً", vm.clampSafe) { vm.clampSafe = it }
                val z = PLATFORMS[vm.platform].second
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("أعلى", "وسط", "أسفل").forEachIndexed { k, n ->
                        OutlinedButton({ if (panel == "cap_pos" && c != null) vm.updStyle(i) { it.copy(y = presetY(z, k), x = 0f) } else vm.setAllY(presetY(z, k)) }) {
                            Text(if (panel == "cap_pos") n else "$n (الكل)")
                        }
                    }
                }
                Text("اسحب النص في المعاينة لتحريكه. المناطق تقريبية وتعمل على الفيديو العمودي 9:16.", color = Color.Gray, fontSize = 11.sp)
            }
            "templates" -> {
                Chips(TEMPLATES.map { it.first }, -1) { k ->
                    val t = TEMPLATES[k].second; val i = vm.selCap
                    if (i in vm.captions.indices) vm.updStyle(i) { c -> t.copy(x = c.x, y = c.y, size = c.size) } else vm.defStyle = t.copy(y = vm.defStyle.y)
                }
                Text("يُطبَّق على النص المحدد، أو على النصوص الجديدة إن لم يكن هناك نص محدد.", color = Color.Gray, fontSize = 11.sp)
            }
            "fx" -> {
                Opt("اهتزاز الكاميرا", vm.fxShake) { vm.fxShake = it }
                Opt("نبض (زووم إيقاعي)", vm.fxPulse) { vm.fxPulse = it }
                Opt("فينيت (تعتيم الأطراف)", vm.fxVignette) { vm.fxVignette = it }
                Opt("أشرطة سينمائية", vm.fxBars) { vm.fxBars = it }
                Text("الاهتزاز والنبض يظهران في المعاينة، والفينيت والأشرطة بعد التصدير.", color = Color.Gray, fontSize = 11.sp)
            }
            "ai" -> {
                Text("مونتاج تلقائي بضغطة واحدة", color = Color.Gray, fontSize = 12.sp)
                Opt("قص السكتات", vm.optSilence) { vm.optSilence = it }
                Opt("كابشن تلقائي", vm.optCaptions) { vm.optCaptions = it }
                Opt("زووم وانتقالات عند القطع", vm.optZoom) { vm.optZoom = it }
                Opt("مؤثرات صوتية", vm.optSfx) { vm.optSfx = it }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(16.dp)).background(Brush.horizontalGradient(listOf(ACCENT, RED)))
                    .clickable(enabled = vm.busy == null && hasVideo) { vm.autoEdit(ctx); panel = null }, contentAlignment = Alignment.Center) {
                    Text("ابدأ المونتاج التلقائي", color = Color.White, fontSize = 17.sp)
                }
                OutlinedButton({ vm.autoFitCaptions() }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("ضبط مكان الكابشن تلقائياً (منطقة آمنة)") }
                Text("الكابشن التلقائي يحتاج اتصالاً بخدمة تفريغ الكلام.", color = Color.Gray, fontSize = 11.sp)
            }
            "adjust" -> {
                Text("السطوع", color = Color.White); Slider(vm.adjB, { vm.adjB = it }, valueRange = -0.5f..0.5f)
                Text("التباين", color = Color.White); Slider(vm.adjC, { vm.adjC = it }, valueRange = -0.5f..0.5f)
                Text("التشبّع", color = Color.White); Slider(vm.adjS, { vm.adjS = it }, valueRange = -1f..1f)
                Text("الدفء (أزرق ← أحمر)", color = Color.White); Slider(vm.adjW, { vm.adjW = it }, valueRange = -1f..1f)
                TextButton({ vm.resetAdjust() }) { Text("إعادة الضبط") }
            }
            "crop" -> {
                Text("التكبير", color = Color.White); Slider(vm.tScale, { vm.tScale = it }, valueRange = 1f..3f)
                Text("إزاحة أفقية", color = Color.White); Slider(vm.tX, { vm.tX = it }, valueRange = -1f..1f)
                Text("إزاحة رأسية", color = Color.White); Slider(vm.tY, { vm.tY = it }, valueRange = -1f..1f)
                TextButton({ vm.resetCrop() }) { Text("إعادة الضبط") }
            }
            "trans" -> {
                Chips(listOf("بدون", "تلاشي للأسود", "وميض أبيض"), vm.transition) { vm.transition = it }
                Text("مدة الانتقال ${vm.transMs} مللي ثانية", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                Slider(vm.transMs.toFloat(), { vm.transMs = it.toLong() }, valueRange = 150f..900f)
                Opt("زووم عند القطع", vm.optZoom) { vm.optZoom = it }
                Opt("تلاشي في بداية الفيديو ونهايته", vm.fadeEnds) { vm.fadeEnds = it }
                Text("الانتقالات تظهر في الفيديو بعد التصدير.", color = Color.Gray, fontSize = 11.sp)
            }
            "filter" -> {
                Chips(FILTER_NAMES, vm.filterIdx) { vm.filterIdx = it }
                Text("يظهر الفلتر مباشرة في المعاينة.", color = Color.Gray, fontSize = 11.sp)
            }
            "export" -> {
                if (doneUri != null) {
                    Text("تم الحفظ في Movies/EditFast ✅", color = Color.White, modifier = Modifier.padding(vertical = 12.dp))
                    Button({
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, doneUri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }, "مشاركة"))
                    }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Text("  مشاركة") }
                } else {
                    Text("الحجم: ${FORMATS[vm.formatIdx].first}", color = Color.Gray, fontSize = 12.sp)
                    Text("الدقة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(listOf("720p", "1080p", "1440p"), vm.resIdx) { vm.resIdx = it }
                    Text("الجودة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(listOf("منخفضة (حجم أصغر)", "متوسطة", "عالية"), vm.quality) { vm.quality = it }
                    Spacer(Modifier.height(12.dp))
                    if (exporting) {
                        LinearProgressIndicator(progress = { prog }, Modifier.fillMaxWidth())
                        Text("جاري التصدير ${(prog * 100).toInt()}%", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                        TextButton({ tr?.cancel(); exporting = false }) { Text("إلغاء") }
                    } else Button({
                        val bits = listOf(listOf(3_000_000, 5_000_000, 8_000_000), listOf(6_000_000, 10_000_000, 16_000_000), listOf(10_000_000, 16_000_000, 25_000_000))
                        val sp = ExportSpec(vm.sources.map { it.uri }, vm.clips.toList(), if (vm.capsVisible) vm.captions.toList() else emptyList(),
                            vm.optZoom, vm.filterIdx, vm.optSfx, vm.muteOriginal, vm.origVol, vm.music, vm.musicVol,
                            FORMATS[vm.formatIdx].second, vm.baseRatio(), vm.rotate, vm.flip, vm.fill,
                            listOf(720, 1080, 1440)[vm.resIdx], bits[vm.resIdx][vm.quality], if (vm.clampSafe) PLATFORMS[vm.platform].second else null,
                            vm.look(), vm.transition, vm.transMs, vm.fadeEnds, vm.voice, vm.voiceStart, vm.fxVignette, vm.fxBars)
                        player.pause(); prog = 0f; exporting = true
                        tr = exportVideo(ctx, sp) { r ->
                            exporting = false
                            if (r.isSuccess) doneUri = r.getOrNull()
                            else Toast.makeText(ctx, "فشل التصدير: ${r.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                        }
                    }, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = RED)) { Text("ابدأ التصدير", fontSize = 16.sp) }
                }
            }
        }
    }

    fun panelTitle(p: String?) = when (p) {
        "clip" -> "سرعة وقص"; "format" -> "حجم الصورة"; "audio" -> "الصوت"; "stickers" -> "ملصقات"; "caps" -> "قائمة النصوص"
        "cap_anim" -> "الحركة"; "cap_pos" -> "التفاصيل"; "safe" -> "المنطقة الآمنة"; "templates" -> "قوالب النص"; "filter" -> "الفلتر"
        "adjust" -> "ضبط الألوان"; "crop" -> "تكبير وتحريك"; "trans" -> "الانتقالات"; "fx" -> "المؤثرات"; "ai" -> "✨ لمسة الذكية"
        "export" -> "خيارات التصدير"; else -> ""
    }

    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding().imePadding()
        .pointerInput(Unit) { detectTapGestures { vm.selCap = -1 } }) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ settings = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
            Spacer(Modifier.weight(1f))
            Text(vm.busy ?: vm.status, color = if (vm.busy != null) Color(0xFFB794FF) else Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(3f))
            Button({ doneUri = null; panel = "export"; editMode = false }, enabled = hasVideo, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = RED)) {
                Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(6.dp)); Text("تصدير")
            }
        }
        Box(Modifier.fillMaxWidth().weight(1f).padding(8.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.aspectRatio(ratio).background(Color.Black)) {
                AndroidView({ PlayerView(it).apply { this.player = player; useController = false } },
                    Modifier.fillMaxSize(), update = { it.resizeMode = if (vm.fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT })
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val fw = constraints.maxWidth; val fh = constraints.maxHeight
                    // منطقة لمس شفافة: ضغطة = تشغيل/إيقاف، وإذا كان هناك عنصر محدد تُلغي التحديد
                    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { if (vm.selCap >= 0) vm.selCap = -1 else toggle() } })
                    if (vm.capsVisible) vm.captions.forEachIndexed { i, c ->
                        if (pos in c.startMs..c.endMs) CaptionLayer(vm, i, c, pos, fw, fh, safeZ, i == vm.selCap) { startEdit(i) }
                    }
                    if (vm.showSafe) PLATFORMS[vm.platform].second?.let { z ->
                        Canvas(Modifier.fillMaxSize()) {
                            val red = Color(0x44FF0000)
                            drawRect(red, Offset.Zero, Size(size.width, size.height * z.top))
                            drawRect(red, Offset(0f, size.height * (1 - z.bottom)), Size(size.width, size.height * z.bottom))
                            drawRect(red, Offset(size.width * (1 - z.right), size.height * z.top), Size(size.width * z.right, size.height * (1 - z.top - z.bottom)))
                        }
                    }
                }
                if (!hasVideo) Button({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, Modifier.align(Alignment.Center)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("اختر فيديو")
                } else if (!playing && sel == null) Icon(Icons.Default.PlayCircle, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.align(Alignment.Center).size(56.dp))
            }
            Row(Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(ACCENT, RED))).clickable { panel = "ai"; editMode = false }.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp)); Text(vm.busy ?: "لمسة الذكية", color = Color.White, fontSize = 13.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.undo() }, enabled = vm.canUndo) { Icon(Icons.Default.Undo, null, tint = if (vm.canUndo) Color.White else Color.DarkGray) }
            IconButton({ vm.redo() }, enabled = vm.canRedo) { Icon(Icons.Default.Redo, null, tint = if (vm.canRedo) Color.White else Color.DarkGray) }
            Spacer(Modifier.weight(1f))
            Text("${fmt(pos)} / ${fmt(vm.totalMs)}", color = Color.White, fontSize = 12.sp)
            IconButton({ toggle() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
            Spacer(Modifier.weight(1f))
            if (sel != null || panel != null) IconButton({ vm.selCap = -1; panel = null; editMode = false }) { Icon(Icons.Default.Check, null, tint = Color.White) }
            else Spacer(Modifier.width(48.dp))
        }

        if (editMode && sel != null) {
            TextEditor(vm, vm.selCap, sel, fontOpts, { fontPicker.launch(arrayOf("*/*")) }, { cb -> hexCb = cb },
                onDone = { editMode = false }, onCancel = { editBackup?.let { b -> vm.modCap(vm.selCap) { b } }; editMode = false })
        } else if (panel != null) {
            Column(Modifier.fillMaxWidth().heightIn(max = 380.dp).background(PANEL)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ panel = null }) { Icon(Icons.Default.Check, null, tint = Color.White) }
                    Text(panelTitle(panel), color = Color.White, fontSize = 16.sp)
                }
                Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 12.dp)) { PanelBody() }
            }
        } else {
            if (sel != null) {
                Row(Modifier.fillMaxWidth().background(BG).horizontalScroll(rememberScrollState()).padding(vertical = 2.dp)) {
                    if (sel.img == null) Tool(Icons.Default.Edit, "تعديل", true) { startEdit(vm.selCap) }
                    Tool(Icons.Default.ContentCut, "تقسيم") { vm.splitCaption(vm.selCap, pos) }
                    Tool(Icons.Default.Delete, "حذف") { vm.removeCaption(vm.selCap) }
                    Tool(Icons.Default.ContentCopy, "نسخ") { vm.duplicateCap(vm.selCap) }
                    Tool(Icons.Default.Animation, "الحركة") { panel = "cap_anim" }
                    Tool(Icons.Default.Tune, "التفاصيل") { panel = "cap_pos" }
                    if (sel.img == null) Tool(Icons.Default.TextFields, "خط") { startEdit(vm.selCap); }
                }
            } else {
                Row(Modifier.fillMaxWidth().background(BG).horizontalScroll(rememberScrollState()).padding(vertical = 2.dp)) {
                    Tool(Icons.Default.TextFields, "نص") { vm.addCaption(pos) }
                    Tool(Icons.Default.EmojiEmotions, "ملصقات") { panel = "stickers" }
                    Tool(Icons.Default.AutoAwesomeMosaic, "قوالب نص") { panel = "templates" }
                    Tool(Icons.Default.PhoneAndroid, "المنطقة الآمنة") { panel = "safe" }
                    Tool(Icons.Default.ContentCut, "تقسيم") { vm.split(pos) }
                    Tool(Icons.Default.Delete, "حذف مقطع") { vm.deleteAt(pos) }
                    Tool(Icons.Default.Speed, "سرعة وقص") { panel = "clip" }
                    Tool(Icons.Default.AspectRatio, "حجم الصورة") { panel = "format" }
                    Tool(Icons.Default.MusicNote, "صوت") { panel = "audio" }
                    Tool(Icons.Default.ClosedCaption, "قائمة النصوص") { panel = "caps" }
                    Tool(Icons.Default.Tune, "فلتر") { panel = "filter" }
                    Tool(Icons.Default.Layers, "انتقالات") { panel = "trans" }
                    Tool(Icons.Default.Movie, "مؤثرات") { panel = "fx" }
                    Tool(Icons.Default.ZoomIn, "تكبير وتحريك") { panel = "crop" }
                    Tool(Icons.Default.Palette, "ضبط الألوان") { panel = "adjust" }
                }
            }
            // الخط الزمني: المؤشر ثابت بالمنتصف • اسحب للتنقل • اقرص للتكبير • مقابض لقص النص المحدد
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 6.dp, bottom = 10.dp)) {
                Column(Modifier.width(34.dp)) {
                    LayerBtn(44, if (vm.muteOriginal) Icons.Default.VolumeOff else Icons.Default.VolumeUp, !vm.muteOriginal) { vm.muteOriginal = !vm.muteOriginal }
                    Spacer(Modifier.height(4.dp))
                    LayerBtn(24, if (vm.capsVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff, vm.capsVisible) { vm.capsVisible = !vm.capsVisible }
                    Spacer(Modifier.height(4.dp))
                    LayerBtn(18, Icons.Default.MusicNote, vm.optSfx) { vm.optSfx = !vm.optSfx }
                }
                Canvas(Modifier.weight(1f).height(116.dp)
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            down.consume()
                            val ppm0 = zoom.dp.toPx() / 1000f
                            val s0 = vm.captions.getOrNull(vm.selCap)
                            var handle = 0
                            if (s0 != null && down.position.y in 44.dp.toPx()..76.dp.toPx()) {
                                val xs = size.width / 2f + (s0.startMs - pos) * ppm0
                                val xe = size.width / 2f + (s0.endMs - pos) * ppm0
                                if (abs(down.position.x - (xs - 12.dp.toPx())) < 24.dp.toPx()) handle = 1
                                else if (abs(down.position.x - (xe + 12.dp.toPx())) < 24.dp.toPx()) handle = 2
                            }
                            var total = 0f
                            do {
                                val ev = awaitPointerEvent()
                                val pan = ev.calculatePan(); val zm = ev.calculateZoom()
                                val ppm = zoom.dp.toPx() / 1000f
                                total += abs(pan.x) + abs(pan.y)
                                if (zm != 1f) zoom = (zoom * zm).coerceIn(10f, 300f)
                                if (total > 8.dp.toPx()) {
                                    val dms = (pan.x / ppm).toLong()
                                    val cur = vm.captions.getOrNull(vm.selCap)
                                    if (handle != 0 && cur != null) {
                                        if (handle == 1) vm.setCaptionTime(vm.selCap, (cur.startMs + dms).coerceIn(0, cur.endMs - 200), cur.endMs)
                                        else vm.setCaptionTime(vm.selCap, cur.startMs, (cur.endMs + dms).coerceAtLeast(cur.startMs + 200))
                                    } else if (dms != 0L) { if (player.playWhenReady) player.pause(); seekOut(pos - dms) }
                                }
                                ev.changes.forEach { if (it.positionChanged()) it.consume() }
                            } while (ev.changes.any { it.pressed })
                            if (total <= 8.dp.toPx()) {
                                val x = pos + ((down.position.x - size.width / 2f) / ppm0).toLong()
                                if (down.position.y in 48.dp.toPx()..72.dp.toPx()) {
                                    val i = vm.captions.indexOfFirst { x in it.startMs..it.endMs }
                                    if (i >= 0) { vm.selCap = i; seekOut(vm.captions[i].startMs + 1); return@awaitEachGesture }
                                }
                                vm.selCap = -1; seekOut(x)
                            }
                        }
                    }) {
                    val w = size.width; val cx = w / 2; val ppm = zoom.dp.toPx() / 1000f
                    fun X(t: Long) = cx + (t - pos) * ppm
                    val h1 = 44.dp.toPx(); val st0 = vm.starts(); val total = vm.totalMs
                    val cur = if (vm.clips.isEmpty()) -1 else vm.clipAt(pos)
                    vm.clips.forEachIndexed { i, c ->
                        val x0 = X(st0[i]); val x1 = X(st0[i] + c.outMs)
                        if (x1 < 0 || x0 > w) return@forEachIndexed
                        val cw0 = x1 - x0
                        drawRoundRect(Color(0xFF2A2A33), Offset(x0, 0f), Size(cw0, h1), CornerRadius(6.dp.toPx()))
                        val th = vm.thumbs[c.src]
                        if (!th.isNullOrEmpty()) {
                            val cell = (h1 * th[0].width / th[0].height).coerceAtLeast(8f)
                            clipRect(x0, 0f, x1, h1) {
                                val n = (cw0 / cell).toInt() + 1
                                for (k in 0 until n) {
                                    val xk = x0 + k * cell
                                    if (xk + cell < 0 || xk > w) continue
                                    val frac = (k * cell / cw0).coerceIn(0f, 0.999f)
                                    val srcT = c.s + ((c.e - c.s) * frac).toLong()
                                    val img = th[(srcT.toFloat() / vm.sources[c.src].durationMs * th.size).toInt().coerceIn(0, th.size - 1)]
                                    drawImage(img, IntOffset.Zero, IntSize(img.width, img.height), IntOffset(xk.toInt(), 0), IntSize(cell.toInt() + 1, h1.toInt()))
                                }
                            }
                        }
                        drawRoundRect(if (i == cur) Color.White else ACCENT, Offset(x0, 0f), Size(cw0, h1), CornerRadius(6.dp.toPx()), Stroke(if (i == cur) 3.dp.toPx() else 1.5.dp.toPx()))
                        if (c.speed != 1f) drawRoundRect(Color(0xFFFF9800), Offset(x0 + 4.dp.toPx(), 4.dp.toPx()), Size(22.dp.toPx(), 10.dp.toPx()), CornerRadius(3.dp.toPx()))
                    }
                    vm.captions.forEachIndexed { i, c ->
                        val x0 = X(c.startMs); val cw0 = maxOf(4f, (c.endMs - c.startMs) * ppm)
                        val base = if (!vm.capsVisible) Color(0xFF555560) else if (c.img != null) Color(0xFFEC407A) else GREEN
                        drawRoundRect(base, Offset(x0, 48.dp.toPx()), Size(cw0, 24.dp.toPx()), CornerRadius(5.dp.toPx()))
                        if (i == vm.selCap) {
                            drawRoundRect(Color.White, Offset(x0, 48.dp.toPx()), Size(cw0, 24.dp.toPx()), CornerRadius(5.dp.toPx()), Stroke(2.dp.toPx()))
                            for (side in 0..1) {
                                val hx = if (side == 0) x0 - 22.dp.toPx() else x0 + cw0 + 2.dp.toPx()
                                drawRoundRect(Color.White, Offset(hx, 46.dp.toPx()), Size(20.dp.toPx(), 28.dp.toPx()), CornerRadius(5.dp.toPx()))
                                val mx = hx + 10.dp.toPx(); val dir = if (side == 0) 1f else -1f
                                drawLine(Color.DarkGray, Offset(mx + 3.dp.toPx() * dir, 54.dp.toPx()), Offset(mx - 3.dp.toPx() * dir, 60.dp.toPx()), 2.dp.toPx())
                                drawLine(Color.DarkGray, Offset(mx - 3.dp.toPx() * dir, 60.dp.toPx()), Offset(mx + 3.dp.toPx() * dir, 66.dp.toPx()), 2.dp.toPx())
                            }
                        }
                    }
                    if (vm.music != null) drawRoundRect(Color(0xFF26A69A), Offset(X(0), 76.dp.toPx()), Size(total * ppm, 18.dp.toPx()), CornerRadius(5.dp.toPx()))
                    vm.voice?.let { v -> drawRoundRect(Color(0xFFEF5350), Offset(X(vm.voiceStart), 76.dp.toPx()), Size((v.size / 44.1f) * ppm, 9.dp.toPx()), CornerRadius(3.dp.toPx())) }
                    if (vm.optSfx) st0.drop(1).forEach { drawRect(Color(0xFFFF9800), Offset(X(it) - 1.dp.toPx(), 76.dp.toPx()), Size(3.dp.toPx(), 18.dp.toPx())) }
                    val step = if (zoom >= 100f) 1000L else if (zoom >= 40f) 2000L else 5000L
                    paint.textSize = 10.sp.toPx()
                    var t = (((pos - (cx / ppm).toLong()).coerceAtLeast(0)) / step) * step
                    while (X(t) < w + 40 && t <= total) {
                        val x = X(t)
                        drawRect(Color.Gray, Offset(x, 98.dp.toPx()), Size(1.dp.toPx(), 5.dp.toPx()))
                        drawContext.canvas.nativeCanvas.drawText("%d:%02d".format(t / 60000, (t / 1000) % 60), x - 8.dp.toPx(), 114.dp.toPx(), paint)
                        t += step
                    }
                    drawRect(Color.White, Offset(cx - 1.5.dp.toPx(), 0f), Size(3.dp.toPx(), size.height))
                }
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(RED)
                    .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, null, tint = Color.White)
                }
            }
        }
    }

    hexCb?.let { cb ->
        var h by remember { mutableStateOf("#FFFFFF") }
        AlertDialog(onDismissRequest = { hexCb = null },
            confirmButton = { TextButton({ runCatching { android.graphics.Color.parseColor(h) }.getOrNull()?.let(cb); hexCb = null }) { Text("تطبيق") } },
            title = { Text("لون مخصص") },
            text = { OutlinedTextField(h, { h = it }, singleLine = true, label = { Text("#RRGGBB") }) })
    }

    if (settings) {
        var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var lang by remember { mutableStateOf(prefs.getString("lang", "ar") ?: "ar") }
        var url by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
        AlertDialog(onDismissRequest = { settings = false },
            confirmButton = { TextButton({ prefs.edit().putString("key", key.trim()).putString("lang", lang.trim()).putString("url", url.trim()).apply(); settings = false }) { Text("حفظ") } },
            title = { Text("الإعدادات") },
            text = {
                Column {
                    Text("مفتاح Groq المجاني لتحويل الكلام إلى نص (console.groq.com)", fontSize = 12.sp)
                    OutlinedTextField(key, { key = it }, label = { Text("API Key") }, singleLine = true)
                    OutlinedTextField(lang, { lang = it }, label = { Text("لغة الكلام (ar / en / فارغ=تلقائي)") }, singleLine = true)
                    OutlinedTextField(url, { url = it }, label = { Text("عنوان الخدمة (اختياري)") }, singleLine = true)
                    if (BuildConfig.GROQ_KEY.isNotBlank()) Text("✓ مفتاح مدمج في التطبيق، لا حاجة لإدخاله", fontSize = 11.sp)
                }
            })
    }
}
