package com.example.editfast

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.ui.graphics.Brush
import android.Manifest
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.io.File

private val BG = Color(0xFF1E1E22)
private val PANEL = Color(0xFF17171C)
private val ACCENT = Color(0xFF8B5CF6)
private val RED = Color(0xFFFF3B5C)
private val SPEEDS = listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = ACCENT)) { EditorScreen() } }
    }
}

private fun fmt(ms: Long) = "%d:%02d.%d".format(ms / 60000, (ms / 1000) % 60, (ms / 100) % 10)

@Composable
private fun Tool(icon: ImageVector, label: String, hi: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.width(72.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (hi) Color(0xFFB794FF) else Color.White, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(5.dp)); Text(label, fontSize = 10.sp, color = Color.LightGray, maxLines = 1)
    }
}

@Composable
private fun Opt(label: String, on: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f)); Switch(on, set)
    }
}

@Composable
private fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            Box(Modifier.size(34.dp).clip(CircleShape).background(if (c == 0) Color(0xFF2A2A36) else Color(c))
                .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Color.White else Color.Gray, CircleShape)
                .clickable { onPick(c) }, contentAlignment = Alignment.Center) { if (c == 0) Text("∅", color = Color.White) }
        }
    }
}

@Composable
private fun LayerBtn(h: Int, icon: ImageVector, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.height(h.dp).width(34.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (on) Color.White else Color(0xFF666670), modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun Chips(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, n -> FilterChip(sel == i, { onSel(i) }, { Text(n) }) }
    }
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) {
        // إيقاف التشغيل عند نهاية الفيديو كي لا يعود ويعمل تلقائياً بعد السحب للبداية
        val l = object : Player.Listener { override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED) player.pause() } }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    var pos by remember { mutableLongStateOf(0L) }          // موضع التشغيل على خط الناتج
    var playing by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(60f) }       // dp لكل ثانية
    var panel by remember { mutableStateOf<String?>(null) }
    var settings by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var prog by remember { mutableFloatStateOf(0f) }
    var tr by remember { mutableStateOf<Transformer?>(null) }
    var doneUri by remember { mutableStateOf<Uri?>(null) }
    val paint = remember { android.graphics.Paint().apply { color = android.graphics.Color.GRAY; isAntiAlias = true } }
    val customFonts = remember { mutableStateListOf<File>().apply { addAll(ctx.filesDir.listFiles { f -> f.name.startsWith("font_") }.orEmpty()) } }

    fun seekOut(t: Long) {
        if (vm.clips.isEmpty() || player.mediaItemCount != vm.clips.size) return
        val tt = t.coerceIn(0, vm.totalMs); val i = vm.clipAt(tt)
        player.seekTo(i, ((tt - vm.starts()[i]) * vm.clips[i].speed).toLong()); pos = tt
    }
    fun curOut(): Long {
        val i = player.currentMediaItemIndex
        if (i !in vm.clips.indices) return 0
        return vm.starts()[i] + (player.currentPosition / vm.clips[i].speed).toLong()
    }
    fun toggle() {
        if (vm.clips.isEmpty()) return
        if (player.playWhenReady && player.playbackState != Player.STATE_ENDED) player.pause()
        else { if (player.playbackState == Player.STATE_ENDED) seekOut(0); player.play() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            val m = MediaMetadataRetriever().apply { setDataSource(ctx, u) }
            val d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            var w = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toFloat() ?: 9f
            var h = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toFloat() ?: 16f
            val rot = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
            m.release(); if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            vm.addSource(ctx, u, d, w / h)
        }
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val name = (u.lastPathSegment ?: "font").substringAfterLast('/').substringBeforeLast('.')
            val f = File(ctx.filesDir, "font_$name.ttf")
            ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            if (customFonts.none { it.name == f.name }) customFonts.add(f)
            vm.updStyle(vm.selCap) { it.copy(font = name, fontPath = f.path) }
        }
    }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { vm.music = u; vm.musicName = (u.lastPathSegment ?: "موسيقى").substringAfterLast('/') }
    }

    val stickerPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            val f = File(ctx.filesDir, "sticker_${System.currentTimeMillis()}.img")
            ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            vm.addSticker(pos, f.path)
        }
    }
    val voiceRec = remember { VoiceRec() }
    fun startVoice() { vm.voiceStart = pos; voiceRec.start(); vm.recording = true; player.play() }
    fun stopVoice() { vm.voice = voiceRec.stop(); vm.recording = false; player.pause() }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) startVoice() }
    // إعادة بناء قائمة التشغيل عند تعديل المقاطع
    LaunchedEffect(vm.version) {
        if (vm.clips.isEmpty()) { player.clearMediaItems(); return@LaunchedEffect }
        val t = pos
        player.setMediaItems(vm.clips.map { c ->
            MediaItem.Builder().setUri(vm.sources[c.src].uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()).build()
        }, false)
        player.prepare(); seekOut(t)
    }
    LaunchedEffect(Unit) {
        while (true) {
            if (vm.clips.isNotEmpty() && player.mediaItemCount == vm.clips.size) {
                val sp = vm.clips[player.currentMediaItemIndex.coerceIn(0, vm.clips.lastIndex)].speed
                if (player.playbackParameters.speed != sp) player.setPlaybackSpeed(sp)
                if (player.isPlaying) pos = curOut()
            }
            playing = player.playWhenReady && player.playbackState != Player.STATE_ENDED && player.playbackState != Player.STATE_IDLE; delay(40)
        }
    }
    val look = vm.look()
    LaunchedEffect(look) { try { player.setVideoEffects(lookEffects(look)) } catch (_: Exception) {} }
    LaunchedEffect(exporting) {
        while (exporting) { val h = ProgressHolder(); if (tr?.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) prog = h.progress / 100f; delay(300) }
    }

    val ratio = if (vm.formatIdx == 0) vm.baseRatio() else FORMATS[vm.formatIdx].second
    val hasVideo = vm.clips.isNotEmpty()
    val safeZ = vm.safeFor(ratio)

    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ settings = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
            Spacer(Modifier.weight(1f))
            Text(vm.busy ?: vm.status, color = if (vm.busy != null) Color(0xFFB794FF) else Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(3f))
            Button({ doneUri = null; panel = "export" }, enabled = hasVideo, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = RED)) {
                Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(6.dp)); Text("تصدير")
            }
        }
        Box(Modifier.fillMaxWidth().weight(1f).padding(8.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.aspectRatio(ratio).background(Color.Black).clickable { if (vm.selCap >= 0) vm.selCap = -1 else toggle() }) {
                AndroidView({ PlayerView(it).apply { this.player = player; useController = false } },
                    Modifier.fillMaxSize(), update = { it.resizeMode = if (vm.fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT })
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val fw = constraints.maxWidth; val fh = constraints.maxHeight
                    if (vm.capsVisible) vm.captions.forEachIndexed { i, c ->
                        if (pos in c.startMs..c.endMs) CaptionLayer(vm, i, c, pos, fw, fh, safeZ, i == vm.selCap)
                    }
                    if (vm.showSafe) PLATFORMS[vm.platform].second?.let { z ->
                        Canvas(Modifier.fillMaxSize()) {
                            val red = Color(0x44FF0000)
                            drawRect(red, Offset.Zero, Size(size.width, size.height * z.top))
                            drawRect(red, Offset(0f, size.height * (1 - z.bottom)), Size(size.width, size.height * z.bottom))
                            drawRect(red, Offset(size.width * (1 - z.right), size.height * z.top), Size(size.width * z.right, size.height * (1 - z.top - z.bottom)))
                        }
                    }
                }
                if (!hasVideo) Button({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, Modifier.align(Alignment.Center)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("اختر فيديو")
                } else if (!playing) Icon(Icons.Default.PlayCircle, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.align(Alignment.Center).size(56.dp))
            }
            Row(Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(ACCENT, RED))).clickable { panel = "ai" }.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp)); Text(vm.busy ?: "لمسة الذكية", color = Color.White, fontSize = 13.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${fmt(pos)} / ${fmt(vm.totalMs)}", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            IconButton({ toggle() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                IconButton({ vm.undo() }, enabled = vm.canUndo) { Icon(Icons.Default.Undo, null, tint = if (vm.canUndo) Color.White else Color.DarkGray) }
                IconButton({ vm.redo() }, enabled = vm.canRedo) { Icon(Icons.Default.Redo, null, tint = if (vm.canRedo) Color.White else Color.DarkGray) }
            }
        }
        if (vm.selCap in vm.captions.indices) {
            Row(Modifier.fillMaxWidth().background(BG).horizontalScroll(rememberScrollState()).padding(vertical = 2.dp)) {
                Tool(Icons.Default.Edit, "تعديل", true) { panel = "cap_edit" }
                Tool(Icons.Default.TextFields, "الخط والتنسيق") { panel = "cap_style" }
                Tool(Icons.Default.Animation, "الحركة") { panel = "cap_anim" }
                Tool(Icons.Default.CropSquare, "الصندوق") { panel = "cap_box" }
                Tool(Icons.Default.OpenWith, "الموضع الآمن") { panel = "cap_pos" }
                Tool(Icons.Default.ContentCopy, "نسخ") { vm.duplicateCap(vm.selCap) }
                Tool(Icons.Default.Delete, "حذف") { vm.removeCaption(vm.selCap) }
                Tool(Icons.Default.Close, "إغلاق") { vm.selCap = -1 }
            }
        } else {
            Row(Modifier.fillMaxWidth().background(BG).horizontalScroll(rememberScrollState()).padding(vertical = 2.dp)) {
                Tool(Icons.Default.TextFields, "نص") { vm.addCaption(pos) }
                Tool(Icons.Default.EmojiEmotions, "ملصقات") { panel = "stickers" }
                Tool(Icons.Default.AutoAwesomeMosaic, "قوالب نص") { panel = "templates" }
                Tool(Icons.Default.PhoneAndroid, "المنطقة الآمنة") { panel = "safe" }
                Tool(Icons.Default.ContentCut, "تقسيم") { vm.split(pos) }
                Tool(Icons.Default.Delete, "حذف مقطع") { vm.deleteAt(pos) }
                Tool(Icons.Default.Speed, "سرعة وقص") { panel = "clip" }
                Tool(Icons.Default.AspectRatio, "حجم الصورة") { panel = "format" }
                Tool(Icons.Default.MusicNote, "صوت") { panel = "audio" }
                Tool(Icons.Default.ClosedCaption, "قائمة النصوص") { panel = "caps" }
                Tool(Icons.Default.Tune, "فلتر") { panel = "filter" }
                Tool(Icons.Default.Layers, "انتقالات") { panel = "trans" }
                Tool(Icons.Default.ZoomIn, "تكبير وتحريك") { panel = "crop" }
                Tool(Icons.Default.Palette, "ضبط الألوان") { panel = "adjust" }
            }
        }
        // خط زمني متحرك: المؤشر ثابت بالمنتصف • اسحب للتنقل • اقرص للتكبير
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 6.dp, bottom = 10.dp)) {
            Column(Modifier.width(34.dp)) {
                LayerBtn(44, if (vm.muteOriginal) Icons.Default.VolumeOff else Icons.Default.VolumeUp, !vm.muteOriginal) { vm.muteOriginal = !vm.muteOriginal }
                Spacer(Modifier.height(4.dp))
                LayerBtn(24, if (vm.capsVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff, vm.capsVisible) { vm.capsVisible = !vm.capsVisible }
                Spacer(Modifier.height(4.dp))
                LayerBtn(18, Icons.Default.MusicNote, vm.optSfx) { vm.optSfx = !vm.optSfx }
            }
            Canvas(Modifier.weight(1f).height(116.dp)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, z, _ ->
                        if (player.playWhenReady) player.pause()
                        if (z != 1f) zoom = (zoom * z).coerceIn(10f, 300f)
                        seekOut(pos - (pan.x / (zoom.dp.toPx() / 1000f)).toLong())
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { o ->
                        val t = pos + ((o.x - size.width / 2f) / (zoom.dp.toPx() / 1000f)).toLong()
                        if (o.y in 48.dp.toPx()..72.dp.toPx()) {
                            val i = vm.captions.indexOfFirst { t in it.startMs..it.endMs }
                            if (i >= 0) { vm.selCap = i; seekOut(vm.captions[i].startMs + 1); return@detectTapGestures }
                        }
                        seekOut(t)
                    }
                }) {
                val w = size.width; val cx = w / 2; val ppm = zoom.dp.toPx() / 1000f
                fun X(t: Long) = cx + (t - pos) * ppm
                val h1 = 44.dp.toPx(); val st0 = vm.starts(); val total = vm.totalMs
                val cur = if (vm.clips.isEmpty()) -1 else vm.clipAt(pos)
                vm.clips.forEachIndexed { i, c ->
                    val x0 = X(st0[i]); val x1 = X(st0[i] + c.outMs)
                    if (x1 < 0 || x0 > w) return@forEachIndexed
                    val cw0 = x1 - x0
                    drawRoundRect(Color(0xFF2A2A33), Offset(x0, 0f), Size(cw0, h1), CornerRadius(6.dp.toPx()))
                    val th = vm.thumbs[c.src]
                    if (!th.isNullOrEmpty()) {
                        val cell = (h1 * th[0].width / th[0].height).coerceAtLeast(8f)
                        clipRect(x0, 0f, x1, h1) {
                            val n = (cw0 / cell).toInt() + 1
                            for (k in 0 until n) {
                                val xk = x0 + k * cell
                                if (xk + cell < 0 || xk > w) continue
                                val frac = (k * cell / cw0).coerceIn(0f, 0.999f)
                                val srcT = c.s + ((c.e - c.s) * frac).toLong()
                                val img = th[(srcT.toFloat() / vm.sources[c.src].durationMs * th.size).toInt().coerceIn(0, th.size - 1)]
                                drawImage(img, IntOffset.Zero, IntSize(img.width, img.height), IntOffset(xk.toInt(), 0), IntSize(cell.toInt() + 1, h1.toInt()))
                            }
                        }
                    }
                    drawRoundRect(if (i == cur) Color.White else ACCENT, Offset(x0, 0f), Size(cw0, h1), CornerRadius(6.dp.toPx()), Stroke(if (i == cur) 3.dp.toPx() else 1.5.dp.toPx()))
                    if (c.speed != 1f) drawRoundRect(Color(0xFFFF9800), Offset(x0 + 4.dp.toPx(), 4.dp.toPx()), Size(22.dp.toPx(), 10.dp.toPx()), CornerRadius(3.dp.toPx()))
                }
                vm.captions.forEachIndexed { i, c ->
                    val x0 = X(c.startMs); val cw0 = maxOf(4f, (c.endMs - c.startMs) * ppm)
                    drawRoundRect(if (vm.capsVisible) Color(0xFFFFC107) else Color(0xFF555560), Offset(x0, 48.dp.toPx()), Size(cw0, 24.dp.toPx()), CornerRadius(5.dp.toPx()))
                    if (i == vm.selCap) drawRoundRect(Color.White, Offset(x0, 48.dp.toPx()), Size(cw0, 24.dp.toPx()), CornerRadius(5.dp.toPx()), Stroke(2.dp.toPx()))
                }
                if (vm.music != null) drawRoundRect(Color(0xFF26A69A), Offset(X(0), 76.dp.toPx()), Size(total * ppm, 18.dp.toPx()), CornerRadius(5.dp.toPx()))
                vm.voice?.let { v -> drawRoundRect(Color(0xFFEF5350), Offset(X(vm.voiceStart), 76.dp.toPx()), Size((v.size / 44.1f) * ppm, 9.dp.toPx()), CornerRadius(3.dp.toPx())) }
                if (vm.optSfx) st0.drop(1).forEach { drawRect(Color(0xFFFF9800), Offset(X(it) - 1.dp.toPx(), 76.dp.toPx()), Size(3.dp.toPx(), 18.dp.toPx())) }
                // المسطرة الزمنية
                val step = if (zoom >= 100f) 1000L else if (zoom >= 40f) 2000L else 5000L
                paint.textSize = 10.sp.toPx()
                var t = (((pos - (cx / ppm).toLong()).coerceAtLeast(0)) / step) * step
                while (X(t) < w + 40 && t <= total) {
                    val x = X(t)
                    drawRect(Color.Gray, Offset(x, 98.dp.toPx()), Size(1.dp.toPx(), 5.dp.toPx()))
                    drawContext.canvas.nativeCanvas.drawText("%d:%02d".format(t / 60000, (t / 1000) % 60), x - 8.dp.toPx(), 114.dp.toPx(), paint)
                    t += step
                }
                drawRect(Color.White, Offset(cx - 1.5.dp.toPx(), 0f), Size(3.dp.toPx(), size.height))
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(RED)
                .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, null, tint = Color.White)
            }
        }
    }

    if (panel != null) ModalBottomSheet({ panel = null }, containerColor = PANEL) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            when (panel) {
                "clip" -> {
                    val i = if (hasVideo) vm.clipAt(pos) else -1
                    val c = vm.clips.getOrNull(i)
                    if (c == null) Text("أضف فيديو أولاً", color = Color.Gray) else {
                        Text("المقطع ${i + 1} من ${vm.clips.size}  •  السرعة ${c.speed}x", color = Color.White, fontSize = 16.sp)
                        Chips(SPEEDS.map { "${it}x" }, SPEEDS.indexOf(c.speed)) { vm.setSpeedAt(pos, SPEEDS[it]) }
                        Text("قص المقطع", color = Color.White, modifier = Modifier.padding(top = 10.dp))
                        RangeSlider(c.s.toFloat()..c.e.toFloat(), { vm.setTrimAt(pos, it.start.toLong(), it.endInclusive.toLong()) },
                            valueRange = 0f..vm.sources[c.src].durationMs.toFloat())
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton({ vm.moveAt(pos, -1) }) { Text("⬅ تقديم") }
                            TextButton({ vm.moveAt(pos, 1) }) { Text("تأخير ➡") }
                            TextButton({ vm.duplicateAt(pos) }) { Text("نسخ") }
                            TextButton({ vm.deleteAt(pos) }) { Text("حذف") }
                        }
                        Text("ملاحظة: تغيير السرعة والقص يحرّك الكابشن اللاحق تلقائياً.", color = Color.Gray, fontSize = 11.sp)
                    }
                }
                "format" -> {
                    Text("حجم الصورة", color = Color.White, fontSize = 16.sp)
                    FORMATS.forEachIndexed { i, (n, _) ->
                        Row(Modifier.fillMaxWidth().clickable { vm.formatIdx = i }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(vm.formatIdx == i, { vm.formatIdx = i }); Text(n, color = Color.White)
                        }
                    }
                    Opt("ملء الإطار (قص الأطراف) بدل الأشرطة السوداء", vm.fill) { vm.fill = it }
                    Text("التدوير", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                    Chips(listOf("0°", "90°", "180°", "270°"), vm.rotate / 90) { vm.rotate = it * 90 }
                    Opt("قلب أفقي (مرآة)", vm.flip) { vm.flip = it }
                }
                "audio" -> {
                    Text("الصوت", color = Color.White, fontSize = 16.sp)
                    Opt("المؤثرات الصوتية (عند القطع والكابشن)", vm.optSfx) { vm.optSfx = it }
                    Opt("كتم صوت الفيديو الأصلي", vm.muteOriginal) { vm.muteOriginal = it }
                    Text("مستوى صوت الفيديو", color = Color.White); Slider(vm.origVol, { vm.origVol = it }, valueRange = 0f..1.5f)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button({ musicPicker.launch(arrayOf("audio/*")) }) { Icon(Icons.Default.MusicNote, null); Text(" إضافة موسيقى") }
                        if (vm.music != null) {
                            Text(vm.musicName, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(1f).padding(start = 8.dp), maxLines = 1)
                            IconButton({ vm.music = null }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                        Button({
                            if (vm.recording) stopVoice()
                            else if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) startVoice()
                            else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                        }, colors = ButtonDefaults.buttonColors(containerColor = if (vm.recording) RED else ACCENT)) {
                            Icon(Icons.Default.Mic, null); Text(if (vm.recording) " إيقاف التسجيل" else " تسجيل تعليق صوتي")
                        }
                        if (vm.voice != null && !vm.recording) IconButton({ vm.voice = null }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                    }
                    Text("يُسجَّل التعليق أثناء تشغيل الفيديو (يُفضّل استخدام سماعات).", color = Color.Gray, fontSize = 11.sp)
                    if (vm.music != null) { Text("مستوى الموسيقى", color = Color.White); Slider(vm.musicVol, { vm.musicVol = it }, valueRange = 0.05f..1f) }
                }
                "stickers" -> {
                    Text("ملصقات (إيموجي)", color = Color.White, fontSize = 16.sp)
                    listOf("😂🔥❤️👍😍😎🤩🥳", "👏💯✨⭐🎉💥🚀✅", "👀🙏💪🎬📌⚡🤔😱").forEach { row ->
                        Row(Modifier.horizontalScroll(rememberScrollState())) {
                            row.chunked(2).forEach { e -> TextButton({ vm.addEmoji(pos, e); panel = null }) { Text(e, fontSize = 30.sp) } }
                        }
                    }
                    Button({ stickerPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)); panel = null }) { Icon(Icons.Default.Image, null); Text(" ملصق من صورة") }
                    Text("يُضاف الملصق عند موضع التشغيل؛ اضغط عليه في المعاينة لتحريكه وتغيير حجمه وحركته.", color = Color.Gray, fontSize = 11.sp)
                }
                "caps" -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("تعديل الكابشن", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        TextButton({ vm.addCaption(pos) }) { Icon(Icons.Default.Add, null); Text("إضافة هنا") }
                    }
                    LazyColumn(Modifier.heightIn(max = 440.dp)) {
                        itemsIndexed(vm.captions) { i, c ->
                            Column(Modifier.padding(vertical = 2.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(fmt(c.startMs), color = if (i == vm.selCap) Color.White else Color(0xFFFFC107), fontSize = 12.sp,
                                        modifier = Modifier.clickable { vm.selCap = i; seekOut(c.startMs) }.padding(end = 8.dp))
                                    OutlinedTextField(c.text, { vm.editCaption(i, it) }, Modifier.weight(1f), singleLine = true)
                                    IconButton({ vm.removeCaption(i) }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                                }
                                if (i == vm.selCap) RangeSlider(c.startMs.toFloat()..c.endMs.toFloat(),
                                    { vm.setCaptionTime(i, it.start.toLong(), it.endInclusive.toLong()) }, valueRange = 0f..maxOf(vm.totalMs, c.endMs).toFloat())
                            }
                        }
                    }
                    if (vm.captions.isEmpty()) Text("لا يوجد كابشن — استخدم «مونتاج تلقائي» أو أضف يدوياً", color = Color.Gray, fontSize = 12.sp)
                }
                "cap_edit" -> {
                    val i = vm.selCap; val c = vm.captions.getOrNull(i)
                    if (c != null) {
                        Text("تعديل النص", color = Color.White, fontSize = 16.sp)
                        if (c.img == null) OutlinedTextField(c.text, { vm.editCaption(i, it) }, Modifier.fillMaxWidth())
                        Text("المحاذاة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                        Chips(listOf("بداية السطر", "وسط", "نهاية السطر"), c.st.align) { v -> vm.updStyle(i) { it.copy(align = v) } }
                        Text("أقصى عرض للنص", color = Color.White)
                        Slider(c.st.maxW, { v -> vm.updStyle(i) { it.copy(maxW = v) } }, valueRange = 0.3f..0.95f)
                        Text("التوقيت", color = Color.White)
                        RangeSlider(c.startMs.toFloat()..c.endMs.toFloat(), { vm.setCaptionTime(i, it.start.toLong(), it.endInclusive.toLong()) },
                            valueRange = 0f..maxOf(vm.totalMs, c.endMs).toFloat())
                    }
                }
                "cap_style" -> {
                    val i = vm.selCap; val c = vm.captions.getOrNull(i)
                    if (c != null) {
                        Text("الخط", color = Color.White)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("sans-serif" to "عادي", "sans-serif-medium" to "متوسط", "serif" to "Serif", "monospace" to "Mono", "casual" to "Casual", "cursive" to "Cursive", "sans-serif-condensed" to "ضيّق").forEach { (k, n) ->
                                FilterChip(c.st.font == k && c.st.fontPath == null, { vm.updStyle(i) { it.copy(font = k, fontPath = null) } }, { Text(n) })
                            }
                            customFonts.forEach { f ->
                                val n = f.name.removePrefix("font_").removeSuffix(".ttf")
                                FilterChip(c.st.fontPath == f.path, { vm.updStyle(i) { it.copy(font = n, fontPath = f.path) } }, { Text(n) })
                            }
                            AssistChip({ fontPicker.launch(arrayOf("*/*")) }, { Text("+ خط من الجهاز") })
                        }
                        Text("الحجم", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                        Slider(c.st.size, { v -> vm.updStyle(i) { it.copy(size = v) } }, valueRange = 0.4f..3f)
                        Text("لون النص", color = Color.White)
                        Swatches(listOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFF00E5FF, 0xFF69F0AE, 0xFFFF4081, 0xFFFF9100, 0xFF000000).map { it.toInt() }, c.st.color) { v -> vm.updStyle(i) { it.copy(color = v) } }
                        Opt("خط عريض", c.st.bold) { v -> vm.updStyle(i) { it.copy(bold = v) } }
                        Opt("حدود حول النص", c.st.outline) { v -> vm.updStyle(i) { it.copy(outline = v) } }
                        if (c.st.outline) Swatches(listOf(0xFF000000, 0xFFFFFFFF, 0xFFFF4081, 0xFF6D4AFF).map { it.toInt() }, c.st.outlineColor) { v -> vm.updStyle(i) { it.copy(outlineColor = v) } }
                        Opt("ظل", c.st.shadow) { v -> vm.updStyle(i) { it.copy(shadow = v) } }
                        TextButton({ vm.applyStyleToAll(i) }) { Text("تطبيق هذا التنسيق على كل النصوص") }
                    }
                }
                "cap_anim" -> {
                    val i = vm.selCap; val c = vm.captions.getOrNull(i)
                    if (c != null) {
                        Text("طريقة الظهور", color = Color.White, fontSize = 16.sp)
                        Chips(ANIMS, c.st.anim) { v -> vm.updStyle(i) { it.copy(anim = v) } }
                        Text("الاختفاء", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                        Chips(listOf("بدون", "تلاشي"), c.st.animOut) { v -> vm.updStyle(i) { it.copy(animOut = v) } }
                        Text("مدة الحركة ${c.st.animMs} مللي ثانية", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                        Slider(c.st.animMs.toFloat(), { v -> vm.updStyle(i) { it.copy(animMs = v.toLong()) } }, valueRange = 100f..1200f)
                        Text("اضغط تشغيل لمعاينة الحركة.", color = Color.Gray, fontSize = 11.sp)
                    }
                }
                "cap_box" -> {
                    val i = vm.selCap; val c = vm.captions.getOrNull(i)
                    if (c != null) {
                        Text("صندوق خلف النص", color = Color.White, fontSize = 16.sp)
                        Chips(listOf("بدون", "مربع", "دائري"), c.st.boxMode) { v -> vm.updStyle(i) { it.copy(boxMode = v) } }
                        if (c.st.boxMode != 0) {
                            Text("لون الصندوق", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                            Swatches(listOf(0xCC000000, 0xFF000000, 0xCCFFFFFF, 0xFFFFEB3B, 0xFF6D4AFF, 0xFFFF4081, 0xFF69F0AE).map { it.toInt() }, c.st.boxColor) { v -> vm.updStyle(i) { it.copy(boxColor = v) } }
                            Text("الحشوة", color = Color.White)
                            Slider(c.st.boxPad, { v -> vm.updStyle(i) { it.copy(boxPad = v) } }, valueRange = 0.3f..2.5f)
                        }
                    }
                }
                "cap_pos", "safe" -> {
                    Text("الموضع والمنطقة الآمنة", color = Color.White, fontSize = 16.sp)
                    Text("المنصة", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                    Chips(PLATFORMS.map { it.first }, vm.platform) { vm.platform = it }
                    Opt("إظهار المناطق الآمنة في المعاينة (الأحمر = تغطيه أزرار المنصة)", vm.showSafe) { vm.showSafe = it }
                    Opt("إبقاء النص داخل المنطقة الآمنة تلقائياً", vm.clampSafe) { vm.clampSafe = it }
                    val z = PLATFORMS[vm.platform].second
                    val sel = vm.selCap
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("أعلى", "وسط", "أسفل").forEachIndexed { k, n ->
                            OutlinedButton({ if (panel == "cap_pos" && sel in vm.captions.indices) vm.updStyle(sel) { it.copy(y = presetY(z, k), x = 0f) } else vm.setAllY(presetY(z, k)) }) {
                                Text(if (panel == "cap_pos") n else "$n (الكل)")
                            }
                        }
                    }
                    Text("اسحب النص في المعاينة لتحريكه، واقرص لتغيير حجمه. المناطق تقريبية وتعمل على الفيديو العمودي 9:16.", color = Color.Gray, fontSize = 11.sp)
                }
                "templates" -> {
                    Text("قوالب النص (لون وحركة وصندوق)", color = Color.White, fontSize = 16.sp)
                    Chips(TEMPLATES.map { it.first }, -1) { k ->
                        val t = TEMPLATES[k].second; val i = vm.selCap
                        if (i in vm.captions.indices) vm.updStyle(i) { c -> t.copy(x = c.x, y = c.y, size = c.size) } else vm.defStyle = t.copy(y = vm.defStyle.y)
                    }
                    Text("يُطبَّق على النص المحدد، أو على النصوص الجديدة إن لم يكن هناك نص محدد.", color = Color.Gray, fontSize = 11.sp)
                }
                "ai" -> {
                    Text("✨ لمسة الذكية", color = Color.White, fontSize = 20.sp)
                    Text("مونتاج تلقائي بضغطة واحدة", color = Color.Gray, fontSize = 12.sp)
                    Opt("قص السكتات", vm.optSilence) { vm.optSilence = it }
                    Opt("كابشن تلقائي", vm.optCaptions) { vm.optCaptions = it }
                    Opt("زووم وانتقالات عند القطع", vm.optZoom) { vm.optZoom = it }
                    Opt("مؤثرات صوتية", vm.optSfx) { vm.optSfx = it }
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(16.dp)).background(Brush.horizontalGradient(listOf(ACCENT, RED)))
                        .clickable(enabled = vm.busy == null && hasVideo) { vm.autoEdit(ctx); panel = null }, contentAlignment = Alignment.Center) {
                        Text("ابدأ المونتاج التلقائي", color = Color.White, fontSize = 17.sp)
                    }
                    OutlinedButton({ vm.autoFitCaptions() }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("ضبط مكان الكابشن تلقائياً (منطقة آمنة)") }
                    Text("الكابشن التلقائي يحتاج اتصالاً بخدمة تفريغ الكلام.", color = Color.Gray, fontSize = 11.sp)
                }
                "adjust" -> {
                    Text("ضبط الألوان", color = Color.White, fontSize = 16.sp)
                    Text("السطوع", color = Color.White); Slider(vm.adjB, { vm.adjB = it }, valueRange = -0.5f..0.5f)
                    Text("التباين", color = Color.White); Slider(vm.adjC, { vm.adjC = it }, valueRange = -0.5f..0.5f)
                    Text("التشبّع", color = Color.White); Slider(vm.adjS, { vm.adjS = it }, valueRange = -1f..1f)
                    Text("الدفء (أزرق ← أحمر)", color = Color.White); Slider(vm.adjW, { vm.adjW = it }, valueRange = -1f..1f)
                    TextButton({ vm.resetAdjust() }) { Text("إعادة الضبط") }
                }
                "crop" -> {
                    Text("تكبير وتحريك الصورة", color = Color.White, fontSize = 16.sp)
                    Text("التكبير", color = Color.White); Slider(vm.tScale, { vm.tScale = it }, valueRange = 1f..3f)
                    Text("إزاحة أفقية", color = Color.White); Slider(vm.tX, { vm.tX = it }, valueRange = -1f..1f)
                    Text("إزاحة رأسية", color = Color.White); Slider(vm.tY, { vm.tY = it }, valueRange = -1f..1f)
                    TextButton({ vm.resetCrop() }) { Text("إعادة الضبط") }
                }
                "trans" -> {
                    Text("الانتقالات بين المقاطع", color = Color.White, fontSize = 16.sp)
                    Chips(listOf("بدون", "تلاشي للأسود", "وميض أبيض"), vm.transition) { vm.transition = it }
                    Text("مدة الانتقال ${vm.transMs} مللي ثانية", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Slider(vm.transMs.toFloat(), { vm.transMs = it.toLong() }, valueRange = 150f..900f)
                    Opt("زووم عند القطع", vm.optZoom) { vm.optZoom = it }
                    Opt("تلاشي في بداية الفيديو ونهايته", vm.fadeEnds) { vm.fadeEnds = it }
                    Text("الانتقالات تظهر في الفيديو بعد التصدير.", color = Color.Gray, fontSize = 11.sp)
                }
                "filter" -> {
                    Text("الفلتر", color = Color.White, fontSize = 16.sp)
                    Chips(FILTER_NAMES, vm.filterIdx) { vm.filterIdx = it }
                    Text("يظهر الفلتر مباشرة في المعاينة.", color = Color.Gray, fontSize = 11.sp)
                }
                "fx" -> {
                    Text("خيارات المونتاج التلقائي", color = Color.White, fontSize = 16.sp)
                    Opt("قص السكتات", vm.optSilence) { vm.optSilence = it }
                    Opt("كابشن تلقائي", vm.optCaptions) { vm.optCaptions = it }
                    Opt("زووم وانتقالات عند القطع", vm.optZoom) { vm.optZoom = it }
                    Opt("مؤثرات صوتية", vm.optSfx) { vm.optSfx = it }
                    Text("المونتاج التلقائي يعمل على أول فيديو في المشروع. الزووم والمؤثرات تظهر بعد التصدير.", color = Color.Gray, fontSize = 11.sp)
                }
                "export" -> {
                    Text("خيارات التصدير", color = Color.White, fontSize = 16.sp)
                    if (doneUri != null) {
                        Text("تم الحفظ في Movies/EditFast ✅", color = Color.White, modifier = Modifier.padding(vertical = 12.dp))
                        Button({
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, doneUri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "مشاركة"))
                        }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Text("  مشاركة") }
                    } else {
                        Text("الحجم: ${FORMATS[vm.formatIdx].first}", color = Color.Gray, fontSize = 12.sp)
                        Text("الدقة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                        Chips(listOf("720p", "1080p", "1440p"), vm.resIdx) { vm.resIdx = it }
                        Text("الجودة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                        Chips(listOf("منخفضة (حجم أصغر)", "متوسطة", "عالية"), vm.quality) { vm.quality = it }
                        Spacer(Modifier.height(12.dp))
                        if (exporting) {
                            LinearProgressIndicator(progress = { prog }, Modifier.fillMaxWidth())
                            Text("جاري التصدير ${(prog * 100).toInt()}%", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                            TextButton({ tr?.cancel(); exporting = false }) { Text("إلغاء") }
                        } else Button({
                            val bits = listOf(listOf(3_000_000, 5_000_000, 8_000_000), listOf(6_000_000, 10_000_000, 16_000_000), listOf(10_000_000, 16_000_000, 25_000_000))
                            val sp = ExportSpec(vm.sources.map { it.uri }, vm.clips.toList(), if (vm.capsVisible) vm.captions.toList() else emptyList(),
                                vm.optZoom, vm.filterIdx, vm.optSfx, vm.muteOriginal, vm.origVol, vm.music, vm.musicVol,
                                FORMATS[vm.formatIdx].second, vm.baseRatio(), vm.rotate, vm.flip, vm.fill,
                                listOf(720, 1080, 1440)[vm.resIdx], bits[vm.resIdx][vm.quality], if (vm.clampSafe) PLATFORMS[vm.platform].second else null,
                                vm.look(), vm.transition, vm.transMs, vm.fadeEnds, vm.voice, vm.voiceStart)
                            player.pause(); prog = 0f; exporting = true
                            tr = exportVideo(ctx, sp) { r ->
                                exporting = false
                                if (r.isSuccess) doneUri = r.getOrNull()
                                else Toast.makeText(ctx, "فشل التصدير: ${r.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                            }
                        }, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = RED)) { Text("ابدأ التصدير", fontSize = 16.sp) }
                    }
                }
            }
        }
    }

    if (settings) {
        var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var lang by remember { mutableStateOf(prefs.getString("lang", "ar") ?: "ar") }
        var url by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
        AlertDialog(onDismissRequest = { settings = false },
            confirmButton = { TextButton({ prefs.edit().putString("key", key.trim()).putString("lang", lang.trim()).putString("url", url.trim()).apply(); settings = false }) { Text("حفظ") } },
            title = { Text("الإعدادات") },
            text = {
                Column {
                    Text("مفتاح Groq المجاني لتحويل الكلام إلى نص (console.groq.com)", fontSize = 12.sp)
                    OutlinedTextField(key, { key = it }, label = { Text("API Key") }, singleLine = true)
                    OutlinedTextField(lang, { lang = it }, label = { Text("لغة الكلام (ar / en / فارغ=تلقائي)") }, singleLine = true)
                    OutlinedTextField(url, { url = it }, label = { Text("عنوان الخدمة (اختياري)") }, singleLine = true)
                    if (BuildConfig.GROQ_KEY.isNotBlank()) Text("✓ مفتاح مدمج في التطبيق، لا حاجة لإدخاله", fontSize = 11.sp)
                }
            })
    }
}


/** نص/ملصق في المعاينة: اضغط للتحديد، اسحب للتحريك، اقرص لتغيير الحجم */
@Composable
private fun CaptionLayer(vm: EditorViewModel, idx: Int, c: Caption, pos: Long, fw: Int, fh: Int, safe: SafeZone?, selected: Boolean) {
    val a = CapAnim.state(c, pos)
    val bmp = remember(c, fw, fh, a.chars) { CapRender.render(c, fw, fh, a.chars).asImageBitmap() }
    val (x, y) = CapAnim.place(c, bmp.width, bmp.height, fw, fh, safe, a)
    val cx = (x + 1f) / 2f * fw; val cy = (1f - y) / 2f * fh
    Image(bmp, null, Modifier
        .offset { IntOffset((cx - bmp.width / 2f).toInt(), (cy - bmp.height / 2f).toInt()) }
        .graphicsLayer(alpha = a.alpha, scaleX = a.scale, scaleY = a.scale)
        .then(if (selected) Modifier.border(1.5.dp, Color.White) else Modifier)
        .pointerInput(idx) { detectTapGestures { vm.selCap = idx } }
        .pointerInput(idx, selected) {
            if (selected) detectTransformGestures { _, pan, z, _ -> vm.moveCap(idx, pan.x / (fw / 2f), -pan.y / (fh / 2f), z) }
        })
}
