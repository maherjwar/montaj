package com.example.editfast

import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8B5CF6))) { EditorScreen() } }
    }
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    var pos by remember { mutableLongStateOf(0L) }
    var exporting by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            val mmr = MediaMetadataRetriever().apply { setDataSource(ctx, u) }
            val d = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            mmr.release()
            vm.onVideo(u, d)
            player.setMediaItem(MediaItem.fromUri(u)); player.prepare()
        }
    }
    LaunchedEffect(Unit) { while (true) { pos = player.currentPosition; delay(100) } }
    // حافظ على التشغيل داخل نطاق القص
    LaunchedEffect(pos, vm.trimStart, vm.trimEnd) {
        if (vm.uri != null && (pos > vm.trimEnd || pos < vm.trimStart) && player.isPlaying) player.seekTo(vm.trimStart)
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B10)).statusBarsPadding().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("EditFast", fontSize = 20.sp, color = Color.White, modifier = Modifier.weight(1f))
            IconButton({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }) {
                Icon(Icons.Default.VideoLibrary, null, tint = Color.White)
            }
            Button(enabled = vm.uri != null && !exporting, onClick = {
                exporting = true
                exportVideo(ctx, vm.uri!!, vm.trimStart, vm.trimEnd, vm.captions.toList()) { r ->
                    exporting = false
                    Toast.makeText(ctx, if (r.isSuccess) "تم الحفظ في Movies/EditFast" else "فشل التصدير: ${r.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                }
            }) { Text(if (exporting) "جاري التصدير..." else "تصدير") }
        }
        Box(Modifier.fillMaxWidth().weight(1.3f).padding(vertical = 8.dp).clip(RoundedCornerShape(16.dp)).background(Color.Black)) {
            AndroidView({ PlayerView(it).apply { this.player = player; useController = false } }, Modifier.fillMaxSize())
            vm.captions.firstOrNull { pos in it.startMs..it.endMs }?.let {
                Text(it.text, color = Color.White, fontSize = 26.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton({ if (player.isPlaying) player.pause() else { if (pos !in vm.trimStart..vm.trimEnd) player.seekTo(vm.trimStart); player.play() } }) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
            }
            Text("%.1f / %.1f ث".format(pos / 1000.0, vm.durationMs / 1000.0), color = Color.White)
        }
        if (vm.durationMs > 0) {
            RangeSlider(
                value = vm.trimStart.toFloat()..vm.trimEnd.toFloat(),
                onValueChange = { vm.trimStart = it.start.toLong(); vm.trimEnd = it.endInclusive.toLong(); player.seekTo(vm.trimStart) },
                valueRange = 0f..vm.durationMs.toFloat()
            )
        }
        LazyColumn(Modifier.weight(1f), reverseLayout = false) {
            items(vm.messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.text, color = Color.White, modifier = Modifier.padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
                        .background(if (m.fromUser) Color(0xFF8B5CF6) else Color(0xFF1C1C26)).padding(10.dp))
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("قولّي عايز المونتاج إزاي...") })
            IconButton({ if (input.isNotBlank()) { vm.send(input); input = "" } }) { Icon(Icons.Default.Send, null, tint = Color(0xFF8B5CF6)) }
        }
    }
}
