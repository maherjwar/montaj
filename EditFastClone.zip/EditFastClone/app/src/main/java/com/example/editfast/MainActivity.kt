package com.example.editfast

import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8B5CF6))) { EditorScreen() } }
    }
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    var pos by remember { mutableLongStateOf(0L) }
    var exporting by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var settings by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            val m = MediaMetadataRetriever().apply { setDataSource(ctx, u) }
            val d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            m.release(); vm.onVideo(u, d); player.setMediaItem(MediaItem.fromUri(u)); player.prepare()
        }
    }
    // المعاينة تتخطى الأجزاء المحذوفة (السكتات)
    LaunchedEffect(Unit) {
        while (true) {
            pos = player.currentPosition
            if (player.isPlaying && vm.segments.isNotEmpty() && vm.segments.none { pos in it.s..it.e }) {
                val nxt = vm.segments.firstOrNull { it.s > pos }
                if (nxt != null) player.seekTo(nxt.s) else player.pause()
            }
            delay(60)
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B10)).statusBarsPadding().navigationBarsPadding().imePadding().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("EditFast", fontSize = 20.sp, color = Color.White, modifier = Modifier.weight(1f))
            IconButton({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }) { Icon(Icons.Default.VideoLibrary, null, tint = Color.White) }
            IconButton({ settings = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
            Button(enabled = vm.uri != null && !exporting, onClick = {
                exporting = true
                exportVideo(ctx, vm.uri!!, vm.segments.toList(), vm.captions.toList(), vm.optFx, vm.optSfx) { r ->
                    exporting = false
                    Toast.makeText(ctx, if (r.isSuccess) "تم الحفظ في Movies/EditFast" else "فشل التصدير: ${r.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                }
            }) { Text(if (exporting) "جاري التصدير..." else "تصدير") }
        }
        Box(Modifier.fillMaxWidth().weight(1.2f).padding(vertical = 8.dp).clip(RoundedCornerShape(16.dp)).background(Color.Black)) {
            AndroidView({ PlayerView(it).apply { this.player = player; useController = false } }, Modifier.fillMaxSize())
            vm.captions.firstOrNull { pos in it.startMs..it.endMs }?.let {
                Text(it.text, color = Color.Yellow, fontSize = 28.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton({ if (player.isPlaying) player.pause() else { if (vm.segments.none { pos in it.s..it.e }) player.seekTo(vm.segments.firstOrNull()?.s ?: 0); player.play() } }) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
            }
            Text("%.1f / %.1f ث".format(pos / 1000.0, vm.durationMs / 1000.0), color = Color.White)
            Spacer(Modifier.weight(1f))
            Text("${vm.segments.size} مقطع • ${vm.captions.size} كابشن", color = Color.Gray, fontSize = 12.sp)
        }
        Button(onClick = { vm.autoEdit(ctx) }, enabled = vm.uri != null && vm.busy == null,
            modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text(vm.busy ?: "مونتاج تلقائي بضغطة واحدة", fontSize = 16.sp)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(vm.optSilence, { vm.optSilence = !vm.optSilence }, { Text("قص السكتات") })
            FilterChip(vm.optCaptions, { vm.optCaptions = !vm.optCaptions }, { Text("كابشن تلقائي") })
            FilterChip(vm.optFx, { vm.optFx = !vm.optFx }, { Text("زووم وانتقالات وألوان") })
            FilterChip(vm.optSfx, { vm.optSfx = !vm.optSfx }, { Text("مؤثرات صوتية") })
        }
        LazyColumn(Modifier.weight(0.8f)) {
            items(vm.messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.text, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
                        .background(if (m.fromUser) Color(0xFF8B5CF6) else Color(0xFF1C1C26)).padding(10.dp))
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("اكتب أمراً...") })
            IconButton({ if (input.isNotBlank()) { vm.send(input); input = "" } }) { Icon(Icons.Default.Send, null, tint = Color(0xFF8B5CF6)) }
        }
    }

    if (settings) {
        var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var lang by remember { mutableStateOf(prefs.getString("lang", "ar") ?: "ar") }
        AlertDialog(onDismissRequest = { settings = false },
            confirmButton = { TextButton({ prefs.edit().putString("key", key.trim()).putString("lang", lang.trim()).apply(); settings = false }) { Text("حفظ") } },
            title = { Text("الإعدادات") },
            text = {
                Column {
                    Text("مفتاح Groq مجاني لتحويل الكلام إلى نص (console.groq.com)", fontSize = 12.sp)
                    OutlinedTextField(key, { key = it }, label = { Text("API Key") }, singleLine = true)
                    OutlinedTextField(lang, { lang = it }, label = { Text("لغة الكلام (ar / en / فارغ=تلقائي)") }, singleLine = true)
                }
            })
    }
}
