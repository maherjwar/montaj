package com.example.editfast

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.io.File

private val BG = Color(0xFF1E1E22)
private val PANEL = Color(0xFF17171C)
private val ACCENT = Color(0xFF8B5CF6)
private val RED = Color(0xFFFF3B5C)
private val SPEEDS = listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = ACCENT)) { EditorScreen() } }
    }
}

private fun fmt(ms: Long) = "%d:%02d.%d".format(ms / 60000, (ms / 1000) % 60, (ms / 100) % 10)

@Composable
private fun Tool(icon: ImageVector, label: String, hi: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.width(72.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (hi) Color(0xFFB794FF) else Color.White, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(5.dp)); Text(label, fontSize = 10.sp, color = Color.LightGray, maxLines = 1)
    }
}

@Composable
private fun Opt(label: String, on: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f)); Switch(on, set)
    }
}

@Composable
private fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            Box(Modifier.size(34.dp).clip(CircleShape).background(if (c == 0) Color(0xFF2A2A36) else Color(c))
                .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Color.White else Color.Gray, CircleShape)
                .clickable { onPick(c) }, contentAlignment = Alignment.Center) { if (c == 0) Text("∅", color = Color.White) }
        }
    }
}

@Composable
private fun LayerBtn(h: Int, icon: ImageVector, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.height(h.dp).width(34.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (on) Color.White else Color(0xFF666670), modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun Chips(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, n -> FilterChip(sel == i, { onSel(i) }, { Text(n) }) }
    }
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    var pos by remember { mutableLongStateOf(0L) }          // موضع التشغيل على خط الناتج
    var playing by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(60f) }       // dp لكل ثانية
    var panel by remember { mutableStateOf<String?>(null) }
    var settings by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var prog by remember { mutableFloatStateOf(0f) }
    var tr by remember { mutableStateOf<Transformer?>(null) }
    var doneUri by remember { mutableStateOf<Uri?>(null) }
    val paint = remember { android.graphics.Paint().apply { color = android.graphics.Color.GRAY; isAntiAlias = true } }
    val customFonts = remember { mutableStateListOf<File>().apply { addAll(ctx.filesDir.listFiles { f -> f.name.startsWith("font_") }.orEmpty()) } }

    fun seekOut(t: Long) {
        if (vm.clips.isEmpty() || player.mediaItemCount != vm.clips.size) return
        val tt = t.coerceIn(0, vm.totalMs); val i = vm.clipAt(tt)
        player.seekTo(i, ((tt - vm.starts()[i]) * vm.clips[i].speed).toLong()); pos = tt
    }
    fun curOut(): Long {
        val i = player.currentMediaItemIndex
        if (i !in vm.clips.indices) return 0
        return vm.starts()[i] + (player.currentPosition / vm.clips[i].speed).toLong()
    }
    fun toggle() {
        if (vm.clips.isEmpty()) return
        if (player.isPlaying) player.pause() else { if (player.playbackState == Player.STATE_ENDED) seekOut(0); player.play() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            val m = MediaMetadataRetriever().apply { setDataSource(ctx, u) }
            val d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            var w = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toFloat() ?: 9f
            var h = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toFloat() ?: 16f
            val rot = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
            m.release(); if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            vm.addSource(ctx, u, d, w / h)
        }
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val name = (u.lastPathSegment ?: "font").substringAfterLast('/').substringBeforeLast('.')
            val f = File(ctx.filesDir, "font_$name.ttf")
            ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            if (customFonts.none { it.name == f.name }) customFonts.add(f)
            vm.style = vm.style.copy(font = name, fontPath = f.path)
        }
    }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { vm.music = u; vm.musicName = (u.lastPathSegment ?: "موسيقى").substringAfterLast('/') }
    }

    // إعادة بناء قائمة التشغيل عند تعديل المقاطع
    LaunchedEffect(vm.version) {
        if (vm.clips.isEmpty()) { player.clearMediaItems(); return@LaunchedEffect }
        val t = pos
        player.setMediaItems(vm.clips.map { c ->
            MediaItem.Builder().setUri(vm.sources[c.src].uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()).build()
        }, false)
        player.prepare(); seekOut(t)
    }
    LaunchedEffect(Unit) {
        while (true) {
            if (vm.clips.isNotEmpty() && player.mediaItemCount == vm.clips.size) {
                val sp = vm.clips[player.currentMediaItemIndex.coerceIn(0, vm.clips.lastIndex)].speed
                if (player.playbackParameters.speed != sp) player.setPlaybackSpeed(sp)
                if (player.isPlaying) pos = curOut()
            }
            playing = player.isPlaying; delay(40)
        }
    }
    LaunchedEffect(vm.filterIdx, vm.rotate, vm.flip) { try { player.setVideoEffects(previewEffects(vm.filterIdx, vm.rotate, vm.flip)) } catch (_: Exception) {} }
    LaunchedEffect(exporting) {
        while (exporting) { val h = ProgressHolder(); if (tr?.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) prog = h.progress / 100f; delay(300) }
    }

    val st = vm.style
    val capFamily = remember(st.font, st.fontPath, st.bold) { FontFamily(st.typeface()) }
    val ratio = if (vm.formatIdx == 0) vm.baseRatio() else FORMATS[vm.formatIdx].second
    val hasVideo = vm.clips.isNotEmpty()

    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ settings = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
            Spacer(Modifier.weight(1f))
            Text(vm.busy ?: vm.status, color = if (vm.busy != null) Color(0xFFB794FF) else Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(3f))
            Button({ doneUri = null; panel = "export" }, enabled = hasVideo, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = RED)) {
                Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(6.dp)); Text("تصدير")
            }
        }
        Box(Modifier.fillMaxWidth().weight(1f).padding(8.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.aspectRatio(ratio).background(Color.Black).clickable { toggle() }) {
                AndroidView({ PlayerView(it).apply { this.player = player; useController = false } },
                    Modifier.fillMaxSize(), update = { it.resizeMode = if (vm.fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT })
                if (vm.capsVisible) vm.captions.firstOrNull { pos in it.startMs..it.endMs }?.let {
                    Text(it.text, color = Color(st.color), fontFamily = capFamily, fontSize = (20 * st.size).sp,
                        modifier = Modifier.align(listOf(Alignment.TopCenter, Alignment.Center, Alignment.BottomCenter)[st.pos])
                            .padding(20.dp).then(if (st.bg != 0) Modifier.background(Color(st.bg)) else Modifier).padding(horizontal = 6.dp))
                }
                if (!hasVideo) Button({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, Modifier.align(Alignment.Center)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("اختر فيديو")
                } else if (!playing) Icon(Icons.Default.PlayCircle, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.align(Alignment.Center).size(56.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${fmt(pos)} / ${fmt(vm.totalMs)}", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            IconButton({ toggle() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                IconButton({ vm.undo() }, enabled = vm.canUndo) { Icon(Icons.Default.Undo, null, tint = if (vm.canUndo) Color.White else Color.DarkGray) }
                IconButton({ vm.redo() }, enabled = vm.canRedo) { Icon(Icons.Default.Redo, null, tint = if (vm.canRedo) Color.White else Color.DarkGray) }
            }
        }
        Row(Modifier.fillMaxWidth().background(BG).horizontalScroll(rememberScrollState()).padding(vertical = 2.dp)) {
            Tool(Icons.Default.AutoAwesome, "مونتاج تلقائي", true) { vm.autoEdit(ctx) }
            Tool(Icons.Default.ContentCut, "تقسيم") { vm.split(pos) }
            Tool(Icons.Default.Delete, "حذف مقطع") { vm.deleteAt(pos) }
            Tool(Icons.Default.Speed, "سرعة وقص") { panel = "clip" }
            Tool(Icons.Default.AspectRatio, "حجم الصورة") { panel = "format" }
            Tool(Icons.Default.MusicNote, "صوت") { panel = "audio" }
            Tool(Icons.Default.EmojiEmotions, "ملصقات") { panel = "stickers" }
            Tool(Icons.Default.TextFields, "نص وخط") { panel = "style" }
            Tool(Icons.Default.ClosedCaption, "الكابشن") { panel = "caps" }
            Tool(Icons.Default.Tune, "فلتر") { panel = "filter" }
            Tool(Icons.Default.AutoFixHigh, "المؤثرات") { panel = "fx" }
        }
        // خط زمني متحرك: المؤشر ثابت بالمنتصف • اسحب للتنقل • اقرص للتكبير
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 6.dp, bottom = 10.dp)) {
            Column(Modifier.width(34.dp)) {
                LayerBtn(44, if (vm.muteOriginal) Icons.Default.VolumeOff else Icons.Default.VolumeUp, !vm.muteOriginal) { vm.muteOriginal = !vm.muteOriginal }
                Spacer(Modifier.height(4.dp))
                LayerBtn(24, if (vm.capsVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff, vm.capsVisible) { vm.capsVisible = !vm.capsVisible }
                Spacer(Modifier.height(4.dp))
                LayerBtn(18, Icons.Default.MusicNote, vm.optSfx) { vm.optSfx = !vm.optSfx }
            }
            Canvas(Modifier.weight(1f).height(116.dp)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, z, _ ->
                        if (z != 1f) zoom = (zoom * z).coerceIn(10f, 300f)
                        seekOut(pos - (pan.x / (zoom.dp.toPx() / 1000f)).toLong())
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { o ->
                        val t = pos + ((o.x - size.width / 2f) / (zoom.dp.toPx() / 1000f)).toLong()
                        if (o.y in 48.dp.toPx()..72.dp.toPx()) {
                            val i = vm.captions.indexOfFirst { t in it.startMs..it.endMs }
                            if (i >= 0) { vm.selCap = i; panel = "caps"; return@detectTapGestures }
                        }
                        seekOut(t)
                    }
                }) {
                val w = size.width; val cx = w / 2; val ppm = zoom.dp.toPx() / 1000f
                fun X(t: Long) = cx + (t - pos) * ppm
                val h1 = 44.dp.toPx(); val st0 = vm.starts(); val total = vm.totalMs
                val cur = if (vm.clips.isEmpty()) -1 else vm.clipAt(pos)
                vm.clips.forEachIndexed { i, c ->
                    val x0 = X(st0[i]); val x1 = X(st0[i] + c.outMs)
                    if (x1 < 0 || x0 > w) return@forEachIndexed
                    val cw0 = x1 - x0
                    drawRoundRect(Color(0xFF2A2A33), Offset(x0, 0f), Size(cw0, h1), CornerRadius(6.dp.toPx()))
                    val th = vm.thumbs[c.src]
                    if (!th.isNullOrEmpty()) {
                        val cell = (h1 * th[0].width / th[0].height).coerceAtLeast(8f)
                        clipRect(x0, 0f, x1, h1) {
                            val n = (cw0 / cell).toInt() + 1
                            for (k in 0 until n) {
                                val xk = x0 + k * cell
                                if (xk + cell < 0 || xk > w) continue
                                val frac = (k * cell / cw0).coerceIn(0f, 0.999f)
                                val srcT = c.s + ((c.e - c.s) * frac).toLong()
                                val img = th[(srcT.toFloat() / vm.sources[c.src].durationMs * th.size).toInt().coerceIn(0, th.size - 1)]
                                drawImage(img, IntOffset.Zero, IntSize(img.width, img.height), IntOffset(xk.toInt(), 0), IntSize(cell.toInt() + 1, h1.toInt()))
                            }
                        }
                    }
                    drawRoundRect(if (i == cur) Color.White else ACCENT, Offset(x0, 0f), Size(cw0, h1), CornerRadius(6.dp.toPx()), Stroke(if (i == cur) 3.dp.toPx() else 1.5.dp.toPx()))
                    if (c.speed != 1f) drawRoundRect(Color(0xFFFF9800), Offset(x0 + 4.dp.toPx(), 4.dp.toPx()), Size(22.dp.toPx(), 10.dp.toPx()), CornerRadius(3.dp.toPx()))
                }
                vm.captions.forEachIndexed { i, c ->
                    val x0 = X(c.startMs); val cw0 = maxOf(4f, (c.endMs - c.startMs) * ppm)
                    drawRoundRect(if (vm.capsVisible) Color(0xFFFFC107) else Color(0xFF555560), Offset(x0, 48.dp.toPx()), Size(cw0, 24.dp.toPx()), CornerRadius(5.dp.toPx()))
                    if (i == vm.selCap) drawRoundRect(Color.White, Offset(x0, 48.dp.toPx()), Size(cw0, 24.dp.toPx()), CornerRadius(5.dp.toPx()), Stroke(2.dp.toPx()))
                }
                if (vm.music != null) drawRoundRect(Color(0xFF26A69A), Offset(X(0), 76.dp.toPx()), Size(total * ppm, 18.dp.toPx()), CornerRadius(5.dp.toPx()))
                if (vm.optSfx) st0.drop(1).forEach { drawRect(Color(0xFFFF9800), Offset(X(it) - 1.dp.toPx(), 76.dp.toPx()), Size(3.dp.toPx(), 18.dp.toPx())) }
                // المسطرة الزمنية
                val step = if (zoom >= 100f) 1000L else if (zoom >= 40f) 2000L else 5000L
                paint.textSize = 10.sp.toPx()
                var t = (((pos - (cx / ppm).toLong()).coerceAtLeast(0)) / step) * step
                while (X(t) < w + 40 && t <= total) {
                    val x = X(t)
                    drawRect(Color.Gray, Offset(x, 98.dp.toPx()), Size(1.dp.toPx(), 5.dp.toPx()))
                    drawContext.canvas.nativeCanvas.drawText("%d:%02d".format(t / 60000, (t / 1000) % 60), x - 8.dp.toPx(), 114.dp.toPx(), paint)
                    t += step
                }
                drawRect(Color.White, Offset(cx - 1.5.dp.toPx(), 0f), Size(3.dp.toPx(), size.height))
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(RED)
                .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, null, tint = Color.White)
            }
        }
    }

    if (panel != null) ModalBottomSheet({ panel = null }, containerColor = PANEL) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            when (panel) {
                "clip" -> {
                    val i = if (hasVideo) vm.clipAt(pos) else -1
                    val c = vm.clips.getOrNull(i)
                    if (c == null) Text("أضف فيديو أولاً", color = Color.Gray) else {
                        Text("المقطع ${i + 1} من ${vm.clips.size}  •  السرعة ${c.speed}x", color = Color.White, fontSize = 16.sp)
                        Chips(SPEEDS.map { "${it}x" }, SPEEDS.indexOf(c.speed)) { vm.setSpeedAt(pos, SPEEDS[it]) }
                        Text("قص المقطع", color = Color.White, modifier = Modifier.padding(top = 10.dp))
                        RangeSlider(c.s.toFloat()..c.e.toFloat(), { vm.setTrimAt(pos, it.start.toLong(), it.endInclusive.toLong()) },
                            valueRange = 0f..vm.sources[c.src].durationMs.toFloat())
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton({ vm.moveAt(pos, -1) }) { Text("⬅ تقديم") }
                            TextButton({ vm.moveAt(pos, 1) }) { Text("تأخير ➡") }
                            TextButton({ vm.duplicateAt(pos) }) { Text("نسخ") }
                            TextButton({ vm.deleteAt(pos) }) { Text("حذف") }
                        }
                        Text("ملاحظة: تغيير السرعة والقص يحرّك الكابشن اللاحق تلقائياً.", color = Color.Gray, fontSize = 11.sp)
                    }
                }
                "format" -> {
                    Text("حجم الصورة", color = Color.White, fontSize = 16.sp)
                    FORMATS.forEachIndexed { i, (n, _) ->
                        Row(Modifier.fillMaxWidth().clickable { vm.formatIdx = i }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(vm.formatIdx == i, { vm.formatIdx = i }); Text(n, color = Color.White)
                        }
                    }
                    Opt("ملء الإطار (قص الأطراف) بدل الأشرطة السوداء", vm.fill) { vm.fill = it }
                    Text("التدوير", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                    Chips(listOf("0°", "90°", "180°", "270°"), vm.rotate / 90) { vm.rotate = it * 90 }
                    Opt("قلب أفقي (مرآة)", vm.flip) { vm.flip = it }
                }
                "audio" -> {
                    Text("الصوت", color = Color.White, fontSize = 16.sp)
                    Opt("المؤثرات الصوتية (عند القطع والكابشن)", vm.optSfx) { vm.optSfx = it }
                    Opt("كتم صوت الفيديو الأصلي", vm.muteOriginal) { vm.muteOriginal = it }
                    Text("مستوى صوت الفيديو", color = Color.White); Slider(vm.origVol, { vm.origVol = it }, valueRange = 0f..1.5f)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button({ musicPicker.launch(arrayOf("audio/*")) }) { Icon(Icons.Default.MusicNote, null); Text(" إضافة موسيقى") }
                        if (vm.music != null) {
                            Text(vm.musicName, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(1f).padding(start = 8.dp), maxLines = 1)
                            IconButton({ vm.music = null }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                        }
                    }
                    if (vm.music != null) { Text("مستوى الموسيقى", color = Color.White); Slider(vm.musicVol, { vm.musicVol = it }, valueRange = 0.05f..1f) }
                }
                "stickers" -> {
                    Text("ملصقات (إيموجي)", color = Color.White, fontSize = 16.sp)
                    listOf("😂🔥❤️👍😍😎🤩🥳", "👏💯✨⭐🎉💥🚀✅", "👀🙏💪🎬📌⚡🤔😱").forEach { row ->
                        Row(Modifier.horizontalScroll(rememberScrollState())) {
                            row.chunked(2).forEach { e -> TextButton({ vm.addCaption(pos, e) }) { Text(e, fontSize = 30.sp) } }
                        }
                    }
                    Text("يُضاف الملصق كطبقة نص عند موضع التشغيل الحالي.", color = Color.Gray, fontSize = 11.sp)
                }
                "caps" -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("تعديل الكابشن", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        TextButton({ vm.addCaption(pos) }) { Icon(Icons.Default.Add, null); Text("إضافة هنا") }
                    }
                    LazyColumn(Modifier.heightIn(max = 440.dp)) {
                        itemsIndexed(vm.captions) { i, c ->
                            Column(Modifier.padding(vertical = 2.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(fmt(c.startMs), color = if (i == vm.selCap) Color.White else Color(0xFFFFC107), fontSize = 12.sp,
                                        modifier = Modifier.clickable { vm.selCap = i; seekOut(c.startMs) }.padding(end = 8.dp))
                                    OutlinedTextField(c.text, { vm.editCaption(i, it) }, Modifier.weight(1f), singleLine = true)
                                    IconButton({ vm.removeCaption(i) }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                                }
                                if (i == vm.selCap) RangeSlider(c.startMs.toFloat()..c.endMs.toFloat(),
                                    { vm.setCaptionTime(i, it.start.toLong(), it.endInclusive.toLong()) }, valueRange = 0f..maxOf(vm.totalMs, c.endMs).toFloat())
                            }
                        }
                    }
                    if (vm.captions.isEmpty()) Text("لا يوجد كابشن — استخدم «مونتاج تلقائي» أو أضف يدوياً", color = Color.Gray, fontSize = 12.sp)
                }
                "style" -> {
                    Text("الخط", color = Color.White)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("sans-serif" to "عادي", "sans-serif-medium" to "متوسط", "serif" to "Serif", "monospace" to "Mono", "casual" to "Casual", "cursive" to "Cursive", "sans-serif-condensed" to "ضيّق").forEach { (k, n) ->
                            FilterChip(st.font == k && st.fontPath == null, { vm.style = st.copy(font = k, fontPath = null) }, { Text(n) })
                        }
                        customFonts.forEach { f ->
                            val n = f.name.removePrefix("font_").removeSuffix(".ttf")
                            FilterChip(st.fontPath == f.path, { vm.style = st.copy(font = n, fontPath = f.path) }, { Text(n) })
                        }
                        AssistChip({ fontPicker.launch(arrayOf("*/*")) }, { Text("+ خط من الجهاز") })
                    }
                    Text("الحجم", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Slider(st.size, { vm.style = st.copy(size = it) }, valueRange = 0.6f..1.8f)
                    Text("لون النص", color = Color.White)
                    Swatches(listOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFF00E5FF, 0xFF69F0AE, 0xFFFF4081, 0xFFFF9100).map { it.toInt() }, st.color) { vm.style = st.copy(color = it) }
                    Text("خلفية النص", color = Color.White)
                    Swatches(listOf(0, 0xFF000000, 0x99000000, 0xFFFFEB3B, 0xFF6D4AFF).map { it.toInt() }, st.bg) { vm.style = st.copy(bg = it) }
                    Opt("خط عريض", st.bold) { vm.style = st.copy(bold = it) }
                    Chips(listOf("أعلى", "وسط", "أسفل"), st.pos) { vm.style = st.copy(pos = it) }
                    TextButton({ vm.addCaption(pos) }) { Icon(Icons.Default.Add, null); Text("إضافة نص جديد هنا") }
                }
                "filter" -> {
                    Text("الفلتر", color = Color.White, fontSize = 16.sp)
                    Chips(FILTER_NAMES, vm.filterIdx) { vm.filterIdx = it }
                    Text("يظهر الفلتر مباشرة في المعاينة.", color = Color.Gray, fontSize = 11.sp)
                }
                "fx" -> {
                    Text("خيارات المونتاج التلقائي", color = Color.White, fontSize = 16.sp)
                    Opt("قص السكتات", vm.optSilence) { vm.optSilence = it }
                    Opt("كابشن تلقائي", vm.optCaptions) { vm.optCaptions = it }
                    Opt("زووم وانتقالات عند القطع", vm.optZoom) { vm.optZoom = it }
                    Opt("مؤثرات صوتية", vm.optSfx) { vm.optSfx = it }
                    Text("المونتاج التلقائي يعمل على أول فيديو في المشروع. الزووم والمؤثرات تظهر بعد التصدير.", color = Color.Gray, fontSize = 11.sp)
                }
                "export" -> {
                    Text("خيارات التصدير", color = Color.White, fontSize = 16.sp)
                    if (doneUri != null) {
                        Text("تم الحفظ في Movies/EditFast ✅", color = Color.White, modifier = Modifier.padding(vertical = 12.dp))
                        Button({
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, doneUri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "مشاركة"))
                        }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Text("  مشاركة") }
                    } else {
                        Text("الحجم: ${FORMATS[vm.formatIdx].first}", color = Color.Gray, fontSize = 12.sp)
                        Text("الدقة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                        Chips(listOf("480p", "720p", "1080p"), vm.resIdx) { vm.resIdx = it }
                        Text("الجودة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                        Chips(listOf("منخفضة (حجم أصغر)", "متوسطة", "عالية"), vm.quality) { vm.quality = it }
                        Spacer(Modifier.height(12.dp))
                        if (exporting) {
                            LinearProgressIndicator(progress = { prog }, Modifier.fillMaxWidth())
                            Text("جاري التصدير ${(prog * 100).toInt()}%", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                            TextButton({ tr?.cancel(); exporting = false }) { Text("إلغاء") }
                        } else Button({
                            val bits = listOf(listOf(1_500_000, 2_500_000, 4_000_000), listOf(3_000_000, 5_000_000, 8_000_000), listOf(6_000_000, 10_000_000, 16_000_000))
                            val sp = ExportSpec(vm.sources.map { it.uri }, vm.clips.toList(), if (vm.capsVisible) vm.captions.toList() else emptyList(), vm.style,
                                vm.optZoom, vm.filterIdx, vm.optSfx, vm.muteOriginal, vm.origVol, vm.music, vm.musicVol,
                                FORMATS[vm.formatIdx].second, vm.baseRatio(), vm.rotate, vm.flip, vm.fill,
                                listOf(480, 720, 1080)[vm.resIdx], bits[vm.resIdx][vm.quality])
                            player.pause(); prog = 0f; exporting = true
                            tr = exportVideo(ctx, sp) { r ->
                                exporting = false
                                if (r.isSuccess) doneUri = r.getOrNull()
                                else Toast.makeText(ctx, "فشل التصدير: ${r.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                            }
                        }, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = RED)) { Text("ابدأ التصدير", fontSize = 16.sp) }
                    }
                }
            }
        }
    }

    if (settings) {
        var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var lang by remember { mutableStateOf(prefs.getString("lang", "ar") ?: "ar") }
        AlertDialog(onDismissRequest = { settings = false },
            confirmButton = { TextButton({ prefs.edit().putString("key", key.trim()).putString("lang", lang.trim()).apply(); settings = false }) { Text("حفظ") } },
            title = { Text("الإعدادات") },
            text = {
                Column {
                    Text("مفتاح Groq المجاني لتحويل الكلام إلى نص (console.groq.com)", fontSize = 12.sp)
                    OutlinedTextField(key, { key = it }, label = { Text("API Key") }, singleLine = true)
                    OutlinedTextField(lang, { lang = it }, label = { Text("لغة الكلام (ar / en / فارغ=تلقائي)") }, singleLine = true)
                }
            })
    }
}
