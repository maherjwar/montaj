package com.example.editfast

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.TextureView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

private val BG = Color(0xFF1E1E22)
private val PANEL = Color(0xFF17171C)
private val ACCENT = Color(0xFF8B5CF6)
private val RED = Color(0xFFFF3B5C)
private val GREEN = Color(0xFF7CB342)
private val SPEEDS = listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
private val PALETTE = listOf(0xFFFFFFFF, 0xFFCCCCCC, 0xFF999999, 0xFF666666, 0xFF000000, 0xFFFFE0B2, 0xFFFFCC80, 0xFFFFEB3B, 0xFFFFD54F,
    0xFFFF9100, 0xFFFF5252, 0xFFFF1744, 0xFFB71C1C, 0xFFFF4081, 0xFFE040FB, 0xFF7C4DFF, 0xFF6D4AFF, 0xFF448AFF, 0xFF00B0FF,
    0xFF00E5FF, 0xFF1DE9B6, 0xFF69F0AE, 0xFF76FF03, 0xFFFFCDD2).map { it.toInt() }

private data class CardP(val mode: Int, val color: Int, val text: Int, val r: Float)
private val CARDS = listOf(
    CardP(1, 0xFFFFEB3B.toInt(), 0xFF000000.toInt(), 0f), CardP(1, 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0f),
    CardP(2, 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 2f), CardP(2, 0xFFFFC107.toInt(), 0xFF000000.toInt(), 2f),
    CardP(2, 0xCC000000.toInt(), 0xFFFFFFFF.toInt(), 2f), CardP(2, 0xFFFF1744.toInt(), 0xFFFFFFFF.toInt(), 0.6f),
    CardP(2, 0xFF6D4AFF.toInt(), 0xFFFFFFFF.toInt(), 0.9f), CardP(2, 0xFF69F0AE.toInt(), 0xFF000000.toInt(), 0.9f)
)
private data class FontOpt(val label: String, val font: String, val path: String?)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.ctx = applicationContext
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = ACCENT)) { EditorScreen() } }
    }
}

private fun fmt(ms: Long) = String.format(Locale.US, "%d:%02d.%d", ms / 60000, (ms / 1000) % 60, (ms / 100) % 10)

/** ينسخ الوسائط إلى مخزن التطبيق كي تبقى متاحة عند إعادة فتح المشروع */
private fun importMedia(ctx: Context, u: Uri, prefix: String, mime: String): File {
    val ext = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: if (mime.startsWith("image")) "jpg" else if (mime.startsWith("audio")) "m4a" else "mp4"
    val f = File(File(ctx.filesDir, "media").apply { mkdirs() }, "${prefix}_${System.currentTimeMillis()}.$ext")
    ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { i.copyTo(it) } }
    return f
}

private fun videoInfo(path: String): Triple<Long, Float, Boolean> {
    val m = MediaMetadataRetriever()
    return try {
        m.setDataSource(path)
        val d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        var w = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toFloat() ?: 9f
        var h = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toFloat() ?: 16f
        val rot = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        Triple(d, if (h > 0) w / h else 1f, true)
    } catch (e: Exception) { Triple(0L, 1f, false) } finally { m.release() }
}

@Composable
private fun Tool(icon: ImageVector, label: String, hi: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.width(66.dp).clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (hi) Color(0xFFB794FF) else Color.White, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp)); Text(label, fontSize = 10.sp, color = Color.LightGray, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun Opt(label: String, on: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f)); Switch(on, set)
    }
}

@Composable
private fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Color.White else Color.Gray, CircleShape)
                .clickable { onPick(c) })
        }
    }
}

@Composable
private fun LayerBtn(h: Int, icon: ImageVector, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.height(h.dp).width(34.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (on) Color.White else Color(0xFF666670), modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun Chips(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, n -> FilterChip(sel == i, { onSel(i) }, { Text(n) }) }
    }
}

@Composable
private fun Palette(selected: Int?, withNone: Boolean, onPick: (Int?) -> Unit, onCustom: () -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        if (withNone) Box(Modifier.size(40.dp).background(Color.White).clickable { onPick(null) }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Block, null, tint = RED)
        }
        PALETTE.forEach { c ->
            Box(Modifier.size(40.dp).background(Color(c)).then(if (c == selected) Modifier.border(3.dp, ACCENT) else Modifier).clickable { onPick(c) })
        }
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(6.dp)).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
            .clickable { onCustom() })
    }
}

@Composable
private fun BoxScope.Handle(al: Alignment, dx: Int, dy: Int, bg: Color, icon: ImageVector?, mod: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    Box(Modifier.align(al).absoluteOffset(dx.dp, dy.dp).size(28.dp).clip(CircleShape).background(bg).then(mod)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier), contentAlignment = Alignment.Center) {
        if (icon != null) Icon(icon, null, tint = if (bg == Color.White) Color.Black else Color.White, modifier = Modifier.size(16.dp))
    }
}

/** شاشة المشروعات */
@Composable
private fun ProjectsScreen(list: List<ProjectItem>, onOpen: (Long) -> Unit, onNew: () -> Unit, onDelete: (Long) -> Unit, onClose: (() -> Unit)?) {
    var del by remember { mutableStateOf<Long?>(null) }
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding().padding(16.dp)
        .pointerInput(Unit) { detectTapGestures { } }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مشروعاتي", color = Color.White, fontSize = 24.sp, modifier = Modifier.weight(1f))
            if (onClose != null) IconButton(onClose) { Icon(Icons.Default.Close, null, tint = Color.White) }
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(ACCENT, RED)))
            .clickable(onClick = onNew), contentAlignment = Alignment.Center) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Add, null, tint = Color.White); Spacer(Modifier.width(8.dp)); Text("مشروع جديد", color = Color.White, fontSize = 18.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        if (list.isEmpty()) Text("لا توجد مشروعات محفوظة بعد. يُحفظ عملك تلقائياً.", color = Color.Gray)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { p ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(PANEL).clickable { onOpen(p.id) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    val bmp = remember(p.thumb) { p.thumb?.let { BitmapFactory.decodeFile(it)?.asImageBitmap() } }
                    Box(Modifier.size(72.dp, 96.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2A2A33))) {
                        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(p.name, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(p.modified)) + "  •  " + fmt(p.durationMs), color = Color.Gray, fontSize = 12.sp)
                    }
                    IconButton({ del = p.id }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                }
            }
        }
    }
    del?.let { id ->
        AlertDialog(onDismissRequest = { del = null },
            confirmButton = { TextButton({ onDelete(id); del = null }) { Text("حذف") } },
            dismissButton = { TextButton({ del = null }) { Text("إلغاء") } },
            title = { Text("حذف المشروع؟") }, text = { Text("لا يمكن التراجع عن الحذف.") })
    }
}

/** طبقة في المعاينة: نص / ملصق / تراكب صورة أو فيديو (PIP) مع إطار تحديد ومقابض */
@Composable
private fun CaptionLayer(vm: EditorViewModel, idx: Int, c: Caption, pos: Long, fw: Int, fh: Int, safe: SafeZone?, selected: Boolean,
                         pip: ExoPlayer, onEdit: () -> Unit) {
    val a = CapAnim.state(c, pos)
    val isVid = c.vid != null
    val bmp = remember(c, fw, fh, a.chars) { if (c.vid != null) null else CapRender.render(c, fw, fh, a.chars).asImageBitmap() }
    val bw = if (isVid) (fw * 0.45f * c.st.size).toInt().coerceAtLeast(8) else bmp!!.width
    val bh = if (isVid) (bw / c.vAspect).toInt().coerceAtLeast(8) else bmp!!.height
    val (x, y) = CapAnim.place(c, bw, bh, fw, fh, safe, a)
    val cx = (x + 1f) / 2f * fw; val cy = (1f - y) / 2f * fh
    val den = LocalDensity.current
    val wDp = with(den) { bw.toDp() }; val hDp = with(den) { bh.toDp() }
    val shape = when (c.mask) { 1 -> CircleShape; 2 -> RoundedCornerShape(18); else -> RectangleShape }
    Box(Modifier.offset { IntOffset((cx - bw / 2f).toInt(), (cy - bh / 2f).toInt()) }
        .size(wDp, hDp).graphicsLayer(scaleX = a.scale, scaleY = a.scale, rotationZ = -a.rot)) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize().graphicsLayer(alpha = a.alpha))
        else Box(Modifier.fillMaxSize().graphicsLayer(alpha = a.alpha).clip(shape)
            .then(if (c.bw > 0f) Modifier.border(with(den) { (c.bw * bw * 0.01f).toDp() }, Color(c.bc), shape) else Modifier)) {
            AndroidView({ ctx -> TextureView(ctx).also { pip.setVideoTextureView(it) } }, Modifier.fillMaxSize())
        }
        Box(Modifier.fillMaxSize()
            .pointerInput(idx) { detectTapGestures { vm.selCap = idx; vm.selClip = false } }
            .pointerInput(idx, selected) {
                if (selected) detectTransformGestures { _, pan, z, _ -> vm.moveCap(idx, pan.x / (fw / 2f), -pan.y / (fh / 2f), z) }
            })
        if (selected) {
            Box(Modifier.fillMaxSize().border(1.5.dp, Color.White))
            Handle(AbsoluteAlignment.TopLeft, -14, -14, RED, Icons.Default.Close, onClick = { vm.removeCaption(idx) })
            if (c.img == null && !isVid) Handle(AbsoluteAlignment.TopRight, 14, -14, Color.White, Icons.Default.Edit, onClick = onEdit)
            Handle(AbsoluteAlignment.BottomRight, 14, 14, Color.White, Icons.Default.OpenInFull,
                Modifier.pointerInput(idx) { detectDragGestures { ch, d -> ch.consume(); vm.updStyle(idx) { it.copy(size = (it.size * (1f + (d.x + d.y) / bw)).coerceIn(0.3f, 4f)) } } })
            if (c.img == null && !isVid) {
                Handle(AbsoluteAlignment.CenterRight, 10, 0, Color.White, null,
                    Modifier.pointerInput(idx) { detectDragGestures { ch, d -> ch.consume(); vm.updStyle(idx) { it.copy(maxW = (it.maxW + d.x * 2f / fw).coerceIn(0.2f, 0.98f)) } } })
                Handle(AbsoluteAlignment.CenterLeft, -10, 0, Color.White, null,
                    Modifier.pointerInput(idx) { detectDragGestures { ch, d -> ch.consume(); vm.updStyle(idx) { it.copy(maxW = (it.maxW - d.x * 2f / fw).coerceIn(0.2f, 0.98f)) } } })
            }
        }
    }
}

/** محرر النص المثبّت أسفل الشاشة (على طريقة InShot) */
@Composable
private fun TextEditor(vm: EditorViewModel, i: Int, c: Caption, fonts: List<FontOpt>, onAddFont: () -> Unit,
                       onCustomColor: ((Int) -> Unit) -> Unit, onDone: () -> Unit, onCancel: () -> Unit) {
    var tab by remember { mutableIntStateOf(3) }
    var sub by remember { mutableIntStateOf(0) }
    val st = c.st
    fun upd(f: (CapStyle) -> CapStyle) = vm.updStyle(i, f)
    Column(Modifier.fillMaxWidth().background(PANEL)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onDone) { Icon(Icons.Default.Check, null, tint = Color.White) }
            IconButton({ tab = 0 }) { Icon(Icons.Default.Opacity, null, tint = if (tab == 0) ACCENT else Color.White) }
            IconButton({ tab = 1 }) { Icon(Icons.Default.FormatAlignCenter, null, tint = if (tab == 1) ACCENT else Color.White) }
            TextButton({ tab = 2 }) { Text("Aa", fontSize = 20.sp, color = if (tab == 2) ACCENT else Color.White) }
            IconButton({ tab = 3 }, Modifier.clip(RoundedCornerShape(8.dp)).background(if (tab == 3) Color(0xFF2C2C36) else Color.Transparent)) {
                Box(Modifier.size(26.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red))))
            }
            IconButton({ tab = 4 }) { Icon(Icons.Default.FormatColorText, null, tint = if (tab == 4) ACCENT else Color(0xFFFF8A65)) }
            IconButton({ tab = 5 }) { Icon(Icons.Default.Keyboard, null, tint = if (tab == 5) ACCENT else Color.White) }
            IconButton(onCancel) { Icon(Icons.Default.Close, null, tint = Color.White) }
        }
        Column(Modifier.heightIn(max = 330.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp).padding(bottom = 10.dp)) {
            when (tab) {
                3 -> {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        listOf("نص", "الحدود", "ظل", "توهج", "بطاقة", "التعتيم").forEachIndexed { k, n ->
                            Column(Modifier.clickable { sub = k }.padding(vertical = 6.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(n, color = if (sub == k) Color.White else Color.Gray, fontSize = 15.sp)
                                if (sub == k) Box(Modifier.padding(top = 3.dp).size(5.dp).clip(CircleShape).background(Color.White))
                            }
                        }
                    }
                    when (sub) {
                        0 -> Palette(st.color, false, { col -> if (col != null) upd { it.copy(color = col, grad = false) } }) { onCustomColor { col -> upd { it.copy(color = col, grad = false) } } }
                        1 -> {
                            Palette(if (st.outline) st.outlineColor else null, true, { col -> if (col == null) upd { it.copy(outline = false) } else upd { it.copy(outline = true, outlineColor = col) } }) { onCustomColor { col -> upd { it.copy(outline = true, outlineColor = col) } } }
                            if (st.outline) Slider(st.outW, { v -> upd { it.copy(outW = v) } }, valueRange = 0.3f..3f)
                        }
                        2 -> {
                            Palette(if (st.shadow) st.shadowColor else null, true, { col -> if (col == null) upd { it.copy(shadow = false) } else upd { it.copy(shadow = true, shadowColor = col) } }) { onCustomColor { col -> upd { it.copy(shadow = true, shadowColor = col) } } }
                            if (st.shadow) Slider(st.shadowAmt, { v -> upd { it.copy(shadowAmt = v) } }, valueRange = 0.3f..3f)
                        }
                        3 -> Palette(if (st.glow) (if (st.glowColor != 0) st.glowColor else st.color) else null, true, { col -> if (col == null) upd { it.copy(glow = false) } else upd { it.copy(glow = true, glowColor = col) } }) { onCustomColor { col -> upd { it.copy(glow = true, glowColor = col) } } }
                        4 -> {
                            Palette(if (st.boxMode != 0) st.boxColor else null, true, { col -> if (col == null) upd { it.copy(boxMode = 0) } else upd { it.copy(boxMode = if (it.boxMode == 0) 2 else it.boxMode, boxColor = col) } }) { onCustomColor { col -> upd { it.copy(boxMode = if (it.boxMode == 0) 2 else it.boxMode, boxColor = col) } } }
                            if (st.boxMode != 0) {
                                Chips(listOf("مربع", "دائري"), st.boxMode - 1) { k -> upd { it.copy(boxMode = k + 1) } }
                                Slider(st.boxPad, { v -> upd { it.copy(boxPad = v) } }, valueRange = 0.3f..2.5f)
                            }
                        }
                        5 -> { Text("شفافية النص", color = Color.White); Slider(st.opacity, { v -> upd { it.copy(opacity = v) } }, valueRange = 0.1f..1f) }
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(84.dp, 46.dp).clip(RoundedCornerShape(6.dp)).background(Color.White).clickable { upd { it.copy(boxMode = 0) } }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Block, null, tint = RED) }
                        CARDS.forEach { p ->
                            Box(Modifier.size(84.dp, 46.dp).clip(RoundedCornerShape(if (p.mode == 2) (p.r * 11f).coerceAtMost(23f).dp else 2.dp)).background(Color(p.color))
                                .clickable { upd { it.copy(boxMode = p.mode, boxColor = p.color, boxR = p.r, color = p.text, grad = false) } }, contentAlignment = Alignment.Center) {
                                Text("نص", color = Color(p.text), fontSize = 16.sp)
                            }
                        }
                    }
                }
                2 -> {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        fonts.forEach { f ->
                            val fam = remember(f) { FontFamily(CapStyle(font = f.font, fontPath = f.path, bold = false).typeface()) }
                            val on = st.font == f.font && st.fontPath == f.path
                            Box(Modifier.size(100.dp, 54.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2C2C36)).then(if (on) Modifier.border(2.dp, ACCENT, RoundedCornerShape(10.dp)) else Modifier)
                                .clickable { upd { it.copy(font = f.font, fontPath = f.path) } }, contentAlignment = Alignment.Center) {
                                Text("أبجد Abc", fontFamily = fam, color = Color.White, fontSize = 17.sp, maxLines = 1)
                            }
                        }
                        AssistChip(onAddFont, { Text("+ خط") })
                    }
                    Text("الحجم", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Slider(st.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.4f..3f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(st.bold, { upd { it.copy(bold = !it.bold) } }, { Text("عريض") })
                        FilterChip(st.italic, { upd { it.copy(italic = !it.italic) } }, { Text("مائل") })
                        FilterChip(st.underline, { upd { it.copy(underline = !it.underline) } }, { Text("تسطير") })
                    }
                }
                1 -> {
                    Text("المحاذاة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(listOf("بداية السطر", "وسط", "نهاية السطر"), st.align) { k -> upd { it.copy(align = k) } }
                    Text("تباعد الأحرف", color = Color.White); Slider(st.spacing, { v -> upd { it.copy(spacing = v) } }, valueRange = 0f..0.5f)
                    Text("تباعد الأسطر", color = Color.White); Slider(st.lineSp, { v -> upd { it.copy(lineSp = v) } }, valueRange = 0.7f..2f)
                    Text("أقصى عرض للنص", color = Color.White); Slider(st.maxW, { v -> upd { it.copy(maxW = v) } }, valueRange = 0.3f..0.95f)
                }
                0 -> {
                    Text("الشفافية", color = Color.White, modifier = Modifier.padding(top = 8.dp)); Slider(st.opacity, { v -> upd { it.copy(opacity = v) } }, valueRange = 0.1f..1f)
                    Text("تدوير النص", color = Color.White); Slider(st.rot, { v -> upd { it.copy(rot = v) } }, valueRange = -180f..180f)
                    Text("الحجم", color = Color.White); Slider(st.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.4f..3f)
                }
                4 -> {
                    Text("قوالب جاهزة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(TEMPLATES.map { it.first }, -1) { k -> val t = TEMPLATES[k].second; upd { s -> t.copy(x = s.x, y = s.y, size = s.size) } }
                    Opt("تعبئة متدرجة", st.grad) { v -> upd { it.copy(grad = v) } }
                    if (st.grad) Swatches(listOf(0xFFFF4081, 0xFFFF6F00, 0xFF6D4AFF, 0xFF00E5FF, 0xFF69F0AE, 0xFFFFFFFF).map { it.toInt() }, st.color2) { v -> upd { it.copy(color2 = v) } }
                    TextButton({ vm.applyStyleToAll(i) }) { Text("تطبيق هذا التنسيق على كل النصوص") }
                }
                5 -> {
                    val fr = remember { FocusRequester() }
                    LaunchedEffect(Unit) { fr.requestFocus() }
                    OutlinedTextField(c.text, { vm.editCaption(i, it) }, Modifier.fillMaxWidth().padding(top = 8.dp).focusRequester(fr))
                }
            }
        }
    }
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    val pipPlayer = remember { ExoPlayer.Builder(ctx).build().apply { volume = 0f } }
    DisposableEffect(Unit) {
        val l = object : Player.Listener { override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED) player.pause() } }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release(); pipPlayer.release() }
    }
    DisposableEffect(Unit) {
        val lc = (ctx as ComponentActivity).lifecycle
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_PAUSE) vm.autosave(ctx) }
        lc.addObserver(obs); onDispose { lc.removeObserver(obs) }
    }
    var pos by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(60f) }
    var panel by remember { mutableStateOf<String?>(null) }
    var settings by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var prog by remember { mutableFloatStateOf(0f) }
    var tr by remember { mutableStateOf<Transformer?>(null) }
    var doneUri by remember { mutableStateOf<Uri?>(null) }
    var editMode by remember { mutableStateOf(false) }
    var editBackup by remember { mutableStateOf<Caption?>(null) }
    var hexCb by remember { mutableStateOf<((Int) -> Unit)?>(null) }
    var toastText by remember { mutableStateOf<String?>(null) }
    var pipLoaded by remember { mutableStateOf<String?>(null) }
    var projItems by remember { mutableStateOf(Projects.list(ctx)) }
    var showProjects by remember { mutableStateOf(vm.projectId == 0L && projItems.isNotEmpty()) }
    LaunchedEffect(Unit) { if (vm.projectId == 0L && projItems.isEmpty()) vm.newProject() }
    val paint = remember { android.graphics.Paint().apply { color = android.graphics.Color.GRAY; isAntiAlias = true } }
    val bundled = remember { ctx.assets.list("fonts")?.filter { it.endsWith(".ttf") || it.endsWith(".otf") }?.sorted().orEmpty() }
    val customFonts = remember { mutableStateListOf<File>().apply { addAll(ctx.filesDir.listFiles { f -> f.name.startsWith("font_") }.orEmpty()) } }
    val fontOpts = bundled.map { FontOpt(it.substringBeforeLast('.').substringBefore('[').substringBefore('-'), it, "asset:fonts/$it") } +
        listOf("sans-serif" to "عادي", "serif" to "Serif", "monospace" to "Mono", "casual" to "Casual", "cursive" to "Cursive").map { FontOpt(it.second, it.first, null) } +
        customFonts.map { FontOpt(it.name.removePrefix("font_").removeSuffix(".ttf"), it.name.removePrefix("font_").removeSuffix(".ttf"), it.path) }

    fun seekOut(t: Long) {
        if (vm.clips.isEmpty() || player.mediaItemCount != vm.clips.size) return
        val tt = t.coerceIn(0, vm.totalMs); val i = vm.clipAt(tt)
        player.seekTo(i, ((tt - vm.starts()[i]) * vm.clips[i].speed).toLong()); pos = tt
    }
    fun curOut(): Long {
        val i = player.currentMediaItemIndex
        if (i !in vm.clips.indices) return 0
        return vm.starts()[i] + (player.currentPosition / vm.clips[i].speed).toLong()
    }
    fun toggle() {
        if (vm.clips.isEmpty()) return
        if (player.playWhenReady && player.playbackState != Player.STATE_ENDED) player.pause()
        else { if (player.playbackState == Player.STATE_ENDED) seekOut(0); player.play() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) scope.launch {
            vm.busy = "جاري الاستيراد..."
            try {
                val f = withContext(Dispatchers.IO) { importMedia(ctx, u, "src", "video/mp4") }
                val (d, ratio, ok) = withContext(Dispatchers.IO) { videoInfo(f.path) }
                if (ok && d > 0) vm.addSource(ctx, Uri.fromFile(f), d, ratio) else vm.status = "تعذر قراءة الفيديو"
            } finally { vm.busy = null }
        }
    }
    val pipPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) scope.launch {
            vm.busy = "جاري الاستيراد..."
            try {
                val mime = ctx.contentResolver.getType(u) ?: ""
                val isVid = mime.startsWith("video")
                val f = withContext(Dispatchers.IO) { importMedia(ctx, u, "pip", mime) }
                if (isVid) { val (d, ratio, ok) = withContext(Dispatchers.IO) { videoInfo(f.path) }; if (ok) vm.addPip(pos, f.path, true, d, ratio) }
                else {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(f.path, o)
                    vm.addPip(pos, f.path, false, 0L, if (o.outHeight > 0) o.outWidth.toFloat() / o.outHeight else 1f)
                }
                panel = null
            } finally { vm.busy = null }
        }
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val name = (u.lastPathSegment ?: "font").substringAfterLast('/').substringBeforeLast('.')
            val f = File(ctx.filesDir, "font_$name.ttf")
            ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            if (customFonts.none { it.name == f.name }) customFonts.add(f)
            vm.updStyle(vm.selCap) { it.copy(font = name, fontPath = f.path) }
        }
    }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            val f = withContext(Dispatchers.IO) { importMedia(ctx, u, "music", ctx.contentResolver.getType(u) ?: "audio/mpeg") }
            vm.music = Uri.fromFile(f); vm.musicName = (u.lastPathSegment ?: "موسيقى").substringAfterLast('/')
        }
    }
    val stickerPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) scope.launch {
            val f = withContext(Dispatchers.IO) { importMedia(ctx, u, "sticker", "image/png") }
            vm.addSticker(pos, f.path)
        }
    }
    val srtPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val text = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText().orEmpty()
            val n = vm.importSrt(text); vm.status = if (n > 0) "تم استيراد $n ترجمة" else "لم أجد ترجمات في الملف"
        }
    }
    val voiceRec = remember { VoiceRec() }
    fun startVoice() { vm.voiceStart = pos; voiceRec.start(); vm.recording = true; player.play() }
    fun stopVoice() { vm.voice = voiceRec.stop(); vm.recording = false; player.pause() }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) startVoice() }

    LaunchedEffect(vm.version) {
        if (vm.clips.isEmpty()) { player.clearMediaItems(); return@LaunchedEffect }
        val t = pos
        player.setMediaItems(vm.clips.map { c ->
            MediaItem.Builder().setUri(vm.sources[c.src].uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()).build()
        }, false)
        player.prepare(); seekOut(t)
    }
    LaunchedEffect(Unit) {
        while (true) {
            if (vm.clips.isNotEmpty() && player.mediaItemCount == vm.clips.size) {
                val cl = vm.clips[player.currentMediaItemIndex.coerceIn(0, vm.clips.lastIndex)]
                if (player.playbackParameters.speed != cl.speed) player.setPlaybackSpeed(cl.speed)
                player.volume = cl.vol.coerceIn(0f, 1f)
                if (player.isPlaying) pos = curOut()
            }
            playing = player.playWhenReady && player.playbackState != Player.STATE_ENDED && player.playbackState != Player.STATE_IDLE
            // مزامنة فيديو التراكب (PIP) مع المعاينة
            val av = vm.captions.firstOrNull { it.vid != null && pos in it.startMs..it.endMs }
            if (av != null) {
                if (pipLoaded != av.vid) { pipPlayer.setMediaItem(MediaItem.fromUri(Uri.fromFile(File(av.vid!!)))); pipPlayer.prepare(); pipLoaded = av.vid }
                val want = pos - av.startMs + av.srcStart
                if (abs(pipPlayer.currentPosition - want) > (if (playing) 400 else 60)) pipPlayer.seekTo(want)
                pipPlayer.playWhenReady = playing
            } else if (pipPlayer.playWhenReady) pipPlayer.pause()
            delay(40)
        }
    }
    LaunchedEffect(Unit) { while (true) { delay(4000); vm.autosave(ctx) } }
    LaunchedEffect(vm.status) { toastText = vm.status; delay(3000); toastText = null }
    val look = vm.look()
    LaunchedEffect(look) { try { player.setVideoEffects(lookEffects(look)) } catch (_: Exception) {} }
    LaunchedEffect(exporting) {
        while (exporting) { val h = ProgressHolder(); if (tr?.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) prog = h.progress / 100f; delay(300) }
    }
    val sel = vm.captions.getOrNull(vm.selCap)
    val clipSel = vm.selClip && sel == null
    LaunchedEffect(sel == null) { if (sel == null) editMode = false }
    BackHandler(showProjects && vm.projectId != 0L) { showProjects = false }
    BackHandler(!showProjects && (panel != null || sel != null || editMode || clipSel)) {
        if (editMode) editMode = false else if (panel != null) panel = null else vm.clearSel()
    }

    val ratio = if (vm.formatIdx == 0) vm.baseRatio() else FORMATS[vm.formatIdx].second
    val hasVideo = vm.clips.isNotEmpty()
    val safeZ = vm.safeFor(ratio)
    fun startEdit(i: Int) { vm.selCap = i; vm.selClip = false; editBackup = vm.captions.getOrNull(i); editMode = true; panel = null }

    @Composable
    fun PanelBody() {
        when (panel) {
            "pip" -> {
                Text("أضف فيديو أو صورة فوق الفيديو الأساسي ثم حرّكها وكبّرها بالسحب.", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Button({ pipPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }, Modifier.fillMaxWidth().height(50.dp)) {
                    Icon(Icons.Default.PictureInPicture, null); Text("  إضافة فيديو أو صورة")
                }
                Text("صوت فيديو التراكب غير مُضمَّن، والكروما والإطار يظهران بعد التصدير.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            }
            "pip_fx" -> {
                val i = vm.selCap; val c = vm.captions.getOrNull(i)
                if (c != null) {
                    Text("القناع", color = Color.White)
                    Chips(listOf("بدون", "دائري", "مستدير"), c.mask) { v -> vm.modCap(i, 6000 + i) { it.copy(mask = v) } }
                    Text("سماكة الإطار", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                    Slider(c.bw, { v -> vm.modCap(i, 6000 + i) { it.copy(bw = v) } }, valueRange = 0f..5f)
                    if (c.bw > 0f) Swatches(listOf(0xFFFFFFFF, 0xFF000000, 0xFFFF4081, 0xFFFFEB3B, 0xFF00E5FF, 0xFF69F0AE).map { it.toInt() }, c.bc) { v -> vm.modCap(i, 6000 + i) { it.copy(bc = v) } }
                    Text("الشفافية", color = Color.White); Slider(c.st.opacity, { v -> vm.updStyle(i) { it.copy(opacity = v) } }, valueRange = 0.1f..1f)
                    Text("التدوير", color = Color.White); Slider(c.st.rot, { v -> vm.updStyle(i) { it.copy(rot = v) } }, valueRange = -180f..180f)
                    Opt("إزالة اللون الأخضر (كروما)", c.chroma) { v -> vm.modCap(i, 6000 + i) { it.copy(chroma = v) } }
                    if (c.chroma) { Text("قوة الإزالة", color = Color.White); Slider(c.chromaTol, { v -> vm.modCap(i, 6000 + i) { it.copy(chromaTol = v) } }, valueRange = 0.1f..0.95f) }
                    if (c.vid != null) Text("بداية مقطع التراكب (ثانية)", color = Color.White)
                    if (c.vid != null) Slider(c.srcStart / 1000f, { v -> vm.modCap(i, 6000 + i) { it.copy(srcStart = (v * 1000).toLong()) } }, valueRange = 0f..30f)
                }
            }
            "clip" -> {
                val i = if (hasVideo) vm.clipAt(pos) else -1
                val c = vm.clips.getOrNull(i)
                if (c == null) Text("أضف فيديو أولاً", color = Color.Gray) else {
                    Text("المقطع ${i + 1} من ${vm.clips.size}  •  السرعة ${c.speed}x", color = Color.White, fontSize = 16.sp)
                    Chips(SPEEDS.map { "${it}x" }, SPEEDS.indexOf(c.speed)) { vm.setSpeedAt(pos, SPEEDS[it]) }
                    Text("قص المقطع", color = Color.White, modifier = Modifier.padding(top = 10.dp))
                    RangeSlider(c.s.toFloat()..c.e.toFloat(), { vm.setTrimAt(pos, it.start.toLong(), it.endInclusive.toLong()) },
                        valueRange = 0f..vm.sources[c.src].durationMs.toFloat())
                    Text("مستوى صوت المقطع ${(c.vol * 100).toInt()}%", color = Color.White)
                    Slider(c.vol, { vm.setVolAt(pos, it) }, valueRange = 0f..1f)
                    Text("ملاحظة: تغيير السرعة والقص يحرّك الكابشن اللاحق تلقائياً.", color = Color.Gray, fontSize = 11.sp)
                }
            }
            "format" -> {
                FORMATS.forEachIndexed { i, (n, _) ->
                    Row(Modifier.fillMaxWidth().clickable { vm.formatIdx = i }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(vm.formatIdx == i, { vm.formatIdx = i }); Text(n, color = Color.White)
                    }
                }
                Opt("ملء الإطار (قص الأطراف) بدل الأشرطة السوداء", vm.fill) { vm.fill = it }
                Text("التدوير", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                Chips(listOf("0°", "90°", "180°", "270°"), vm.rotate / 90) { vm.rotate = it * 90 }
                Opt("قلب أفقي (مرآة)", vm.flip) { vm.flip = it }
            }
            "audio" -> {
                Opt("المؤثرات الصوتية (عند القطع والكابشن)", vm.optSfx) { vm.optSfx = it }
                Opt("كتم صوت الفيديو الأصلي", vm.muteOriginal) { vm.muteOriginal = it }
                Text("مستوى صوت الفيديو", color = Color.White); Slider(vm.origVol, { vm.origVol = it }, valueRange = 0f..1.5f)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button({ musicPicker.launch(arrayOf("audio/*")) }) { Icon(Icons.Default.MusicNote, null); Text(" إضافة موسيقى") }
                    if (vm.music != null) {
                        Text(vm.musicName, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(1f).padding(start = 8.dp), maxLines = 1)
                        IconButton({ vm.music = null }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                    Button({
                        if (vm.recording) stopVoice()
                        else if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) startVoice()
                        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                    }, colors = ButtonDefaults.buttonColors(containerColor = if (vm.recording) RED else ACCENT)) {
                        Icon(Icons.Default.Mic, null); Text(if (vm.recording) " إيقاف التسجيل" else " تسجيل تعليق صوتي")
                    }
                    if (vm.voice != null && !vm.recording) IconButton({ vm.voice = null }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                }
                Text("يُسجَّل التعليق أثناء تشغيل الفيديو (يُفضّل استخدام سماعات).", color = Color.Gray, fontSize = 11.sp)
                if (vm.music != null) { Text("مستوى الموسيقى", color = Color.White); Slider(vm.musicVol, { vm.musicVol = it }, valueRange = 0.05f..1f) }
            }
            "stickers" -> {
                listOf("😂🔥❤️👍😍😎🤩🥳", "👏💯✨⭐🎉💥🚀✅", "👀🙏💪🎬📌⚡🤔😱").forEach { row ->
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        row.chunked(2).forEach { e -> TextButton({ vm.addEmoji(pos, e); panel = null }) { Text(e, fontSize = 30.sp) } }
                    }
                }
                Button({ stickerPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)); panel = null }) { Icon(Icons.Default.Image, null); Text(" ملصق من صورة") }
            }
            "caps" -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ srtPicker.launch(arrayOf("*/*")) }) { Text("استيراد SRT") }
                    TextButton({
                        val v = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, "captions_${System.currentTimeMillis()}.srt")
                            put(MediaStore.Downloads.MIME_TYPE, "application/x-subrip"); put(MediaStore.Downloads.RELATIVE_PATH, "Download/")
                        }
                        val dst = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                        if (dst != null) { ctx.contentResolver.openOutputStream(dst)?.use { it.write(vm.toSrt().toByteArray()) }; vm.status = "تم حفظ ملف SRT في التنزيلات" }
                    }) { Text("تصدير SRT") }
                    Spacer(Modifier.weight(1f))
                    TextButton({ vm.addCaption(pos) }) { Icon(Icons.Default.Add, null); Text("إضافة هنا") }
                }
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    itemsIndexed(vm.captions) { i, c ->
                        if (c.img == null && c.vid == null) Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmt(c.startMs), color = if (i == vm.selCap) Color.White else Color(0xFFFFC107), fontSize = 12.sp,
                                modifier = Modifier.clickable { vm.selCap = i; vm.selClip = false; seekOut(c.startMs + 1); panel = null }.padding(end = 8.dp))
                            OutlinedTextField(c.text, { vm.editCaption(i, it) }, Modifier.weight(1f), singleLine = true)
                            IconButton({ vm.removeCaption(i) }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                        }
                    }
                }
                if (vm.captions.isEmpty()) Text("لا يوجد كابشن — استخدم «لمسة الذكية» أو أضف يدوياً أو استورد ملف SRT", color = Color.Gray, fontSize = 12.sp)
            }
            "cap_anim" -> {
                val i = vm.selCap; val c = vm.captions.getOrNull(i)
                if (c != null) {
                    Text("طريقة الظهور", color = Color.White)
                    Chips(ANIMS, c.st.anim) { v -> vm.updStyle(i) { it.copy(anim = v) } }
                    if (c.st.anim == 9) {
                        Text("لون الكلمة المميّزة", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                        Swatches(listOf(0xFFFFEB3B, 0xFF00E5FF, 0xFF69F0AE, 0xFFFF4081, 0xFFFF9100, 0xFFFFFFFF).map { it.toInt() }, c.st.hl) { v -> vm.updStyle(i) { it.copy(hl = v) } }
                    }
                    Text("الاختفاء", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(OUTS, c.st.animOut) { v -> vm.updStyle(i) { it.copy(animOut = v) } }
                    Text("حركة مستمرة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(LOOPS, c.st.loop) { v -> vm.updStyle(i) { it.copy(loop = v) } }
                    Text("مدة الحركة ${c.st.animMs} مللي ثانية", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Slider(c.st.animMs.toFloat(), { v -> vm.updStyle(i) { it.copy(animMs = v.toLong()) } }, valueRange = 100f..1200f)
                }
            }
            "cap_pos", "safe" -> {
                val i = vm.selCap; val c = vm.captions.getOrNull(i)
                if (panel == "cap_pos" && c != null) {
                    Text("التوقيت", color = Color.White)
                    RangeSlider(c.startMs.toFloat()..c.endMs.toFloat(), { vm.setCaptionTime(i, it.start.toLong(), it.endInclusive.toLong()) },
                        valueRange = 0f..maxOf(vm.totalMs, c.endMs).toFloat())
                }
                Text("المنصة", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                Chips(PLATFORMS.map { it.first }, vm.platform) { vm.platform = it }
                Opt("إظهار المناطق الآمنة في المعاينة (الأحمر = تغطيه أزرار المنصة)", vm.showSafe) { vm.showSafe = it }
                Opt("إبقاء العناصر داخل المنطقة الآمنة تلقائياً", vm.clampSafe) { vm.clampSafe = it }
                val z = PLATFORMS[vm.platform].second
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("أعلى", "وسط", "أسفل").forEachIndexed { k, n ->
                        OutlinedButton({ if (panel == "cap_pos" && c != null) vm.updStyle(i) { it.copy(y = presetY(z, k), x = 0f) } else vm.setAllY(presetY(z, k)) }) {
                            Text(if (panel == "cap_pos") n else "$n (الكل)")
                        }
                    }
                }
                Text("اسحب العنصر في المعاينة لتحريكه. المناطق تقريبية وتعمل على الفيديو العمودي 9:16.", color = Color.Gray, fontSize = 11.sp)
            }
            "templates" -> {
                Chips(TEMPLATES.map { it.first }, -1) { k ->
                    val t = TEMPLATES[k].second; val i = vm.selCap
                    if (i in vm.captions.indices) vm.updStyle(i) { c -> t.copy(x = c.x, y = c.y, size = c.size) } else vm.defStyle = t.copy(y = vm.defStyle.y)
                }
                Text("يُطبَّق على النص المحدد، أو على النصوص الجديدة إن لم يكن هناك نص محدد.", color = Color.Gray, fontSize = 11.sp)
            }
            "fx" -> {
                Opt("اهتزاز الكاميرا", vm.fxShake) { vm.fxShake = it }
                Opt("نبض (زووم إيقاعي)", vm.fxPulse) { vm.fxPulse = it }
                Opt("فينيت (تعتيم الأطراف)", vm.fxVignette) { vm.fxVignette = it }
                Opt("أشرطة سينمائية", vm.fxBars) { vm.fxBars = it }
                Text("الاهتزاز والنبض يظهران في المعاينة، والفينيت والأشرطة بعد التصدير.", color = Color.Gray, fontSize = 11.sp)
            }
            "ai" -> {
                Text("مونتاج تلقائي بضغطة واحدة", color = Color.Gray, fontSize = 12.sp)
                Opt("قص السكتات", vm.optSilence) { vm.optSilence = it }
                Opt("كابشن تلقائي", vm.optCaptions) { vm.optCaptions = it }
                Opt("زووم وانتقالات عند القطع", vm.optZoom) { vm.optZoom = it }
                Opt("مؤثرات صوتية", vm.optSfx) { vm.optSfx = it }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(16.dp)).background(Brush.horizontalGradient(listOf(ACCENT, RED)))
                    .clickable(enabled = vm.busy == null && hasVideo) { vm.autoEdit(ctx); panel = null }, contentAlignment = Alignment.Center) {
                    Text("ابدأ المونتاج التلقائي", color = Color.White, fontSize = 17.sp)
                }
                OutlinedButton({ vm.autoFitCaptions() }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("ضبط مكان الكابشن تلقائياً (منطقة آمنة)") }
                Text("الكابشن التلقائي يحتاج اتصالاً بخدمة تفريغ الكلام.", color = Color.Gray, fontSize = 11.sp)
            }
            "adjust" -> {
                Text("السطوع", color = Color.White); Slider(vm.adjB, { vm.adjB = it }, valueRange = -0.5f..0.5f)
                Text("التباين", color = Color.White); Slider(vm.adjC, { vm.adjC = it }, valueRange = -0.5f..0.5f)
                Text("التشبّع", color = Color.White); Slider(vm.adjS, { vm.adjS = it }, valueRange = -1f..1f)
                Text("الدفء (أزرق ← أحمر)", color = Color.White); Slider(vm.adjW, { vm.adjW = it }, valueRange = -1f..1f)
                TextButton({ vm.resetAdjust() }) { Text("إعادة الضبط") }
            }
            "crop" -> {
                Text("التكبير", color = Color.White); Slider(vm.tScale, { vm.tScale = it }, valueRange = 1f..3f)
                Text("إزاحة أفقية", color = Color.White); Slider(vm.tX, { vm.tX = it }, valueRange = -1f..1f)
                Text("إزاحة رأسية", color = Color.White); Slider(vm.tY, { vm.tY = it }, valueRange = -1f..1f)
                TextButton({ vm.resetCrop() }) { Text("إعادة الضبط") }
            }
            "trans" -> {
                Chips(listOf("بدون", "تلاشي للأسود", "وميض أبيض"), vm.transition) { vm.transition = it }
                Text("مدة الانتقال ${vm.transMs} مللي ثانية", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                Slider(vm.transMs.toFloat(), { vm.transMs = it.toLong() }, valueRange = 150f..900f)
                Opt("زووم عند القطع", vm.optZoom) { vm.optZoom = it }
                Opt("تلاشي في بداية الفيديو ونهايته", vm.fadeEnds) { vm.fadeEnds = it }
                Text("الانتقالات تظهر في الفيديو بعد التصدير.", color = Color.Gray, fontSize = 11.sp)
            }
            "filter" -> {
                Chips(FILTER_NAMES, vm.filterIdx) { vm.filterIdx = it }
                Text("يظهر الفلتر مباشرة في المعاينة.", color = Color.Gray, fontSize = 11.sp)
            }
            "export" -> {
                if (doneUri != null) {
                    Text("تم الحفظ في Movies/EditFast ✅", color = Color.White, modifier = Modifier.padding(vertical = 12.dp))
                    Button({
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, doneUri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }, "مشاركة"))
                    }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Text("  مشاركة") }
                } else {
                    Text("الحجم: ${FORMATS[vm.formatIdx].first}", color = Color.Gray, fontSize = 12.sp)
                    Text("الدقة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(listOf("720p", "1080p", "1440p"), vm.resIdx) { vm.resIdx = it }
                    Text("الجودة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(listOf("منخفضة (حجم أصغر)", "متوسطة", "عالية"), vm.quality) { vm.quality = it }
                    Spacer(Modifier.height(12.dp))
                    if (exporting) {
                        LinearProgressIndicator(progress = { prog }, Modifier.fillMaxWidth())
                        Text("جاري التصدير ${(prog * 100).toInt()}%", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                        TextButton({ tr?.cancel(); exporting = false }) { Text("إلغاء") }
                    } else Button({
                        val bits = listOf(listOf(3_000_000, 5_000_000, 8_000_000), listOf(6_000_000, 10_000_000, 16_000_000), listOf(10_000_000, 16_000_000, 25_000_000))
                        val sp = ExportSpec(vm.sources.map { it.uri }, vm.clips.toList(), if (vm.capsVisible) vm.captions.toList() else emptyList(),
                            vm.optZoom, vm.filterIdx, vm.optSfx, vm.muteOriginal, vm.origVol, vm.music, vm.musicVol,
                            FORMATS[vm.formatIdx].second, vm.baseRatio(), vm.rotate, vm.flip, vm.fill,
                            listOf(720, 1080, 1440)[vm.resIdx], bits[vm.resIdx][vm.quality], if (vm.clampSafe) PLATFORMS[vm.platform].second else null,
                            vm.look(), vm.transition, vm.transMs, vm.fadeEnds, vm.voice, vm.voiceStart, vm.fxVignette, vm.fxBars)
                        player.pause(); prog = 0f; exporting = true
                        tr = exportVideo(ctx, sp) { r ->
                            exporting = false
                            if (r.isSuccess) doneUri = r.getOrNull()
                            else Toast.makeText(ctx, "فشل التصدير: ${r.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                        }
                    }, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = RED)) { Text("ابدأ التصدير", fontSize = 16.sp) }
                }
            }
        }
    }

    fun panelTitle(p: String?) = when (p) {
        "pip" -> "تراكب (فيديو/صورة فوق الفيديو)"; "pip_fx" -> "القناع والتأثيرات"
        "clip" -> "سرعة وقص"; "format" -> "حجم الصورة"; "audio" -> "الصوت"; "stickers" -> "ملصقات"; "caps" -> "قائمة النصوص"
        "cap_anim" -> "الحركة"; "cap_pos" -> "التفاصيل"; "safe" -> "المنطقة الآمنة"; "templates" -> "قوالب النص"; "filter" -> "الفلتر"
        "adjust" -> "ضبط الألوان"; "crop" -> "تكبير وتحريك"; "trans" -> "الانتقالات"; "fx" -> "المؤثرات"; "ai" -> "✨ لمسة الذكية"
        "export" -> "خيارات التصدير"; else -> ""
    }

    Box(Modifier.fillMaxSize().background(BG)) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
        .pointerInput(Unit) { detectTapGestures { vm.clearSel() } }) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ settings = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
            IconButton({ vm.autosave(ctx); projItems = Projects.list(ctx); showProjects = true }) { Icon(Icons.Default.FolderOpen, null, tint = Color.White) }
            Spacer(Modifier.weight(1f))
            Row(Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(ACCENT, RED)))
                .clickable { panel = "ai"; editMode = false }.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp)); Text(vm.busy ?: "لمسة الذكية", color = Color.White, fontSize = 12.sp, maxLines = 1)
            }
            Spacer(Modifier.width(8.dp))
            Button({ doneUri = null; panel = "export"; editMode = false }, enabled = hasVideo, shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = RED), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp), modifier = Modifier.height(36.dp)) {
                Icon(Icons.Default.FileDownload, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("تصدير", fontSize = 13.sp)
            }
        }
        Box(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 8.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.aspectRatio(ratio).background(Color.Black)) {
                AndroidView({ PlayerView(it).apply { this.player = player; useController = false } },
                    Modifier.fillMaxSize(), update = { it.resizeMode = if (vm.fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT })
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val fw = constraints.maxWidth; val fh = constraints.maxHeight
                    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { if (vm.selCap >= 0 || vm.selClip) vm.clearSel() else toggle() } })
                    if (vm.capsVisible) vm.captions.forEachIndexed { i, c ->
                        if (pos in c.startMs..c.endMs) CaptionLayer(vm, i, c, pos, fw, fh, safeZ, i == vm.selCap, pipPlayer) { startEdit(i) }
                    }
                    if (vm.showSafe) PLATFORMS[vm.platform].second?.let { z ->
                        Canvas(Modifier.fillMaxSize()) {
                            val red = Color(0x44FF0000)
                            drawRect(red, Offset.Zero, Size(size.width, size.height * z.top))
                            drawRect(red, Offset(0f, size.height * (1 - z.bottom)), Size(size.width, size.height * z.bottom))
                            drawRect(red, Offset(size.width * (1 - z.right), size.height * z.top), Size(size.width * z.right, size.height * (1 - z.top - z.bottom)))
                        }
                    }
                }
                if (!hasVideo) Button({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, Modifier.align(Alignment.Center)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("اختر فيديو")
                } else if (!playing && sel == null) Icon(Icons.Default.PlayCircle, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.align(Alignment.Center).size(56.dp))
                toastText?.let { t ->
                    if (vm.busy == null) Text(t, color = Color.White, fontSize = 12.sp, maxLines = 2,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp).clip(RoundedCornerShape(50)).background(Color(0xCC000000)).padding(horizontal = 14.dp, vertical = 6.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.undo() }, enabled = vm.canUndo) { Icon(Icons.Default.Undo, null, tint = if (vm.canUndo) Color.White else Color.DarkGray) }
            IconButton({ vm.redo() }, enabled = vm.canRedo) { Icon(Icons.Default.Redo, null, tint = if (vm.canRedo) Color.White else Color.DarkGray) }
            Spacer(Modifier.weight(1f))
            Text("\u202A${fmt(pos)} / ${fmt(vm.totalMs)}\u202C", color = Color.White, fontSize = 12.sp)
            IconButton({ toggle() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
            Spacer(Modifier.weight(1f))
            if (sel != null || panel != null || clipSel) IconButton({ vm.clearSel(); panel = null; editMode = false }) { Icon(Icons.Default.Check, null, tint = Color.White) }
            else Spacer(Modifier.width(48.dp))
        }

        if (editMode && sel != null) {
            TextEditor(vm, vm.selCap, sel, fontOpts, { fontPicker.launch(arrayOf("*/*")) }, { cb -> hexCb = cb },
                onDone = { editMode = false }, onCancel = { editBackup?.let { b -> vm.modCap(vm.selCap) { b } }; editMode = false })
        } else if (panel != null) {
            Column(Modifier.fillMaxWidth().heightIn(max = 380.dp).background(PANEL)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ panel = null }) { Icon(Icons.Default.Check, null, tint = Color.White) }
                    Text(panelTitle(panel), color = Color.White, fontSize = 16.sp)
                }
                Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 12.dp)) { PanelBody() }
            }
        } else {
            val strip = Modifier.fillMaxWidth().background(BG).horizontalScroll(rememberScrollState())
            if (sel != null) {
                val media = sel.img != null || sel.vid != null
                Row(strip) {
                    if (!media) Tool(Icons.Default.Edit, "تعديل", true) { startEdit(vm.selCap) }
                    if (media) Tool(Icons.Default.Face, "القناع والتأثيرات", true) { panel = "pip_fx" }
                    Tool(Icons.Default.ContentCut, "تقسيم") { vm.splitCaption(vm.selCap, pos) }
                    Tool(Icons.Default.Delete, "حذف") { vm.removeCaption(vm.selCap) }
                    Tool(Icons.Default.ContentCopy, "نسخ") { vm.duplicateCap(vm.selCap) }
                    Tool(Icons.Default.Animation, "الحركة") { panel = "cap_anim" }
                    Tool(Icons.Default.Tune, "التفاصيل") { panel = "cap_pos" }
                    if (!media) Tool(Icons.Default.TextFields, "خط") { startEdit(vm.selCap) }
                }
            } else if (clipSel) {
                Row(strip) {
                    Tool(Icons.Default.ContentCut, "تقسيم", true) { vm.split(pos) }
                    Tool(Icons.Default.Delete, "حذف") { vm.deleteAt(pos); vm.selClip = false }
                    Tool(Icons.Default.Speed, "سرعة وقص") { panel = "clip" }
                    Tool(Icons.Default.ContentCopy, "نسخ") { vm.duplicateAt(pos) }
                    Tool(Icons.Default.ArrowBack, "تقديم") { vm.moveAt(pos, -1) }
                    Tool(Icons.Default.ArrowForward, "تأخير") { vm.moveAt(pos, 1) }
                    Tool(Icons.Default.RotateRight, "تدوير") { vm.rotate = (vm.rotate + 90) % 360 }
                }
            } else {
                Row(strip) {
                    Tool(Icons.Default.PictureInPicture, "تراكب") { panel = "pip" }
                    Tool(Icons.Default.TextFields, "نص") { vm.addCaption(pos) }
                    Tool(Icons.Default.EmojiEmotions, "ملصقات") { panel = "stickers" }
                    Tool(Icons.Default.AutoAwesomeMosaic, "قوالب نص") { panel = "templates" }
                    Tool(Icons.Default.MusicNote, "صوت") { panel = "audio" }
                    Tool(Icons.Default.Tune, "فلتر") { panel = "filter" }
                    Tool(Icons.Default.Palette, "ألوان") { panel = "adjust" }
                    Tool(Icons.Default.Movie, "مؤثرات") { panel = "fx" }
                    Tool(Icons.Default.Layers, "انتقالات") { panel = "trans" }
                    Tool(Icons.Default.AspectRatio, "الحجم") { panel = "format" }
                    Tool(Icons.Default.ZoomIn, "تكبير") { panel = "crop" }
                    Tool(Icons.Default.PhoneAndroid, "منطقة آمنة") { panel = "safe" }
                    Tool(Icons.Default.ClosedCaption, "النصوص") { panel = "caps" }
                    Tool(Icons.Default.ContentCut, "تقسيم") { vm.split(pos) }
                }
            }
            // الخط الزمني
            val lanesNow = laneIndex(vm.captions)
            val laneCount = (lanesNow.maxOrNull() ?: 0) + 1
            val audioTop = 44 + laneCount * 24 + 2
            val rulerTop = audioTop + 20
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 10.dp, top = 4.dp, bottom = 8.dp)) {
                Column(Modifier.width(34.dp)) {
                    LayerBtn(40, if (vm.muteOriginal) Icons.Default.VolumeOff else Icons.Default.VolumeUp, !vm.muteOriginal) { vm.muteOriginal = !vm.muteOriginal }
                    Spacer(Modifier.height(4.dp))
                    LayerBtn(laneCount * 24 - 2, if (vm.capsVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff, vm.capsVisible) { vm.capsVisible = !vm.capsVisible }
                    Spacer(Modifier.height(4.dp))
                    LayerBtn(16, Icons.Default.MusicNote, vm.optSfx) { vm.optSfx = !vm.optSfx }
                }
                Canvas(Modifier.weight(1f).height((rulerTop + 24).dp)
                    .pointerInput(laneCount) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            down.consume()
                            val ppm0 = zoom.dp.toPx() / 1000f
                            val ln = laneIndex(vm.captions)
                            val s0 = vm.captions.getOrNull(vm.selCap)
                            var handle = 0
                            if (s0 != null) {
                                val ly = (44 + ln[vm.selCap] * 24).dp.toPx()
                                if (down.position.y in (ly - 4.dp.toPx())..(ly + 26.dp.toPx())) {
                                    val xs = size.width / 2f + (s0.startMs - pos) * ppm0
                                    val xe = size.width / 2f + (s0.endMs - pos) * ppm0
                                    if (abs(down.position.x - (xs - 12.dp.toPx())) < 24.dp.toPx()) handle = 1
                                    else if (abs(down.position.x - (xe + 12.dp.toPx())) < 24.dp.toPx()) handle = 2
                                }
                            }
                            var total = 0f
                            do {
                                val ev = awaitPointerEvent()
                                val pan = ev.calculatePan(); val zm = ev.calculateZoom()
                                val ppm = zoom.dp.toPx() / 1000f
                                total += abs(pan.x) + abs(pan.y)
                                if (zm != 1f) zoom = (zoom * zm).coerceIn(10f, 300f)
                                if (total > 8.dp.toPx()) {
                                    val dms = (pan.x / ppm).toLong()
                                    val cur = vm.captions.getOrNull(vm.selCap)
                                    if (handle != 0 && cur != null) {
                                        if (handle == 1) vm.setCaptionTime(vm.selCap, (cur.startMs + dms).coerceIn(0, cur.endMs - 200), cur.endMs)
                                        else vm.setCaptionTime(vm.selCap, cur.startMs, (cur.endMs + dms).coerceAtLeast(cur.startMs + 200))
                                    } else if (dms != 0L) { if (player.playWhenReady) player.pause(); seekOut(pos - dms) }
                                }
                                ev.changes.forEach { if (it.positionChanged()) it.consume() }
                            } while (ev.changes.any { it.pressed })
                            if (total <= 8.dp.toPx()) {
                                val x = pos + ((down.position.x - size.width / 2f) / ppm0).toLong()
                                val plusL = size.width / 2f + (vm.totalMs - pos) * ppm0 + 6.dp.toPx()
                                if (down.position.y < 42.dp.toPx() && down.position.x in plusL..(plusL + 36.dp.toPx())) {
                                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)); return@awaitEachGesture
                                }
                                if (down.position.y < 42.dp.toPx() && vm.clips.isNotEmpty() && x in 0..vm.totalMs) {
                                    vm.selCap = -1; vm.selClip = true; seekOut(x); return@awaitEachGesture
                                }
                                if (down.position.y >= 44.dp.toPx() && down.position.y < (44 + ln.size.coerceAtLeast(0) * 0 + 3 * 24).dp.toPx()) {
                                    val lane = ((down.position.y - 44.dp.toPx()) / 24.dp.toPx()).toInt()
                                    val i = vm.captions.indices.firstOrNull { ln[it] == lane && x in vm.captions[it].startMs..vm.captions[it].endMs }
                                    if (i != null) { vm.selCap = i; vm.selClip = false; seekOut(vm.captions[i].startMs + 1); return@awaitEachGesture }
                                }
                                vm.clearSel(); seekOut(x)
                            }
                        }
                    }) {
                    val w = size.width; val cx = w / 2; val ppm = zoom.dp.toPx() / 1000f
                    fun X(t: Long) = cx + (t - pos) * ppm
                    val h1 = 40.dp.toPx(); val st0 = vm.starts(); val total = vm.totalMs
                    val cur = if (vm.clips.isEmpty()) -1 else vm.clipAt(pos)
                    vm.clips.forEachIndexed { i, c ->
                        val x0 = X(st0[i]); val x1 = X(st0[i] + c.outMs)
                        if (x1 < 0 || x0 > w) return@forEachIndexed
                        val cw0 = x1 - x0
                        drawRoundRect(Color(0xFF2A2A33), Offset(x0, 0f), Size(cw0, h1), CornerRadius(6.dp.toPx()))
                        val th = vm.thumbs[c.src]
                        if (!th.isNullOrEmpty()) {
                            val cell = (h1 * th[0].width / th[0].height).coerceAtLeast(8f)
                            clipRect(x0, 0f, x1, h1) {
                                val n = (cw0 / cell).toInt() + 1
                                for (k in 0 until n) {
                                    val xk = x0 + k * cell
                                    if (xk + cell < 0 || xk > w) continue
                                    val frac = (k * cell / cw0).coerceIn(0f, 0.999f)
                                    val srcT = c.s + ((c.e - c.s) * frac).toLong()
                                    val img = th[(srcT.toFloat() / vm.sources[c.src].durationMs * th.size).toInt().coerceIn(0, th.size - 1)]
                                    drawImage(img, IntOffset.Zero, IntSize(img.width, img.height), IntOffset(xk.toInt(), 0), IntSize(cell.toInt() + 1, h1.toInt()))
                                }
                            }
                        }
                        val on = clipSel && i == cur
                        drawRoundRect(if (on) Color.White else ACCENT, Offset(x0, 0f), Size(cw0, h1), CornerRadius(6.dp.toPx()), Stroke(if (on) 3.dp.toPx() else 1.5.dp.toPx()))
                        if (c.speed != 1f) drawRoundRect(Color(0xFFFF9800), Offset(x0 + 4.dp.toPx(), 4.dp.toPx()), Size(22.dp.toPx(), 10.dp.toPx()), CornerRadius(3.dp.toPx()))
                    }
                    // زر + في نهاية المسار
                    val plusL = X(total) + 6.dp.toPx()
                    if (plusL < w) {
                        drawRoundRect(RED, Offset(plusL, 2.dp.toPx()), Size(36.dp.toPx(), 36.dp.toPx()), CornerRadius(10.dp.toPx()))
                        drawLine(Color.White, Offset(plusL + 18.dp.toPx(), 12.dp.toPx()), Offset(plusL + 18.dp.toPx(), 28.dp.toPx()), 3.dp.toPx())
                        drawLine(Color.White, Offset(plusL + 10.dp.toPx(), 20.dp.toPx()), Offset(plusL + 26.dp.toPx(), 20.dp.toPx()), 3.dp.toPx())
                    }
                    // طبقات النص والملصقات والتراكب
                    vm.captions.forEachIndexed { i, c ->
                        val ty = (44 + lanesNow[i] * 24).dp.toPx()
                        val x0 = X(c.startMs); val cw0 = maxOf(4f, (c.endMs - c.startMs) * ppm)
                        val base = if (!vm.capsVisible) Color(0xFF555560) else if (c.vid != null) Color(0xFF7E57C2) else if (c.img != null) Color(0xFFEC407A) else GREEN
                        drawRoundRect(base, Offset(x0, ty), Size(cw0, 22.dp.toPx()), CornerRadius(5.dp.toPx()))
                        if (i == vm.selCap) {
                            drawRoundRect(Color.White, Offset(x0, ty), Size(cw0, 22.dp.toPx()), CornerRadius(5.dp.toPx()), Stroke(2.dp.toPx()))
                            for (side in 0..1) {
                                val hx = if (side == 0) x0 - 22.dp.toPx() else x0 + cw0 + 2.dp.toPx()
                                drawRoundRect(Color.White, Offset(hx, ty - 2.dp.toPx()), Size(20.dp.toPx(), 26.dp.toPx()), CornerRadius(5.dp.toPx()))
                                val mx = hx + 10.dp.toPx(); val dir = if (side == 0) 1f else -1f
                                drawLine(Color.DarkGray, Offset(mx + 3.dp.toPx() * dir, ty + 5.dp.toPx()), Offset(mx - 3.dp.toPx() * dir, ty + 11.dp.toPx()), 2.dp.toPx())
                                drawLine(Color.DarkGray, Offset(mx - 3.dp.toPx() * dir, ty + 11.dp.toPx()), Offset(mx + 3.dp.toPx() * dir, ty + 17.dp.toPx()), 2.dp.toPx())
                            }
                        }
                    }
                    val at = audioTop.dp.toPx()
                    if (vm.music != null) drawRoundRect(Color(0xFF26A69A), Offset(X(0), at), Size(total * ppm, 16.dp.toPx()), CornerRadius(5.dp.toPx()))
                    vm.voice?.let { v -> drawRoundRect(Color(0xFFEF5350), Offset(X(vm.voiceStart), at), Size((v.size / 44.1f) * ppm, 8.dp.toPx()), CornerRadius(3.dp.toPx())) }
                    if (vm.optSfx) st0.drop(1).forEach { drawRect(Color(0xFFFF9800), Offset(X(it) - 1.dp.toPx(), at), Size(3.dp.toPx(), 16.dp.toPx())) }
                    val step = if (zoom >= 100f) 1000L else if (zoom >= 40f) 2000L else 5000L
                    paint.textSize = 10.sp.toPx()
                    var t = (((pos - (cx / ppm).toLong()).coerceAtLeast(0)) / step) * step
                    val rt = rulerTop.dp.toPx()
                    while (X(t) < w + 40 && t <= total) {
                        val x = X(t)
                        drawRect(Color.Gray, Offset(x, rt), Size(1.dp.toPx(), 5.dp.toPx()))
                        drawContext.canvas.nativeCanvas.drawText(String.format(Locale.US, "%d:%02d", t / 60000, (t / 1000) % 60), x - 8.dp.toPx(), rt + 17.dp.toPx(), paint)
                        t += step
                    }
                    drawRect(Color.White, Offset(cx - 1.5.dp.toPx(), 0f), Size(3.dp.toPx(), size.height))
                }
            }
        }
    }
    if (showProjects) ProjectsScreen(projItems,
        onOpen = { id ->
            if (id != vm.projectId) { vm.autosave(ctx); vm.openProject(ctx, id) }
            showProjects = false
        },
        onNew = { vm.autosave(ctx); vm.newProject(); showProjects = false },
        onDelete = { id ->
            Projects.delete(ctx, id); projItems = Projects.list(ctx)
            if (id == vm.projectId) vm.newProject()
        },
        onClose = if (vm.projectId != 0L) ({ showProjects = false }) else null)
    }

    hexCb?.let { cb ->
        var h by remember { mutableStateOf("#FFFFFF") }
        AlertDialog(onDismissRequest = { hexCb = null },
            confirmButton = { TextButton({ runCatching { android.graphics.Color.parseColor(h) }.getOrNull()?.let(cb); hexCb = null }) { Text("تطبيق") } },
            title = { Text("لون مخصص") },
            text = { OutlinedTextField(h, { h = it }, singleLine = true, label = { Text("#RRGGBB") }) })
    }

    if (settings) {
        var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var lang by remember { mutableStateOf(prefs.getString("lang", "ar") ?: "ar") }
        var url by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
        AlertDialog(onDismissRequest = { settings = false },
            confirmButton = { TextButton({ prefs.edit().putString("key", key.trim()).putString("lang", lang.trim()).putString("url", url.trim()).apply(); settings = false }) { Text("حفظ") } },
            title = { Text("الإعدادات") },
            text = {
                Column {
                    Text("مفتاح Groq المجاني لتحويل الكلام إلى نص (console.groq.com)", fontSize = 12.sp)
                    OutlinedTextField(key, { key = it }, label = { Text("API Key") }, singleLine = true)
                    OutlinedTextField(lang, { lang = it }, label = { Text("لغة الكلام (ar / en / فارغ=تلقائي)") }, singleLine = true)
                    OutlinedTextField(url, { url = it }, label = { Text("عنوان الخدمة (اختياري)") }, singleLine = true)
                    if (BuildConfig.GROQ_KEY.isNotBlank()) Text("✓ مفتاح مدمج في التطبيق، لا حاجة لإدخاله", fontSize = 11.sp)
                }
            })
    }
}
