package com.example.editfast

import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.io.File

private val BG = Color(0xFF0D0D12)
private val PANEL = Color(0xFF16161F)
private val ACCENT = Color(0xFF8B5CF6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = ACCENT)) { EditorScreen() } }
    }
}

private fun fmt(ms: Long) = "%02d:%02d".format(ms / 60000, (ms / 1000) % 60)

@Composable
private fun Tool(icon: ImageVector, label: String, hi: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (hi) Color(0xFFB794FF) else Color.White, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(4.dp)); Text(label, fontSize = 11.sp, color = if (hi) Color(0xFFB794FF) else Color.White)
    }
}

@Composable
private fun Opt(label: String, on: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f)); Switch(on, set)
    }
}

@Composable
private fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            Box(Modifier.size(34.dp).clip(CircleShape).background(if (c == 0) Color(0xFF2A2A36) else Color(c))
                .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Color.White else Color.Gray, CircleShape)
                .clickable { onPick(c) }, contentAlignment = Alignment.Center) { if (c == 0) Text("∅", color = Color.White) }
        }
    }
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    var pos by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<String?>(null) }
    var settings by remember { mutableStateOf(false) }
    val customFonts = remember { mutableStateListOf<File>().apply { addAll(ctx.filesDir.listFiles { f -> f.name.startsWith("font_") }.orEmpty()) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            val m = MediaMetadataRetriever().apply { setDataSource(ctx, u) }
            val d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            m.release(); vm.onVideo(u, d); player.setMediaItem(MediaItem.fromUri(u)); player.prepare()
        }
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val name = (u.lastPathSegment ?: "font").substringAfterLast('/').substringBeforeLast('.')
            val f = File(ctx.filesDir, "font_$name.ttf")
            ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            if (customFonts.none { it.name == f.name }) customFonts.add(f)
            vm.style = vm.style.copy(font = name, fontPath = f.path)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            pos = player.currentPosition; playing = player.isPlaying
            if (player.isPlaying && vm.segments.isNotEmpty() && vm.segments.none { pos in it.s..it.e }) {
                val nxt = vm.segments.firstOrNull { it.s > pos }
                if (nxt != null) player.seekTo(nxt.s) else player.pause()
            }
            delay(60)
        }
    }
    fun toggle() {
        if (vm.uri == null) return
        if (player.isPlaying) player.pause() else {
            if (vm.segments.none { pos in it.s..it.e }) player.seekTo(vm.segments.firstOrNull()?.s ?: 0); player.play()
        }
    }
    val st = vm.style
    val capFamily = remember(st.font, st.fontPath, st.bold) { FontFamily(st.typeface()) }

    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {
        // الشريط العلوي
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }) { Icon(Icons.Default.VideoLibrary, null, tint = Color.White) }
            IconButton({ settings = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
            Spacer(Modifier.weight(1f))
            Button(shape = RoundedCornerShape(50), enabled = vm.uri != null && !exporting, onClick = {
                exporting = true; player.pause()
                exportVideo(ctx, vm.uri!!, vm.segments.toList(), vm.captions.toList(), vm.style, vm.optZoom, vm.optGrade, vm.optSfx) { r ->
                    exporting = false
                    Toast.makeText(ctx, if (r.isSuccess) "تم الحفظ في Movies/EditFast ✅" else "فشل التصدير: ${r.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                }
            }) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(6.dp)); Text(if (exporting) "جاري التصدير..." else "تصدير") }
        }
        // المعاينة
        Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black).clickable { toggle() }) {
            AndroidView({ PlayerView(it).apply { this.player = player; useController = false } }, Modifier.fillMaxSize())
            vm.captions.firstOrNull { pos in it.startMs..it.endMs }?.let {
                Text(it.text, color = Color(st.color), fontFamily = capFamily, fontSize = (22 * st.size).sp,
                    modifier = Modifier.align(listOf(Alignment.TopCenter, Alignment.Center, Alignment.BottomCenter)[st.pos])
                        .padding(24.dp).then(if (st.bg != 0) Modifier.background(Color(st.bg)) else Modifier).padding(horizontal = 6.dp))
            }
            if (vm.uri == null) Button({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, Modifier.align(Alignment.Center)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("اختر فيديو")
            } else if (!playing) Icon(Icons.Default.PlayCircle, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.align(Alignment.Center).size(64.dp))
        }
        // شريط التحكم
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${fmt(pos)} / ${fmt(vm.durationMs)}", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            IconButton({ toggle() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(32.dp)) }
            Text(vm.busy ?: vm.status, color = if (vm.busy != null) Color(0xFFB794FF) else Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(2f))
        }
        // الخط الزمني: بنفسجي = مقاطع محفوظة، أصفر = كابشن
        val d = vm.durationMs.coerceAtLeast(1).toFloat()
        Canvas(Modifier.fillMaxWidth().height(76.dp).padding(horizontal = 12.dp)
            .pointerInput(vm.durationMs) { detectTapGestures { o -> if (vm.uri != null) player.seekTo((o.x / size.width * d).toLong()) } }
            .pointerInput(vm.durationMs) { detectHorizontalDragGestures { c, _ -> if (vm.uri != null) player.seekTo((c.position.x / size.width * d).toLong().coerceIn(0, vm.durationMs)) } }) {
            val w = size.width; val h = 34.dp.toPx()
            drawRoundRect(Color(0xFF22222E), Offset.Zero, Size(w, h), CornerRadius(8.dp.toPx()))
            vm.segments.forEach { drawRoundRect(Color(0xFF6D4AFF), Offset(it.s / d * w, 0f), Size((it.e - it.s) / d * w, h), CornerRadius(8.dp.toPx())) }
            vm.captions.forEach { drawRoundRect(Color(0xFFFFC107), Offset(it.startMs / d * w, 42.dp.toPx()), Size(maxOf(4f, (it.endMs - it.startMs) / d * w), 20.dp.toPx()), CornerRadius(5.dp.toPx())) }
            drawRect(Color.White, Offset(pos / d * w - 1.5.dp.toPx(), 0f), Size(3.dp.toPx(), size.height))
        }
        // شريط الأدوات
        Row(Modifier.fillMaxWidth().background(PANEL).horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
            Tool(Icons.Default.AutoAwesome, "مونتاج تلقائي", true) { vm.autoEdit(ctx) }
            Tool(Icons.Default.ClosedCaption, "الكابشن") { panel = "caps" }
            Tool(Icons.Default.TextFields, "الخط والستايل") { panel = "style" }
            Tool(Icons.Default.AutoFixHigh, "المؤثرات") { panel = "fx" }
            Tool(Icons.Default.ContentCut, "قص") { panel = "trim" }
        }
    }

    if (panel != null) ModalBottomSheet({ panel = null }, containerColor = PANEL) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            when (panel) {
                "caps" -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("تعديل الكابشن", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        TextButton({ vm.addCaption(pos) }) { Icon(Icons.Default.Add, null); Text("إضافة هنا") }
                    }
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        itemsIndexed(vm.captions) { i, c ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(fmt(c.startMs), color = Color(0xFFFFC107), fontSize = 12.sp, modifier = Modifier.clickable { player.seekTo(c.startMs) }.padding(end = 8.dp))
                                OutlinedTextField(c.text, { vm.editCaption(i, it) }, Modifier.weight(1f), singleLine = true)
                                IconButton({ vm.removeCaption(i) }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                            }
                        }
                    }
                    if (vm.captions.isEmpty()) Text("لا يوجد كابشن بعد — استخدم «مونتاج تلقائي» أو أضف يدوياً", color = Color.Gray, fontSize = 12.sp)
                }
                "style" -> {
                    Text("الخط", color = Color.White)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("sans-serif" to "عادي", "sans-serif-medium" to "متوسط", "serif" to "Serif", "monospace" to "Mono", "casual" to "Casual", "cursive" to "Cursive", "sans-serif-condensed" to "ضيّق").forEach { (k, n) ->
                            FilterChip(st.font == k && st.fontPath == null, { vm.style = st.copy(font = k, fontPath = null) }, { Text(n) })
                        }
                        customFonts.forEach { f ->
                            val n = f.name.removePrefix("font_").removeSuffix(".ttf")
                            FilterChip(st.fontPath == f.path, { vm.style = st.copy(font = n, fontPath = f.path) }, { Text(n) })
                        }
                        AssistChip({ fontPicker.launch(arrayOf("*/*")) }, { Text("+ خط من الجهاز") })
                    }
                    Text("الحجم", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Slider(st.size, { vm.style = st.copy(size = it) }, valueRange = 0.6f..1.8f)
                    Text("لون النص", color = Color.White)
                    Swatches(listOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFF00E5FF, 0xFF69F0AE, 0xFFFF4081, 0xFFFF9100).map { it.toInt() }, st.color) { vm.style = st.copy(color = it) }
                    Text("خلفية النص", color = Color.White)
                    Swatches(listOf(0, 0xFF000000, 0x99000000, 0xFFFFEB3B, 0xFF6D4AFF).map { it.toInt() }, st.bg) { vm.style = st.copy(bg = it) }
                    Opt("خط عريض", st.bold) { vm.style = st.copy(bold = it) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("أعلى", "وسط", "أسفل").forEachIndexed { i, n -> FilterChip(st.pos == i, { vm.style = st.copy(pos = i) }, { Text(n) }) }
                    }
                }
                "fx" -> {
                    Text("خيارات المونتاج", color = Color.White, fontSize = 16.sp)
                    Opt("قص السكتات تلقائياً", vm.optSilence) { vm.optSilence = it }
                    Opt("كابشن تلقائي", vm.optCaptions) { vm.optCaptions = it }
                    Opt("زووم وانتقالات عند القطع", vm.optZoom) { vm.optZoom = it }
                    Opt("تدرج ألوان", vm.optGrade) { vm.optGrade = it }
                    Opt("مؤثرات صوتية", vm.optSfx) { vm.optSfx = it }
                    Text("الزووم والألوان والمؤثرات الصوتية تظهر بعد التصدير.", color = Color.Gray, fontSize = 11.sp)
                }
                "trim" -> {
                    Text("قص يدوي (يستبدل القص التلقائي)", color = Color.White)
                    if (vm.durationMs > 0 && vm.segments.isNotEmpty()) RangeSlider(
                        vm.segments.first().s.toFloat()..vm.segments.last().e.toFloat(),
                        { vm.setRange(it.start.toLong(), it.endInclusive.toLong()); player.seekTo(it.start.toLong()) },
                        valueRange = 0f..vm.durationMs.toFloat())
                    TextButton({ vm.setRange(0, vm.durationMs) }) { Text("استعادة الفيديو كاملاً") }
                }
            }
        }
    }

    if (settings) {
        var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var lang by remember { mutableStateOf(prefs.getString("lang", "ar") ?: "ar") }
        AlertDialog(onDismissRequest = { settings = false },
            confirmButton = { TextButton({ prefs.edit().putString("key", key.trim()).putString("lang", lang.trim()).apply(); settings = false }) { Text("حفظ") } },
            title = { Text("الإعدادات") },
            text = {
                Column {
                    Text("مفتاح Groq المجاني لتحويل الكلام إلى نص (console.groq.com)", fontSize = 12.sp)
                    OutlinedTextField(key, { key = it }, label = { Text("API Key") }, singleLine = true)
                    OutlinedTextField(lang, { lang = it }, label = { Text("لغة الكلام (ar / en / فارغ=تلقائي)") }, singleLine = true)
                }
            })
    }
}
