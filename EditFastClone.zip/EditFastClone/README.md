# EditFast Clone (MVP)
ارفع المشروع إلى GitHub، وسيبنيه ملف .github/workflows/build.yml تلقائياً (Actions ← Artifacts ← EditFast-debug-apk).
- اختيار فيديو، تشغيل، قص بالشريط أو بالأمر "قص من 2 إلى 8"
- مساعد شات: "كابشن: النص هنا" يوزّع الكابشن على الفيديو
- تصدير MP4 مع حرق الكابشن عبر Media3 Transformer
الخطوات التالية: كابشن تلقائي (Speech-to-Text)، قوالب موشن، إزالة الخلفية، ربط المساعد بنموذج ذكاء اصطناعي.
